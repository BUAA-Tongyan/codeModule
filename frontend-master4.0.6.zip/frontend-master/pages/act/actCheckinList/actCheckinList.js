// pages/act/actCheckinList/actCheckinList.js
import {
  api_GetConsumeActList
} from '../../api/getData.js'


Page({

  /**
   * 页面的初始数据
   */
  data: {
    dataSource: [],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    /*获取可签到的活动列表*/
    api_GetConsumeActList((res) => {
      let tmp=[]
      let actarr = res.data.data
      console.log("#########--可签到的活动列表--##########", actarr)
      actarr.forEach(i =>{
        console.log(i)
        if (i.title.indexOf("transaction") != -1){
          console.log("skip",i)
        }
        else {
          tmp.push(i)
        }
      })
      this.setData({
        dataSource: tmp
      });
    })
  },
  // 跳转查看审核详情
  onClickCheckDetail: function(e) {
    console.log(e)
    console.log('签到的活动ID==>', e.currentTarget.dataset.index.actId)
    console.log('签到的活动consumeToken==>', e.currentTarget.dataset.index.consumeToken)
    console.log('是否需要签退needSignOut==>', e.currentTarget.dataset.index.needSignOut)
    let actId = e.currentTarget.dataset.index.actId
    let consumeToken = e.currentTarget.dataset.index.consumeToken
    let needSignOut = e.currentTarget.dataset.index.needSignOut
    let cardID = e.currentTarget.dataset.index.cardID
    wx.navigateTo({
      url: '../actCheckin/actCheckin?actId=' + actId + '&consumeToken=' + consumeToken + '&needSignOut=' + needSignOut + '&cardID=' + cardID,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})
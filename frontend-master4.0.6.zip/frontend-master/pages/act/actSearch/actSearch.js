// pages/act/actSearch/actSearch.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    value: '',
    dataSource: {
      actInfo: {},
      selectedFlag: false, // 参与人展开折叠标记
    },
    idSelected: true,
    topicSelected: false,
    domainSelected: false,
    placeSelected: false,
    searchType: 'byId',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },

  searchById: function() {
    console.log('==> 搜索ID')
    this.setData({
      idSelected: true,
      topicSelected: false,
      domainSelected: false,
      placeSelected: false,
      searchType: 'byId'
    })
  },
  searchByTopic: function() {
    console.log('==> 搜索主题')
    this.setData({
      idSelected: false,
      topicSelected: true,
      domainSelected: false,
      placeSelected: false,
      searchType: 'byTitle'
    })
  },
  searchByDomain: function() {
    console.log('==> 搜索学科')
    this.setData({
      idSelected: false,
      topicSelected: false,
      domainSelected: true,
      placeSelected: false,
      searchType: 'byDomain'
    })
  },
  searchByPlace: function() {
    console.log('==> 搜索地点')
    this.setData({
      idSelected: false,
      topicSelected: false,
      domainSelected: false,
      placeSelected: true,
      searchType: 'byPlace'
    })
  },

  /*搜索相关函数*/
  onChange(e) {
    console.log('onChange-------------------------==>', e)
    this.setData({
      value: e.detail
    });
  },
  onSearch(e) {
    console.log('onSearch-------------------------==>', e)
    console.log('需要搜索的关键词和类型==>', e.detail, this.data.searchType)
    /*跳转搜索结果*/
    wx.navigateTo({
      url: '../actSearchResult/actSearchResult?searchType=' + this.data.searchType + '&keywords=' + this.data.value,
      success: function(res) {
        // success
      },
      fail: function() {
        // fail
      },
      complete: function() {
        // complete
      }
    })
  },

})
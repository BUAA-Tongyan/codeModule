let {
  api_SearchAct,
  api_GetActList,

} = require("../../api/getData.js")

Page({

  /**
   * 页面的初始数据
   */
  data: {
    curPage: 0,
    // dataSource: [],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

    let keywords = options.keywords
    let searchType = options.searchType
    console.log("#########--搜索条件--##########", keywords, searchType)
    
    let params = {
      page: this.data.curPage + 1,
      size: 20
    };

    let fleas=[]
    api_GetActList(params, (res) => {
      if (res.errcode == 0) {
        console.log("#########--搜索结果--##########", res.data.list)
        var dataSource = []
        for (var index in res.data.list) {
          var t = res.data.list[index]

          if ((t.domains[0] == '跳蚤市场') && (t.state !== "已取消")) {
            // 题目修改
            if (t.title.search("transaction") != -1) {
              t.headImg = JSON.parse(t.title).headImg
              if (t.headImg.indexOf("http://www.buaagsu.com/yan/static/") != -1) {
                t.headImg = t.headImg
              }
              else {
                t.headImg = "http://www.buaagsu.com/yan/static/buaainfoImg" + t.headImg
              }
              t.place = JSON.parse(t.title).plc
              t.itemtype = JSON.parse(t.title).itp
              t.title = '【' + JSON.parse(t.title).transaction + '】' + JSON.parse(t.title).title
            } else {
              t.title = t.title
            }
            // 发起人修改
            if (t.contactName.search("qrcode") != -1) {
              t.contactName = JSON.parse(t.contactName).contactName
            } else {
              t.contactName = t.contactName
            }

            if ((searchType == 'byId')&&(t.actId==keywords)) {
              fleas.push(t)
              
            } else if ((searchType == 'byType') && (t.itemtype.indexOf(keywords) != -1)) {
              fleas.push(t)

            } else if ((searchType == 'byTran') && (t.title.indexOf(keywords) != -1)) {
              fleas.push(t)

            } else if ((searchType == 'byPlace') && ((t.place.indexOf("邮") != -1) || (t.place.indexOf("快递") != -1) ))  {
              fleas.push(t)
            }else if ((searchType == 'byPlace') && (t.place.indexOf(keywords) != -1)) {
              fleas.push(t)
            }


            // fleas.push(t)
          }

        }
        console.log("筛选后的跳蚤市场列表 --> ", fleas)
        var researchResult=fleas
        this.setData({
          dataSource: researchResult,
        })

        if (res.data.list.length == 0) {
          setTimeout(function() {
            wx.navigateBack({
              delta: 1
            })
          }, 2000)
        }
      } else {
        wx.showToast({
          title: res.errmsg,
          icon: 'none',
          duration: 2000
        })
        setTimeout(function() {
          wx.navigateBack({
            delta: 1
          })
        }, 2000)
      }
    })
  },

  //点击跳转活动详情页
  onClickTODO: function(e) {
    var $data = e.currentTarget.dataset.index;
    console.log('当前点击的活动ID==>', $data.actId)
    wx.navigateTo({
      url: '../itemDetail/itemDetail?actId=' + $data.actId,
      success: function(res) {
        // success
      },
      fail: function() {
        // fail
      },
      complete: function() {
        // complete
      }
    })
  },
  /*获取主页活动列表*/
  getHomeActList: function () {
    console.log("==> 加载函数执行")
    wx.showToast({
      title: '数据加载中',
      icon: 'loading',
      duration: 3000,
    });
    console.log("bottom: ", this.data.bottom)
    if (this.data.bottom >= this.data.maxSize) {
      console.log("==> 到达底部");
      this.setData({
        noDataFlag: true
      })
      wx.hideToast()
      return
    } else {
      let params = {
        page: this.data.curPage + 1,
        size: 5
      };
      let weishalong = this.data.dataSource

      api_GetActList(params, (res) => {
        console.log("#########--活动列表--##########", res.data)
        //下拉刷新停止
        wx.stopPullDownRefresh()
        // res.data.list.forEach(i => {
        //   if (i.domains[0]=='跳蚤市场') {
        //     weishalong.push(i)
        //   }
        // })
        var dataSource = []
        for (var index in res.data.list) {
          var t = res.data.list[index]

          if (t.domains[0] == '跳蚤市场') {
            // 题目修改
            if (t.title.search("transaction") != -1) {
              t.headImg = JSON.parse(t.title).headImg
              t.title = '【' + JSON.parse(t.title).transaction + '】' + JSON.parse(t.title).title
            } else {
              t.title = t.title
            }
            // 发起人修改
            if (t.contactName.search("qrcode") != -1) {
              t.contactName = JSON.parse(t.contactName).contactName
            } else {
              t.contactName = t.contactName
            }
            weishalong.push(t)
          }

        }
        console.log("筛选后的跳蚤市场列表 --> ", weishalong)

        this.setData({
          bottom: weishalong.length,
          dataSource: weishalong,
          curPage: res.data.curPage,
          maxSize: res.data.maxSize,
        })
        console.log("==> 展示数据", this.data.dataSource);
        wx.hideToast()
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  // /**
  //  * 用户点击右上角分享
  //  */
  // onShareAppMessage: function() {

  // }
})
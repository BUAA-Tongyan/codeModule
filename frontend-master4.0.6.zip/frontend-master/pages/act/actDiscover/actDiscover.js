// pages/act/actDiscover/actDiscover.js

let {
  api_GetDiscoverList,
  api_GetAllBanners,
} = require("../../api/getData.js")
Page({

  /**
   * 页面的初始数据
   */
  data: {
    swiperList: [],
    indicatorDots: true,
    autoplay: true,
    interval: 2000,
    duration: 1000,
    previousMargin: 0,
    nextMargin: 0,
    discoverList: [],
    
    curPage: -1,
    maxSize: 0,
    bottom: -1,
    //发现列表采用maxPage判断
    maxPage: 0,
    noDataFlag: false,
    club_info_unchecked: false,
    site_info_unchecked: false,
    shop_info_unchecked: false,
    minipro_info_unchecked: false,
    calendar_info_unchecked: false,
    ministory_info_unchecked: false,
    challenge14_unchecked: false,
    offeryes_unchecked: false,
    register_flag:false,

    showBack: false,
    // buaa_calendar_unchecked: false,
  }, 
   onShareAppMessage: function() {
        const promise = new Promise(resolve => {
          setTimeout(() => {
            resolve({
              title: '同研————开启新视界'
            })
          }, 20) /*20是延时*/ 
        })
        return {
          title: '同研————开启新视界',
          path: 'pages/act/myIndex/myIndex',
          promise 
        }
    },
      //转发到朋友圈
     onShareTimeline(){},
  /**
   * 生命周期函数--监听页面加载
   */

   onShow: function () {
    const pages = getCurrentPages();
    const currentPage = pages[pages.length - 1];
    this.onLoad(currentPage.options);
  },
  onLoad: function (options) {
    /*获取发现列表*/
    this.getDiscoverList();
    this.setData({
      club_info_unchecked:wx.getStorageSync("club_info_1"),
      site_info_unchecked:wx.getStorageSync("site_info_0"),
      shop_info_unchecked:wx.getStorageSync("shop_info_2"),
      minipro_info_unchecked:wx.getStorageSync("minipro_info_3"),
      calendar_info_unchecked:wx.getStorageSync("calendar_info_5"),
      ministory_info_unchecked:wx.getStorageSync("ministory_info_4"),
      challenge14_unchecked:wx.getStorageSync("challenge14_6"),
      offeryes_unchecked:wx.getStorageSync("offeryes_7"),
      register_flag:getApp().globalData.userNotSignUp,
    })
    console.log(getApp().globalData.userNotSignUp)
    api_GetAllBanners((res) => {
      if (res.length) {
        this.setData({
          swiperList: res
        });
      } else {
        this.setData({
          swiperList: [{
            url: '',
            img: 'http://www.buaa.edu.cn/__local/D/A6/CF/285952AD92970F08226AECCD5E3_C8F39F61_106FF.jpg',
            title: '学院路校区'
          }, {
            url: '',
            img: 'http://www.buaa.edu.cn/__local/8/18/50/33226DE0493305EA215E7F40655_C7255710_15B18.jpg',
            title: '图书馆'
          }, {
            url: '',
            img: 'http://www.buaa.edu.cn/__local/6/CE/0C/E18BA593FC960A0B53E7C1CD455_6532815F_38D87.jpg',
            title: '沙河校区'
          }]
        })
      }
      console.log("#########--轮播图--##########", this.data.swiperList)
    })
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.refresh();
  },

  showalert: function(){
    wx.showModal({
      content: '近期上线，敬请期待。',
      showCancel : false  
      })
    
  },

  getDiscoverList: function (e) {
    wx.showToast({
      title: '数据加载中',
      icon: 'loading',
      duration: 3000,
    });


    if (this.data.curPage == this.data.maxPage) {
      console.log("==> 到达底部");
      this.setData({
        noDataFlag: true
      })
      wx.hideToast()
      return
    } else {
      let params = {
        page: this.data.curPage + 1,
        size: 3
      };
      let tmp = this.data.discoverList
      api_GetDiscoverList(params, (res) => {
        console.log("#########--获取发现列表--##########", res.data)
        //下拉刷新停止
        wx.stopPullDownRefresh()
        wx.hideToast()
        res.data.data.list.forEach(i => {
          // 临时处理
          if (i.headImgLink == "") {
            i.headImgLink = '/images/discDemo-2.35x1.jpg'
          }
          tmp.push(i)
        })
        this.setData({
          bottom: tmp.length,
          discoverList: tmp,
          curPage: res.data.data.curPage,
          maxPage: res.data.data.maxPage - 1,
        })
      })
    }
  },

  /* 下拉刷新 */
  refresh: function () {
    console.log("==> 下拉刷新")
    this.setData({
      bottom: -1,
      discoverList: [],
      curPage: -1,
      maxSize: 0,
    })
    this.getDiscoverList();
  },

  /** 
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    this.getDiscoverList();
  }

})
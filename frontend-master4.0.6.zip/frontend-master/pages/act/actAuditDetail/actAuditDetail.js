// pages/act/actAuditDetail/actAuditDetail.js
let {
  api_GetApplyFormDetail,
  api_DealPassAudit,
  api_DealRejectAudit,
  api_SendTemplateMessage,
  api_DeleteActivity
} = require("../../api/getData.js")
import {
  $wuxToptips
} from '../../components/wux-index'
const app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    adminShow:false,
    userInfo: {}, // 用户信息
    hasUserInfo: null,
    dataSource: {
      actInfo: {},
      selectedFlag: false, // 参与人展开折叠标记
    },
    rejectFlag: false,
    rejectReason: '',
    color:"",
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    // 风格
    let style = wx.getStorageSync('style')
    switch (style){
      case "lightblue" : this.setData({
        color:"#3367DD"
      })
      break
      case "blue" : this.setData({
        color:"#475793"
      })
      break
      case "black" : this.setData({
        color:"black"
      })
      break
      case "red" : this.setData({
        color:"#C32B20"
      })
      break

    }
    console.log('options query===================', options.actApplyFormId)

    // 获取用户信息
    if (app.globalData.userInfo) {
      console.log('globalData用户信息 -->', app.globalData.userInfo)
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true,
        adminShow: this.hasAuthorities(['ROLE_013_Admin', 'ROLE_005_Admin', 'ROLE_010_Admin'])
      })
    }

    /*获取未审核活动详情*/
    let params = options.actApplyFormId
    api_GetApplyFormDetail(params, (res) => {
      console.log("#########--发起的活动详情--##########", res.data.data)
      let str = 'dataSource.actInfo'
      var data = res.data.data
      // var imgUrl = data.summary.split("imgUrl:")[1]
      // console.log("拿到的附图链接 --> ", imgUrl)
      if (data.summary.search("itemprice")!=-1) {
        var items = JSON.parse(data.summary)
        data.itemprice = "物品价格：" + items.itemprice;
        data.itemtype = "物品种类：" + items.itemtype;
        data.detailImg = items.detailImg;
        data.summary = "物品详情：" + items.summary;
      } else {
        data.summary = data.summary
      }
      if (data.title.search("transaction") != -1) {
        var titleitems = JSON.parse(data.title)
        data.transaction = titleitems.transaction;
        if (titleitems.headImg.indexOf("http://www.buaagsu.com/yan/static/") != -1) {
          data.headImg = titleitems.headImg
        }
        else {
          data.headImg = "http://www.buaagsu.com/yan/static/buaainfoImg" + titleitems.headImg
        }
        // data.headImg = titleitems.headImg;
        data.title = titleitems.title;
      } else {
        data.title = data.title
      }
      if (data.contactName.search("qrcode") != -1) {
        data.qrcode = JSON.parse(data.contactName).qrcode;
        data.contactName = JSON.parse(data.contactName).contactName;
      } else {
        data.contactName = data.contactName
      }
      
      this.setData({
        [str]: data
      })
      console.log("data --> ", this.data)
    })


  },

  /**
   * 验证用户权限
   */
  hasAuthorities: function (checkList) {
    let authList = wx.getStorageSync("allAuthorities")
    for (let j = 0; j < checkList.length; j++) {
      for (let i = 0; i < authList.length; i++) {
        if (authList[i] === checkList[j]) {
          return true
        }
      }
    }
    return false
  },
  onPass: function(e) {
    console.log('formId==>', e.detail.formId)
    var that = this
    that.setData({
      rejectFlag: false,
      formId: e.detail.formId
    })
    console.log('要通过的活动ID', that.data.dataSource.actInfo.actApplyFormId)
    let tmp = JSON.stringify(that.data.dataSource.actInfo.actApplyFormId);
    let result = 'actApplyFormId='
    result += tmp
    api_DealPassAudit(result, (res) => {
      console.log('审核结果==>', res)
      if (res.errmsg == 'ok') {
        wx.showToast({
          title: '通过成功！',
          icon: 'success',
          duration: 2000
        })
        //发送模板消息
        that.sendPassTemplateMessage()
        setTimeout(function() {
          wx.navigateBack({
            delta: 1
          })
        }, 2000)
      } else {
        wx.showModal({
          title: '通过失败',
          content: res.errmsg + '！请确认该活动时间是否过期。',
        })
      }
    })
  },

  onReject: function(e) {
    this.setData({
      rejectFlag: true
    })
  },

  //拒绝原因
  setRejectReason: function(e) {
    this.setData({
      rejectReason: e.detail.value
    })
  },

  onRejectConfirm: function(e) {
    let that = this
    console.log('formId==>', e.detail.formId)
    console.log('拒绝原因==>', that.data.rejectReason)
    // that.setData({
    //   formId: e.detail.formId
    // })
    let tmp = that.data.rejectReason
    if (tmp !== '') {
      console.log('要拒绝的活动ID==>', that.data.dataSource.actInfo.actApplyFormId)
      let result = {
        actApplyFormId: that.data.dataSource.actInfo.actApplyFormId,
        reason: tmp
      }
      console.log('要提交的拒绝信息==>', result)
      api_DealRejectAudit(result, (res) => {
        console.log('审核结果==>', res)
        if (res.errmsg == 'ok') {
          //发送模板消息
          that.sendPassTemplateMessage()
          wx.showToast({
            title: '拒绝成功！',
            icon: 'success',
            duration: 2000
          })
          wx.navigateBack({
            delta: 1
          })
        }
      })
    } else {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '请填写拒绝原因',
        duration: 2000,
        success() {},
      })
    }

  },

  sendPassTemplateMessage: function(e) {
    let that = this
    // 模板消息关键词参数
    let keywords = {
      "keyword1": {
        "value": that.data.rejectFlag ? "未通过" : "通过",
        "color": "#173177"
      },
      "keyword2": {
        "value": that.data.rejectFlag ? that.data.rejectReason : "请按时举行活动",
        "color": "#173177"
      },
      "keyword3": {
        "value": that.data.dataSource.actInfo.title,
        "color": "#173177"
      },
      "keyword4": {
        "value": that.data.dataSource.actInfo.startTime,
        "color": "#173177"
      },
      "keyword5": {
        "value": that.data.dataSource.actInfo.place,
        "color": "#173177"
      },
    }
    let data = JSON.stringify(keywords);
    let messageData = {
      templateId: 'ku6LQ3VL0-_vSbeaVFsRXGDEsRsBOWWyKFyDpwplyi0',
      page: '/pages/act/home/home',
      formId: that.data.dataSource.actInfo.formId,
      data: data,
      emphasisKeyword: "keyword1.DATA"
    }
    console.log('==>待发送的模板消息数据：', messageData)
    //调用发送模板消息API
    api_SendTemplateMessage(messageData, (res) => {
      console.log('发送模板消息==>', res)
    })
  },
  confirmDelete:function(){
    this.setData({
      showDeleteBtnConfirm: true
    })
  },
  /*
  * 删除活动
  * */
  delActivity:function (e) {
    let that = this
    console.log(e)
    console.log('formId==>', e.detail.formId)
    console.log('取消原因==>', e.detail.value.reason)
    that.setData({
      formId: e.detail.formId
    })
    let reason = e.detail.value.reason
    if (reason.length > 0) {
      console.log('要取消的活动ID==>', that.data.dataSource.actInfo.actId)
      let result = {
        actId: that.data.dataSource.actInfo.actId,
        reason: reason
      }
      console.log('要提交的取消信息==>', result)
      wx.showModal({
        title: '提示',
        content: '此操作不可撤回，确认删除？',
        success: function(e) {
          api_DeleteActivity(result, (res) => {
            console.log('删除结果==>', res)
            if (res.errmsg == 'ok') {
              //发送模板消息
              // that.sendPassTemplateMessage()
              wx.showToast({
                title: '删除成功',
                icon: 'success',
                duration: 2000
              })
              setTimeout(function () {
                wx.navigateBack({
                  delta: 1
                })
              }, 2000)
            }else{
              $wuxToptips().show({
                icon: 'cancel',
                hidden: false,
                text: '删除失败 - '+ res.errmsg,
                duration: 2000,
                success() {},
              })
            }
          })
        }
      })
    } else {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '请填写活动取消原因',
        duration: 2000,
        success() {},
      })
    }
  }
})
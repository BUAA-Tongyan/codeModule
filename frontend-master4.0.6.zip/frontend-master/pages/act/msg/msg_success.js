// pages/act/msg/msg_success.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    actApply: false,
    actParticipate: false,
    challange: false,
    flea: false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    console.log('传值==>', options.type)
    if (options.type == "actApply") {
      console.log('发起活动=============>')
      this.setData({
        actApply: true,
        actParticipate: false,
        challange: false,
        flea: false,
      })
    }
    if (options.type == "actParticipate") {
      console.log("报名成功-------------------->")
      this.setData({
        actApply: false,
        actParticipate: true,
        actId: options.actId,
        challange: false,
        flea: false,
      })
    }
    if (options.type == "challange") {
      console.log("挑战发起成功-------------------->")
      this.setData({
        actApply: false,
        actParticipate: false,
        challange: true,
        flea: false,
      })
    }
    if (options.type == "flea") {
      console.log("二手发布成功-------------------->")
      this.setData({
        actApply: false,
        actParticipate: false,
        challange: false,
        flea: true,
      })
    }
  },

  goHome: function(e) {
    wx.switchTab({
      url: '/pages/act/home/home',
    })
  },

  stayActApply: function(e) {
    if (this.data.actApply) {
      wx.switchTab({
        url: '/pages/act/actApply/actApply',
      })
    }
    if (this.data.actParticipate) {
      wx.redirectTo({
        url: '/pages/act/actApply/actApply',
      })
    }
    if (this.data.challange) {
      wx.redirectTo({
        url: '/pages/act/14Post/14Post',
      })
    }
    if (this.data.flea) {
      wx.redirectTo({
        url: '/pages/act/itemPost/itemPost',
      })
    }
  },

  // stayActDetail: function(e) {
  //   wx.navigateTo({
  //     url: '../actDetail/actDetail?actId=' + this.data.actId,
  //   })
  // },
})
// pages/act/disSetAdd/disSetAdd.js

let {
  api_AddDiscover
} = require("../../api/getData.js")

import {
  $wuxToptips
} from '../../components/wux-index'

Page({

  /**
   * 页面的初始数据
   */
  data: {
    kind_options: ["场所信息", "社团组织", "微故事"],
    indexType: "场所信息",
    lengthOfInfo: 0
  },
  typeChange: function(e) {

    this.setData({
      indexType: e.detail.value
    })
  },
  getLengthOfInfo: function(e) {
    var length = e.detail.value.length;
    this.setData({
      lengthOfInfo: length
    })
  },
  submitDis: function(e) {
    console.log('要提交的表单数据==>', e)
    var temp = e.detail.value;
    // temp['headImgLink']=""
    var reg = /^https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)$/gi;
    if (temp.title.length <= 5) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '标题不能少于5个字',
        duration: 2000,
        success() { },
      })
    } else if (temp.introduction.length == 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '摘要不能为空',
        duration: 2000,
        success() { },
      })
    } else if (temp.contentLink.length == 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '链接不能为空',
        duration: 2000,
        success() { },
      })
    } else if (temp.type.length == 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '类型不能为空',
        duration: 2000,
        success() { },
      })
    } else if (!reg.test(temp.contentLink)) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '链接格式错误',
        duration: 2000,
        success() { },
      })
    } else {
      temp.introduction = temp.introduction+'\n'+temp.keywords;
      api_AddDiscover(temp, (res) => {
        console.log(res)
        wx.showToast({
          title: '添加成功！',
          icon: 'success',
          duration: 2000
        })
        wx.navigateBack({
          delta: 1
        })
      })

    }

  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})
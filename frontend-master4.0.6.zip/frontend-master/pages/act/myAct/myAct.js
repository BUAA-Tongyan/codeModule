// pages/act/myAct/myAct.js
let {
  api_GetActivitiesSign,
  api_GetActivitiesApply
} = require("../../api/getData.js")

Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentTab: 0,
    dataSource: [],
    dataSource_1: [],
    bottom: -1,
    curPage: 0,
    maxSize: 0,
    bottom_1: -1,
    curPage_1: 0,
    maxSize_1: 0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

    this.getActivitiesSign()
    this.getActivitiesApply()

  },

  getActivitiesSign: function(e) {
    console.log("bottom: ", this.data.bottom)
    if (this.data.bottom >= this.data.maxSize) {
      console.log("==> 到达底部");
      this.setData({
        noDataFlag: true
      })
      wx.hideToast()
      return
    } else {
      /*获取报名的活动列表*/
      let params = {
        page: this.data.curPage + 1,
        size: '6'
      };
      let actPartIn = this.data.dataSource
      api_GetActivitiesSign(params, (res) => {
        wx.showToast({
          title: '数据加载中',
          icon: 'loading',
        });
        console.log("#########--参与的活动--##########", res.data)
        wx.stopPullDownRefresh()
        if (res.data.errcode == 0) {
          wx.hideToast()
          res.data.data.list.forEach(i => {
            // actPartIn.push(i)
            var t = i
            
            if (t.domains[0] == '跳蚤市场') {
              // 题目修改
              if (t.title.search("transaction") != -1) {
                t.headImg = JSON.parse(t.title).headImg
                t.title = '【' + JSON.parse(t.title).transaction + '】' + JSON.parse(t.title).title
              } else {
                t.title = t.title
              }
              // 发起人修改
              if (t.contactName.search("qrcode") != -1) {
                t.contactName = JSON.parse(t.contactName).contactName
              } else {
                t.contactName = t.contactName
              }
              actPartIn.push(t)
            } else {
              actPartIn.push(t)
            }
          })
          this.setData({
            dataSource: actPartIn,
            bottom: actPartIn.length,
            curPage: res.data.data.curPage,
            maxSize: res.data.data.maxSize,
          })
        } else {
          wx.hideToast()
          wx.showModal({
            title: '提示',
            content: res.data.errmsg,
          })
        }
      });
    }
  },

  getActivitiesApply: function(e) {
    console.log("bottom_1: ", this.data.bottom_1)
    if (this.data.bottom_1 >= this.data.maxSize_1) {
      console.log("==> 到达底部");
      this.setData({
        noDataFlag_1: true
      })
      wx.hideToast()
      return
    } else {
      let params_1 = {
        page: this.data.curPage_1 + 1,
        size: '6'
      };
      let actApply = this.data.dataSource_1
      api_GetActivitiesApply(params_1, (res) => {
        wx.showToast({
          title: '数据加载中',
          icon: 'loading',
          duration: 3000,
        });
        console.log("#########--发起的活动--##########", res.data)
        wx.stopPullDownRefresh()
        res.data.data.list.forEach(i => {
          // actApply.push(i)
          var t = i
          if(t.state=="审核未通过") {
            //DO nothing
          }
          else if (t.domains[0] == '跳蚤市场') {
            // 题目修改
            if (t.title.search("transaction") != -1) {
              t.headImg = JSON.parse(t.title).headImg
              t.title = '【' + JSON.parse(t.title).transaction + '】' + JSON.parse(t.title).title
            } else {
              t.title = t.title
            }
            // 发起人修改
            if (t.contactName.search("qrcode") != -1) {
              t.contactName = JSON.parse(t.contactName).contactName
            } else {
              t.contactName = t.contactName
            }
            actApply.push(t)
          } else {
            actApply.push(t)
          }
        })
        this.setData({
          dataSource_1: actApply,
          bottom_1: actApply.length,
          curPage_1: res.data.data.curPage,
          maxSize_1: res.data.data.maxSize,
        })
        wx.hideToast()
      })
    }
  },


  /* 下拉刷新 */
  refresh: function() {
    console.log("==> 下拉刷新")
    if (this.data.currentTab == 0) {
      this.setData({
        bottom: -1,
        dataSource: [],
        curPage: 0,
        maxSize: 0,
      })
      this.getActivitiesSign()
    } else if (this.data.currentTab == 1) {
      this.setData({
        bottom_1: -1,
        dataSource_1: [],
        curPage_1: 0,
        maxSize_1: 0,
      })
      this.getActivitiesApply()
    }
  },
  // 加载更多数据
  loadMore: function() {
    if (this.data.currentTab == 0) {
      this.getActivitiesSign()
    } else {
      this.getActivitiesApply()
    }
  },

  //滑动切换
  swiperTab: function(e) {
    var that = this;
    that.setData({
      currentTab: e.detail.current
    });
  },

  //点击切换
  clickTab: function(e) {

    var that = this;
    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  },

  //点击跳转活动详情页
  onClickTODO: function(e) {
    var $data = e.currentTarget.dataset.index;
    console.log('当前点击的活动ID==>', $data)
    if ($data.actId) {
      wx.navigateTo({
        url: '../actDetail/actDetail?actId=' + $data.actId,
        success: function(res) {
          // success
        },
        fail: function() {
          // fail
        },
        complete: function() {
          // complete
        }
      })
    } else {
      wx.navigateTo({
        url: '../actAuditDetail/actAuditDetail?actApplyFormId=' + $data.actApplyFormId,
        success: function(res) {
          // success
        },
        fail: function() {
          // fail
        },
        complete: function() {
          // complete
        }
      })
    }

  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    this.refresh()
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    this.loadMore()
  },
})
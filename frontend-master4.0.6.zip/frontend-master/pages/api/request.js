let config = require("../../config.js")
var app = getApp();

/*封装get*/
function get(url, callback) {
  let session = wx.getStorageSync("session_id")
  wx.request({
    method: 'GET',
    url: config.service + url,
    header: {
      'hellobuaa': wx.getStorageSync("token"),
      "Cookie": "SESSION=" + session
    },
    success: (res) => {
      callback(res)
    },
  })
}

/*封装post*/
function post(url, body, callback) {
  let session = wx.getStorageSync("session_id")
  wx.request({
    method: 'POST',
    url: config.service + url,
    data: body,
    header: {
      'content-type': 'application/x-www-form-urlencoded',
      'hellobuaa': wx.getStorageSync("token"),
      "Cookie": "SESSION=" + session
    },
    success: (res) => {
      callback(res.data)
    },
  })
}

/*文件上传 */
function upload(url, body, filePath, name, callback) {
  let session = wx.getStorageSync("session_id")
  wx.uploadFile({
    url: config.service + url,
    filePath: filePath,
    // name: 'imgFile',
    // name: 'buaaCardImg',
    name: name,
    formData: body,
    header: {
      'content-type': 'multipart/form-data',
      'hellobuaa': wx.getStorageSync("token"),
      "Cookie": "SESSION=" + session
    },
    success: function(res) {
      callback(res.data)
    },
    fail: function(res) {
      callback(res.data)
    },
    // complete: function(res) {
    //   callback(res)
    // }
  })
}

module.exports = {
  get: get,
  post: post,
  upload: upload
}
/* 
 *api：所有与获取数据相关的api均可写在此文档中，注意添加注释，便于区分和定位
 *get，post注意调用格式
 *upload 注意name参数
 *为了查找方便，后续可以考虑将api按功能逻辑拆分到过个文件中
 */
var app = getApp()
let config = require("../../config.js")
let {
  get,
  post,
  upload
} = require("./request.js")

/**************************************百日挑战相关API**********************************************/

/**
 * 获取该次打卡活动详细信息
 * @param act_id 活动id
 * @returns {'status': 200, 'data': data}
 */
const api_GetHundredRegisterActDetail = (act_id, callback) => {
  let url = '/buaa/v2/api/100day_game/act_info' + '?act_id=' + act_id
  get(url, (res) => {
    callback(res.data)
  })
};

/**
 * 获取活动类型
 */
const api_GetHundredActType = (callback) => {
  let url = '/buaa/v2/api/100day_game/act_type'
  get(url, (res) => {
    callback(res.data)
  })
};

/**
 * 获取活动列表
 */
const api_GetHundredActList = (callback) => {
  let url = '/buaa/v2/api/100day_game/user_act'
  get(url, (res) => {
    callback(res.data)
  })
};

/**
 * 发起活动
 * @param act_form: 值为json序列化后的活动表单
 * @returns {'status': 200/0, 'data': data}
 */
const api_PostHundredAct = (act_form, callback) => {
  let url = '/buaa/v2/api/100day_game/add_act'
  post(url,act_form, (res) => {
    callback(res)
  })
};

/**
 * 签到
 * @param params: {act_id:活动id,image_url:打卡图片链接}
 * @returns {'status': 200/0, 'data': data}
 */
const api_HundredSign = (params,callback) => {
  let url ='/buaa/v2/api/100day_game/record_act'
  post(url, params,(res)=>{
    callback(res)
  })
}

/**************************************用户信息相关API**********************************************/

/* 获取用户权限 */
const api_GetAllAuthorities = (callback) => {
  let url = '/buaa/uc/getAllAuthorities'
  get(url, (res) => {
    callback(res)
  })
};


/*通过token获取用户信息 */
const api_uc_GetInfoByToken = (callback) => {
  let url = '/buaa/uc/getUserInfoByToken'
  get(url, (res) => {
    callback(res)
  })
}

/* 手动更新用户头像 */
const api_uc_GetNewHeadImg = (param, callback) => {
  let url = '/buaa/uc/getNewHeadImg'
  post(url, param, (res) => {
    callback(res)
  })
}

/* 账户迁移 */
// param: form {手机号，姓名，学号}
const api_uc_MigrateFromV2 = (param, callback) => {
  let url = '/buaa/uc/migrateFromV2'
  post(url, param, (res) => {
    callback(res)
  })
}
/*************************************获取用户真实信息**********************************************/
const api_GetRealUserInfo = (param, callback) => {
  let url = '/buaa/autho/wx_app_real_auth'
  post(url, param, (res) => {
    callback(res)
  })
}


/**
 * 获取账户状态,待审核，审核通过等
 * @returns {*}
 */
const api_GetUserState = (callback) => {
  let url = '/buaa/act/getUserState'
  get(url, (res) => {
    callback(res)
  })
}

/**
 * 获取积分变更记录
 * @param page
 * @param size
 * @returns {*}
 */
const api_GetPointChangeRecords = (params, callback) => {
  let url = '/buaa/act/getPointChangeRecords' + '?page=' + params.page + '&size=' + params.size
  get(url, (res) => {
    callback(res.data)
  })
}

/**
 * 获取信用分变更记录
 * @param page
 * @param size
 * @returns {*}
 */
const api_GetCreditChangeRecords = (params, callback) => {
  let url = '/buaa/act/getCreditChangeRecords' + '?page=' + params.page + '&size=' + params.size
  get(url, (res) => {
    callback(res.data)
  })
}


/**
 * 分享活动增加积分
 * @actId 必须是对象形式
 * @returns {*}
 */
const api_shareAct = (actId, callback) => {
  let url = '/buaa/act/shareAct'
  post(url, actId, (res) => {
    callback(res)
  })
}


/**************************************首页微沙龙相关API**********************************************/
/* 获取主页活动列表@暂存到全局变量中，刷新时更新 */
const api_GetActList = (params, callback) => {
  let url = '/buaa/act/getActList' + '?page=' + params.page + '&size=' + params.size + '&actListType=1'
  get(url, (res) => {
    callback(res.data)
  })
}

/**
 * 更改喜欢状态
 * @param actId
 * @returns {*}
 */
const api_LikeAct = (param, callback) => {
  let url = '/buaa/act/toggleFavorite'
  post(url, param, (res) => {
    callback(res)
  })
}
/**************************************活动搜索相关API**********************************************/
/**
 * 活动搜索
 * @param keywords
 * @param searchType
 * @param page
 * @param size
 * @returns {*}
 */
const api_SearchAct = (params, callback) => {
  let url = '/buaa/act/searchAct' + '?keywords=' + params.keywords + '&searchType=' + params.searchType + '&page=' + params.page + '&size=' + params.size
  get(url, (res) => {
    callback(res.data)
  })
}


/**************************************学术活动相关API**********************************************/
/* 学术主页活动列表 */
const api_GetAcadActListOn = (params, callback) => {
  let url = '/buaa/act/getActList' + '?page=' + params.page + '&size=' + params.size + '&actListType=2&state=1'
  get(url, (res) => {
    callback(res.data)
  })
}
/* 获取学术主页活动列表 */
const api_GetAcadActListOff = (params, callback) => {
  let url = '/buaa/act/getActList' + '?page=' + params.page + '&size=' + params.size + '&actListType=2&state=0'
  get(url, (res) => {
    callback(res.data)
  })
}

/* 获取活动详情 */
const api_GetActivityInfo = (params, callback) => {
  let url = '/buaa/act/getActivityInfo' + '?actId=' + params
  get(url, (res) => {
    callback(res)
  })
}


/**************************************发起活动相关API**********************************************/
/**
 * 获取发起活动表单
 */
const api_GetActApplyForm = (callback) => {
  let url = '/buaa/act/getActApplyForm'
  get(url, (res) => {
    callback(res)
  })
}
/**
 * 发起新活动
 */
const api_ApplyNewAct = (form, callback) => {
  let url = '/buaa/act/applyNewAct'
  //console.log(form.get('type'))
  post(url, form, (res) => {
    callback(res)
  })
}


/**************************************活动审核相关API**********************************************/
/**
 * 获取未审核活动列表
 * @param page
 * @param size
 */
const api_GetActivitiesToAudit = (params, callback) => {
  let url = '/buaa/act/getActivitiesToAudit' + '?page=' + params.page + '&size=' + params.size
  get(url, (res) => {
    callback(res)
  })
}

/**
 * 获取已审核活动列表
 * @param page
 * @param size
 */
const api_GetActivitiesAudited = (params, callback) => {
  let url = '/buaa/act/getActivitiesAudited' + '?page=' + params.page + '&size=' + params.size
  get(url, (res) => {
    callback(res)
  })
}

/**
 * 获取未审核活动详情
 * @param actApplyFormId
 */
const api_GetApplyFormDetail = (params, callback) => {
  let url = '/buaa/act/getActApplyFormDetail?actApplyFormId=' + params
  get(url, (res) => {
    callback(res)
  })
}

/**
 * 提交活动审核结果（审核通过）
 * @param result
 */
const api_DealPassAudit = (result, callback) => {
  let url = '/buaa/act/dealPassAudit'
  post(url, result, (res) => {
    callback(res)
  })
}

/**
 * 提交活动审核结果（审核不通过）
 * @param result
 */
const api_DealRejectAudit = (result, callback) => {
  let url = '/buaa/act/dealRejectAudit'
  post(url, result, (res) => {
    callback(res)
  })
}

/**************************************我的活动相关API**********************************************/
/**
 * 获取我报名的活动列表
 * @param page
 * @param size
 * @returns {*}
 */
const api_GetActivitiesSign = (params, callback) => {
  let url = '/buaa/act/getParticipatedActList' + '?page=' + params.page + '&size=' + params.size
  get(url, (res) => {
    callback(res)
  })
}

/**
 * 获取我发起的活动列表
 * @param page
 * @param size
 * @returns {*}
 */
const api_GetActivitiesApply = (params, callback) => {
  let url = '/buaa/act/getMyApply' + '?page=' + params.page + '&size=' + params.size
  get(url, (res) => {
    callback(res)
  })
}

/**************************************活动签到相关API**********************************************/
/**
 * 获取可签到的活动列表
 * @returns {*}
 */
const api_GetConsumeActList = (callback) => {
  let url = '/buaa/act/getConsumeActList'
  get(url, (res) => {
    callback(res)
  })
}

/**
 * 获取参与人列表
 * @param actId
 * @param page
 * @param size
 * @returns {*}
 */
const api_GetParticipatedList = (params, callback) => {
  let url = '/buaa/act/getParticipatedUserList' + '?actId=' + params.actId + '&page=' + params.page + '&size=' + params.size
  get(url, (res) => {
    callback(res)
  })
}


/**************************************发现相关API**********************************************/
/* 获取发现列表 */
const api_GetDiscoverList = (params, callback) => {
    let url = '/buaa/act/get_find_content_list' + '?page=' + params.page + '&size='
        + params.size + '&type=' + (params.type||-1) + '&search=' + (params.search||'');
    get(url, (res) => {
        callback(res)
    })
}

/*新增发现 */
const api_AddDiscover = (form, callback) => {
  let url = '/buaa/act/add_find_content'
  //console.log(form.get('type'))
  post(url, form, (res) => {
    callback(res)
  })
}
/* 删除发现*/
const api_RemoveDiscover = (form, callback) => {
  let url = '/buaa/act/remove_find_content'
  post(url, form, (res) => {
    callback(res)
  })
}

/**************************************用户审核相关API**********************************************/
/**
 * 获取已审核用户表单
 * @param page
 * @param size
 */
const api_GetAuditDoneList = (params, callback) => {
  let url = '/buaa/uc/getUsersAudited' + '?page=' + params.page + '&size=' + params.size
  get(url, (res) => {
    callback(res)
  })
}
/**
 * 获取未审核用户表单
 * @param page
 * @param size
 */
const api_GetAuditTODOList = (params, callback) => {
  let url = '/buaa/uc/getUsersToAudit' + '?page=' + params.page + '&size=' + params.size
  get(url, (res) => {
    callback(res)
  })
}

/**
 * 获取审核列表用户详情
 * @param applyId
 *
 */
const api_GetRegisterFormById = (params, callback) => {
  let url = '/buaa/uc/getRegisterFormById?applyId=' + params
  get(url, (res) => {
    callback(res)
  })
}


/**
 * 提交用户审核结果（审核通过）
 * @param result
 */
const api_SubmitPassAuditResult = (result, callback) => {
  let url = '/buaa/uc/passAudit'
  post(url, result, (res) => {
    callback(res)
  })
}

/**
 * 提交用户审核结果（审核不通过）
 * @param result
 */
const api_SubmitRejectAuditResult = (result, callback) => {
  let url = '/buaa/uc/rejectAudit'
  post(url, result, (res) => {
    callback(res)
  })
}


/**************************************轮播设置相关API**********************************************/
/* 获取轮播图：首页和轮播设置页 */
const api_GetAllBanners = (callback) => {
  // if (app.allBanners) {
  //   callback(app.allBanners)
  // } else {
  get('/buaa/act/getAllBanners', (res) => {
    // app.allBanners = res.data.data
    // callback(app.allBanners)
    callback(res.data.data)
  })
  // }
};

/* 删除轮播*/
const api_DeleteBanner = (bannerId, callback) => {
  let url = '/buaa/act/removeBanner'
  var params = {
    'bannerId': bannerId
  }
  post(url, params, (res) => {
    callback(res)
  })
}

/*增加轮播 */
const api_AddBanner = (form, imgPath, callback) => {
  let name = 'imgFile'
  let url = '/buaa/act/addBanner'
  upload(url, form, imgPath, name, (res) => {
    callback(res)
  })
}

/*发送反馈 */
const api_AddFeed = (form, callback) => {
  let url = '/buaa/act/add_feed'
  post(url, form, (res) => {
    callback(res)
  })
}

/*************************************发送活动平台模板消息，审核活动通知****************************************/
const api_SendTemplateMessage = (form, callback) => {
  let url = '/buaa/act/sendTemplateMessage'
  post(url, form, (res) => {
    callback(res)
  })
}

/*************************************发送用户平台模板消息，审核用户通知***************************************/
const api_uc_SendTemplateMessage = (form, callback) => {
  let url = '/buaa/uc/sendTemplateMessage'
  post(url, form, (res) => {
    callback(res)
  })
}


/*************************************取消活动**********************************************/
/**
 * 取消活动
 * @param form
 * @returns {*}
 */
const api_DeleteActivity = (param, callback) => {
  let url = '/buaa/act/cancelActivity'
  post(url, param, (res) => {
    callback(res)
  })
}

/**
 * 获取卡券信息
 * @param cardId
 * @returns {*}
 */
const api_GetCardExt = (params, callback) => {
  let url = '/buaa/wx/getCardExt' + '?cardId=' + params.cardId + '&amount=' + params.amount
  get(url, (res) => {
    callback(res)
  })
}

/**
 * 取消报名
 * @param form
 */
const api_refundTicket = (actId, callback) => {
  let url = '/buaa/act/refundTicket'
  post(url, actId, (res) => {
    callback(res)
  })
}


/**
 * 提交用户注册信息
 * @param form
 */
const api_SubmitUserInfo = (form, imgPath, callback) => {
  let name = 'buaaCardImg'
  let url = '/buaa/uc/register'
  upload(url, form, imgPath, name, (res) => {
    callback(res)
  })
}



/**
 * 提交用户更改的信息
 * @param form
 */
const api_EditUserInfo = (form, imgPath, callback) => {
  let name = 'buaaCardImg'
  let url = '/buaa/uc/editUserInfo'
  upload(url, form, imgPath, name, (res) => {
    callback(res)
  })
}


/**
 * 发送人机响应及手机号码
 * @params {ticket}
 * @params {randstr}
 * @params {phone}
 */
const api_VerifyByPhone = (params, callback) => {
  let url = '/buaa/uc/sendPhoneVcode'
  post(url, params, (res) => {
    callback(res)
  })
}


/**
 * 注册页面，获取学院列表
 */
const api_GetRegisterFormData = (callback) => {
  console.log("获取学院列表api");
  let url = '/buaa/uc/getRegisterFormData'
  get(url, (res) => {
    callback(res)
  })
}


/**
 * 核销卡券
 * @param formData
 * @returns {*}
 */
const api_SignIn = (form, callback) => {
  let url = '/buaa/act/signIn'
  post(url, form, (res) => {
    callback(res)
  })
}

/**
 * 用户自主核销卡券
 * @param formData
 * @returns {*}
 */
const api_SignInSelf = (form, callback) => {
  let url = '/buaa/act/signInSelf'
  post(url, form, (res) => {
    callback(res)
  })
}

/**
 * 通过Token向服务器请求用户信息
 * @param {String} state
 * @param {String} code
 */
const api_wx_getInfoByToken = (callback) => {
  let url = '/buaa/autho/getSimpleUnionInfoByToken'
  get(url, (res) => {
    callback(res)
  })
}

//注意每个函数都要在此声明，为了便于与普通函数区分，推荐使用前缀 api_
module.exports = {
  api_GetHundredRegisterActDetail: api_GetHundredRegisterActDetail,
  api_GetHundredActType: api_GetHundredActType,
  api_GetHundredActList: api_GetHundredActList,
  api_HundredSign: api_HundredSign,
  api_PostHundredAct: api_PostHundredAct,
  api_GetAllBanners: api_GetAllBanners,
  api_GetAllAuthorities: api_GetAllAuthorities,
  api_GetActList: api_GetActList,
  api_GetAcadActListOn: api_GetAcadActListOn,
  api_GetAcadActListOff: api_GetAcadActListOff,
  api_GetActivityInfo: api_GetActivityInfo,
  api_GetDiscoverList: api_GetDiscoverList,
  api_GetActivitiesSign: api_GetActivitiesSign,
  api_GetActivitiesApply: api_GetActivitiesApply,
  api_GetActivitiesToAudit: api_GetActivitiesToAudit,
  api_GetActivitiesAudited: api_GetActivitiesAudited,
  api_AddDiscover: api_AddDiscover,
  api_RemoveDiscover: api_RemoveDiscover,
  api_GetActApplyForm: api_GetActApplyForm,
  api_ApplyNewAct: api_ApplyNewAct,
  api_AddBanner: api_AddBanner,
  api_DeleteBanner: api_DeleteBanner,
  api_uc_GetInfoByToken: api_uc_GetInfoByToken,
  api_GetApplyFormDetail: api_GetApplyFormDetail,
  api_DealPassAudit: api_DealPassAudit,
  api_DealRejectAudit: api_DealRejectAudit,
  api_GetConsumeActList: api_GetConsumeActList,
  api_LikeAct: api_LikeAct,
  api_GetAuditDoneList: api_GetAuditDoneList,
  api_GetAuditTODOList: api_GetAuditTODOList,
  api_SearchAct: api_SearchAct,
  api_GetRegisterFormById: api_GetRegisterFormById,
  api_GetParticipatedList: api_GetParticipatedList,
  api_GetUserState: api_GetUserState,
  api_GetPointChangeRecords: api_GetPointChangeRecords,
  api_GetCreditChangeRecords: api_GetCreditChangeRecords,
  api_AddFeed: api_AddFeed,
  api_SendTemplateMessage: api_SendTemplateMessage,
  api_uc_SendTemplateMessage: api_uc_SendTemplateMessage,
  api_GetRealUserInfo: api_GetRealUserInfo,
  api_DeleteActivity: api_DeleteActivity,
  api_GetCardExt: api_GetCardExt,
  api_refundTicket: api_refundTicket,
  api_SubmitUserInfo: api_SubmitUserInfo,
  api_SignIn: api_SignIn,
  api_SignInSelf: api_SignInSelf,
  api_VerifyByPhone: api_VerifyByPhone,
  api_SubmitPassAuditResult: api_SubmitPassAuditResult,
  api_SubmitRejectAuditResult: api_SubmitRejectAuditResult,
  api_EditUserInfo: api_EditUserInfo,
  api_shareAct: api_shareAct,
  api_wx_getInfoByToken: api_wx_getInfoByToken,
  api_GetRegisterFormData: api_GetRegisterFormData,
  api_uc_GetNewHeadImg: api_uc_GetNewHeadImg,
  api_uc_MigrateFromV2: api_uc_MigrateFromV2

}
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    // this.getHeight();
  },
  
  // 电影序幕滚动效果
  // getHeight() {
  //   var obj = new Object();
  //   //创建节点选择器
  //   var query = wx.createSelectorQuery();
  //   query.select('.container').boundingClientRect()
  //   query.select('.list').boundingClientRect()
  //   query.exec((res) => {
  //     obj.container = res[0].height; // 框的height
  //     obj.list = res[1].height; // list的height
  //     // return obj;
  //     this.util(obj);
  //   })
  // },
  // util: function(obj) {
  //   console.log(obj);
  //   console.log(-obj.list);
  //   var continueTime = (parseInt(obj.list / obj.container) + 1) * 15000;
  //   var setIntervalTime = 500 + continueTime;

  //   var animation = wx.createAnimation({
  //     duration: 2000, //动画时长
  //     timingFunction: "linear", //线性
  //     delay: 0 //0则不延迟
  //   });
  //   this.animation = animation;
  //   animation.translateY(obj.container).step({
  //     duration: 500,
  //     timingFunction: 'step-start'
  //   }).translateY(-obj.list).step({
  //     duration: continueTime
  //   });
  //   this.setData({
  //     animationData: animation.export()
  //   })
  //   setInterval(() => {
  //     animation.translateY(obj.container).step({
  //       duration: 500,
  //       timingFunction: 'step-start'
  //     }).translateY(-obj.list).step({
  //       duration: continueTime
  //     });
  //     this.setData({
  //       animationData: animation.export()
  //     })
  //   }, setIntervalTime)
  // },
})
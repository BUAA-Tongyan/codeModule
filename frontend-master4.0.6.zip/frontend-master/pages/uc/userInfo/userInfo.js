var app = getApp()
let {
  api_uc_GetInfoByToken,
  api_uc_GetNewHeadImg
} = require("../../api/getData.js")

Page({

  /**
   * 页面的初始数据
   */
  data: {},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

    // if (app.globalData.userNotSignUp) {
    //   wx.showModal({
    //     title: '提示',
    //     content: '平台尚无您的个人信息！',
    //     confirmText: "前往注册",
    //     cancelText: "随便逛逛",
    //     success(res) {
    //       if (res.confirm) {
    //         console.log('用户点击确定')
    //         wx.navigateTo({
    //           url: '../../act/register/register',
    //         })
    //       } else if (res.cancel) {
    //         console.log('用户点击取消')
    //         wx.reLaunch({
    //           url: '../../act/home/home',
    //         })
    //       }
    //     }
    //   })
    // }

    if (app.globalData.userInfoByToken) {
      console.log('userInfoByToken###############', app.globalData.userInfoByToken)
      this.setData({
        userInfo: app.globalData.userInfoByToken,
        hasUserInfo: true
      })
    }

  },

  goUserInfoEdit: function() {
    wx.navigateTo({
      url: '../../uc/userEditInfo/userEditInfo',
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    if (app.globalData.userNotSignUp) {
      wx.showModal({
        title: '提示',
        content: '平台尚无您的信息！',
        confirmText: "前往注册",
        cancelText: "随便逛逛",
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
            wx.navigateTo({
              url: '../../act/register/register',
            })
          } else if (res.cancel) {
            console.log('用户点击取消')
            wx.reLaunch({
              url: '../../act/home/home',
            })
          }
        }
      })
    }
    // console.log("全局信息==>", app.globalData)
    // // 如果审核通过用户信息，则
    // if (app.globalData.refreshUserInfoDetail) {
    //   /*获取用户信息并存在全局变量中*/
    //   api_uc_GetInfoByToken((res) => {
    //     app.globalData.userInfoByToken = res.data.data
    //     callback(null, res)
    //     this.setData({
    //       userInfo: app.globalData.userInfoByToken,
    //       hasUserInfo: true
    //     })
    //   })
    //   app.globalData.refreshUserInfoDetail = false
    // }

    wx.startPullDownRefresh()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

    /*获取用户信息并存在全局变量中*/
    api_uc_GetInfoByToken((res) => {
      app.globalData.userInfoByToken = res.data.data
      this.setData({
        userInfo: app.globalData.userInfoByToken,
        hasUserInfo: true
      })
    })
    app.globalData.refreshUserInfoDetail = false
    wx.stopPullDownRefresh()

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },

  getNewHeadImg: function() {
    // wx.startPullDownRefresh()
    let param = ''
    api_uc_GetNewHeadImg(param, (res) => {
      console.log('更新头像后的用户信息==>', res.data)
      app.globalData.userInfoByToken = res.data
      this.setData({
        userInfo: app.globalData.userInfoByToken,
        hasUserInfo: true
      })
    })
    app.globalData.refreshUserInfoDetail = false
    wx.showToast({
      title: '头像更新成功',
    })
    // wx.stopPullDownRefresh()
  }

})
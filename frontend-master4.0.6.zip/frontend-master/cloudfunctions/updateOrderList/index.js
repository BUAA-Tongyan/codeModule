// 云函数入口文件
const cloud = require('wx-server-sdk')
cloud.init({
  env: 'server-0d9db'
})
const db = cloud.database()
// 云函数入口函数
exports.main = async(e, ctx) => {
  let {
    id,adminName
  } = e
  console.log('云端：拿到订单的id',id)
  try {
    return await db.collection('order')
      .doc(id).update({
        data: {
          isFinished: true,
          adminName:adminName
        }
      })
  } catch (e) {
    console.log(e)
  }
}
// 云函数入口文件
const cloud = require('wx-server-sdk')
cloud.init({
  env: 'server-0d9db'
})
const db = cloud.database()
const _ = db.command
// 云函数入口函数
exports.main = async(e, ctx) => {
  let {
    buaaId,
    cart
  } = e
  let len = cart.length
  // 更新库存（每一条记录减去1）
  for (i = 0; i < len; i++) {
    let id = cart[i]._id
    await db.collection('pointsExchange').doc(id).update({
      data: {
        count: _.inc(-cart[i].num)
      }
    })
  }
  return 'done'
}
let app = getApp()
Component({
    externalClasses: [ "parent-class" ],
    properties: {
        title: {
          type: String,
          value: ''
        },
        topClass: {
          type: String,
          value: ""
        },
        titleClass: {
          type: String,
          value: ""
        },
        titleTextClass: {
          type: String,
          value: ""
        },
        showBack: {
          type: Boolean,
          value: true
        },
        showBackText: {
          type: String,
          value: "返回"
        },
        showHome: {
          type: Boolean,
          value: true
        },
        homePath: {
          type: String,
          value: ""
        },
        homeOpenType: {
          type: String,
          value: ""
        },
        background: {
          type:String,
          value: ''
        },
        showShadow: {
          type:Boolean,
          value: true
        },
        buttonColor:{
          type:String,
          value: ''
        },
    },
  pageLifetimes: {
    // 组件所在页面的生命周期函数
    show: function () {
      var t = this
      let { showNavigationBarLoading, hideNavigationBarLoading } = Object.assign({}, wx)
      wx._showNavigationBarLoading || wx.__defineGetter__('showNavigationBarLoading', function () {
        wx._showNavigationBarLoading = 1
        return function (o) {
          var p = getCurrentPages().pop() || {},
            cb = p ? p.selectComponent('#c-bar') : false
          cb && cb.setData && cb.setData({
            loading: !0
          })
          
          return showNavigationBarLoading(o)
        }
      })
      wx._hideNavigationBarLoading || wx.__defineGetter__('hideNavigationBarLoading', function () {
        wx._hideNavigationBarLoading = 1
        return function (o) {
          var p = getCurrentPages().pop() || {},
            cb = p ? p.selectComponent('#c-bar') : false
          cb && cb.setData && cb.setData({
            loading: !1
          })
          return hideNavigationBarLoading(o)
        }
      })
    },
    hide: function () { },
    resize: function () { },
  },
    data: {
      custom:wx.getMenuButtonBoundingClientRect(),
      cBarHeight:68,
      cBarTitleTop:20,
      cBarTitleHeight:68,
      cBarTitlePaddingTop:20,
      isiPad: /^ipad/i.test(app.globalData.systemInfo.model || ""),
      isApple: /^iPhone/i.test(app.globalData.systemInfo.model || ""),
      canvasHeight: 300,
      canvasWidth: 300,
      backgroundImg: '',
      iconColor:"",
    },
    observers: {
      "homePath": function (p) {
        this.setData({
          hPath: p ? p : '/pages/act/home/home'
        })
      },
      "homeOpenType": function (t) {
        this.setData({
          hOpenType: t ? t : 'switchTab'
        })
      }
    },
    ready: function() {
      let t = this, ps = getCurrentPages()
      t.setData({
        hPath: t.data.homePath ? t.data.homePath : '/pages/act/home/home',
        hOpenType: t.data.homeOpenType ? t.data.homeOpenType : 'switchTab',
        navBackType: ps.length <= 1 ? 'switchTab' : 'navigateBack',
        title: t.data.title || app.globalData.appName
      })
      
      wx.getSystemInfo({
        success: e => {
          let sH = e.statusBarHeight,
          // bH = t.data.custom.bottom + t.data.custom.top - sH
          bH = t.data.custom.bottom*2 - t.data.custom.height - sH
          bH = bH < t.data.cBarHeight ? t.data.cBarHeight : bH
          ps[ps.length-1].setData({
            addMiniTop: t.data.custom.top+t.data.custom.height+10,
            addMiniRight: Math.ceil(3*t.data.custom.width/4)-6
          })
          wx.setStorageSync('cBarHeight',t.data.height || bH)
          t.setData({
            cBarHeight: t.data.height || bH,
            cBarTitleTop: t.data.titleTop || sH, // 标题的高度
            cBarTitleHeight: t.data.titleHeight || bH,
            cBarTitlePaddingTop: t.data.titlePaddingTop || sH
          })
        }
      })

     /*当前风格*/
     
     let style = wx.getStorageSync('style')
     console.log(style)
     switch(style) {
       case "blue" :
         this.setData(
           {
             backgroundImg : "https://7365-server-0d9db-1259368714.tcb.qcloud.la/images_background/navi_back_blue.jpg?sign=1509427a8d95c59e05ddb226543342a3&t=1600340593",
             iconColor:"white",
           }
         );
         break;
       case "lightblue":
         this.setData(
           {
             backgroundImg : "https://7365-server-0d9db-1259368714.tcb.qcloud.la/images_background/navi_back_light_blue.jpg?sign=78b4a3e2fae13a453c8a2c78c08b1017&t=1600340558",
             iconColor:"white",
           }
         );
 
         break;
       case "red":
         this.setData(
           {
             backgroundImg : "https://7365-server-0d9db-1259368714.tcb.qcloud.la/images_background/navi_back_red.jpg?sign=decadea18d4d8b43c4b7a944359447a0&t=1600340606",
             iconColor:"white",
           }
         );
         break;
       case "black":
         this.setData(
           {
             backgroundImg : "https://7365-server-0d9db-1259368714.tcb.qcloud.la/images_background/navi_back.jpg?sign=487e6afd82ad0e464f96f3b51315d528&t=1600340652",
            iconColor:"white",
           }
         );
         break;
       default:
 
         break;
     }
    },
    methods: {
    }
});
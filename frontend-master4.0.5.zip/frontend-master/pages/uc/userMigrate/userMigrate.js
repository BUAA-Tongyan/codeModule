// pages/uc/userMigrate/userMigrate.js
var app = getApp()
let {
  api_uc_GetInfoByToken,
  api_uc_MigrateFromV2
} = require("../../api/getData.js")
import {
  $wuxToptips
} from '../../components/wux-index'

Page({

  /**
   * Page initial data
   */
  data: {

  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function(options) {

  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function() {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function() {

  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function() {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function() {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function() {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function() {

  },

  formSubmit: function(e) {
    var temp = e.detail.value;
    console.log('要提交的表单==>', temp)

    if (temp.name == '') {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '姓名不能为空',
        duration: 2000,
        success() {},
      })
    } else if (temp.buaaId == '') {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '学号或工号不能为空',
        duration: 2000,
        success() {},
      })
    } else if (temp.phone == '') {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '手机号不能为空',
        duration: 2000,
        success() {},
      })
    } else {
      api_uc_MigrateFromV2(temp, (res) => {
        console.log('账户迁移结果==>', res)
        if (res.errmsg == 'ok') {
          wx.showToast({
            title: '账号迁移成功！',
            icon: 'success',
          })
          setTimeout(function() {
            wx.reLaunch({
              url: '../../act/home/home',
            })
          }, 2000)
        } else {
          wx.showModal({
            title: '账号迁移失败！',
            content: res.errmsg + '！请修改信息重试，若仍不成功请联系管理员！',
          })
          // setTimeout(function() {
          //   wx.navigateBack({
          //     delta: 1
          //   })
          // }, 2000)
        }
      })

    }

  },
})
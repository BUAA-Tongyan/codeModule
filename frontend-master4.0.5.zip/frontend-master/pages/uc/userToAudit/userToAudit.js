// pages/uc/userToAudit/userToAudit.js
var app = getApp()
let {
  api_GetAuditTODOList,
  api_uc_SendTemplateMessage
} = require("../../api/getData.js")

Page({

  /**
   * 页面的初始数据
   */
  data: {
    rejectFlag: false,
    rejectReason: '',
    // dataSource:[],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.getAuditTODOList(1, 10);
  },

  /*获取待审核用户列表*/
  getAuditTODOList: function(p, s) {
    let params = {
      page: p,
      size: s
    };
    api_GetAuditTODOList(params, (res) => {
      console.log("#########--获取待审核用户列表--##########", res.data.data.list)
      this.setData({
        dataSource: res.data.data.list
      })
    })
    // if(this.data.dataSource.length == 0){
    //   setTimeout(function () {
    //     wx.navigateBack({
    //       delta: 1
    //     })
    //   }, 2000)
    // }
  },

  /*点击进入审核详情*/
  onClickDONE: function(e) {
    console.log('当前点击用户的applyId==>', e.currentTarget.dataset.index)
    wx.navigateTo({
      url: '../userAuditDetail/userAuditDetail?applyId=' + e.currentTarget.dataset.index
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    if (app.globalData.refreshUserToAuditList) {
      this.getAuditTODOList(1, 10)
      app.globalData.refreshUserToAuditList = false
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})
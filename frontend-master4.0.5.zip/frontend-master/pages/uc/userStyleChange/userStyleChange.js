// // pages/uc/userStyleChange/userStyleChange.js
// Page({

//   /**
//    * 页面的初始数据
//    */
//   data: {

//   },

//   /**
//    * 生命周期函数--监听页面加载
//    */
//   onLoad: function (options) {

//   },

//   /**
//    * 生命周期函数--监听页面初次渲染完成
//    */
//   onReady: function () {

//   },

//   /**
//    * 生命周期函数--监听页面显示
//    */
//   onShow: function () {

//   },

//   /**
//    * 生命周期函数--监听页面隐藏
//    */
//   onHide: function () {

//   },

//   /**
//    * 生命周期函数--监听页面卸载
//    */
//   onUnload: function () {

//   },

//   /**
//    * 页面相关事件处理函数--监听用户下拉动作
//    */
//   onPullDownRefresh: function () {

//   },

//   /**
//    * 页面上拉触底事件的处理函数
//    */
//   onReachBottom: function () {

//   },

//   /**
//    * 用户点击右上角分享
//    */
//   onShareAppMessage: function () {

//   },
//   change:function(e){
//     let style = e.currentTarget.id
//     let currentStyle = wx.getStorageSync('style')
//     if (style != currentStyle){
//       wx.setStorageSync('style', style)

//       wx.reLaunch(      {
//         url: '../../act/home/home'
//       })


//     }
//   },
// })

const app = getApp()
const $ = require('../../../utils/promisify')
Page({
  changeColor: function (e) {
    console.log(e.detail.value)
    app.store.setState({
      mainColor: e.detail.value
    })
    this.setData({
      mainColor: e.detail.value
    })
    wx.setStorageSync('mainColor', e.detail.value)
  },
  saveColorInTheCloud: function () {
    wx.showLoading({
      title: '发送请求中...'
    })
    const db = wx.cloud.database()
    const nickName = wx.getStorageSync('commonUserInfo').nickName || '未授权用户'
    const trueName = wx.getStorageSync('tongyanUserInfo').nickname || '未注册用户'
    const name = nickName + '---' + trueName
    const openId = wx.getStorageSync('openId')
    const time = new Date()

    db.collection('userSkins').doc(openId)
      .set({
        data: {
          color: app.store.$state.mainColor,
          openId,
          name,
          time
        }
      })
      .then(res => {
        wx.hideLoading()
        console.log('获取:设置or更新', res)
        if (res.stats.created) {
          $.remind('设置成功!')
        } else {
          $.remind('修改成功!')
        }
      })
  },
  data: {
    colorGroup: [{
        color: 'blue',
        text: '海蓝'
      }, {
        color: 'pink',
        text: '桃粉'
      },
      {
        color: 'cyan',
        text: '天青'
      },
      {
        color: 'yellow',
        text: '明黄'
      },
      {
        color: 'purple',
        text: '姹紫'
      },
      {
        color: 'orange',
        text: '桔橙'
      },
      {
        color: 'mauve',
        text: '木槿'
      },
      {
        color: 'grey',
        text: '玄灰'
      },
      {
        color: 'gradual-blue',
        text: '靛青(渐变)'
      },
      {
        color: 'gradual-pink',
        text: '霞彩(渐变)'
      },
      {
        color: 'gradual-green',
        text: '翠柳(渐变)'
      },
      {
        color: 'gradual-orange',
        text: '鎏金(渐变)'
      },
      {
        color: 'gradual-purple',
        text: '惑紫(渐变)'
      },
      {
        color: 'pink light',
        text: '浅粉'
      },
      {
        color: 'blue light',
        text: '浅蓝'
      },
      {
        color: 'red light',
        text: '浅红'
      },
      {
        color: 'orange light',
        text: '浅橙'
      },
      {
        color: 'purple light',
        text: '浅紫'
      }, {
        color: 'brown light',
        text: '浅褐'
      },
    ]
  },
})
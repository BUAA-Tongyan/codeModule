import {api_SignInSelf} from "../../api/getData";

var app = getApp();
Page({
    /**
     * 页面的初始数据
     */
    data: {
        icon: 'waiting', // success, waiting, cancel
        title: '校验中...',
        desc: ''
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        console.log('actSignSelf:options', options);

        let flag = options.scene;
        let cardID = flag.substr(1);

        let formData = {
            cardID: cardID,
            signAction: flag[0] === '0' ? "sign_in" : "sign_out"
        };

        let this_ = this;
        wx.showLoading();
        api_SignInSelf(formData, (res) => {
            console.log("==> 卡券核销成功: ", res);
            wx.hideLoading();
            if (res.errcode == 0) {
                wx.showToast({
                    title: flag[0] === '0' ? '签到成功' : '签退成功',
                    icon: 'success'
                });

                this_.setData({
                    icon: 'success',
                    title: flag[0] === '0' ? '签到成功' : '签退成功',
                    desc: ''
                });
            } else {
                this_.setData({
                    icon: 'cancel',
                    title: flag[0] === '0' ? '签到失败' : '签退失败',
                    desc: res.errmsg +'\n请重试或咨询活动主办方'
                });
            }
        })
    }
});
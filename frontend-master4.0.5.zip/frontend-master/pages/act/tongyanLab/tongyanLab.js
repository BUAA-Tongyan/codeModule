// pages/act/tongyanLab/tongyanLab.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // grids: [0, 1, 2]

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  navigateToPUMP: function(e) {
    console.log('==>跳转小程序')
    wx.navigateToMiniProgram({
      appId: 'wx722259434581f0d3',
      path: 'pages/index/index',
      extraData: {
        foo: 'bar'
      },
      envVersion: 'v10',
      success(res) {
        // 打开成功
      }
    })
  },

  navigateToBUAA: function(e) {
    console.log('==>跳转小程序')
    wx.navigateToMiniProgram({
      appId: 'wxf68a40a9f57c8f3f',
      path: 'pages/index/index',
      extraData: {
        foo: 'bar'
      },
      envVersion: 'v10',
      success(res) {
        // 打开成功
      }
    })
  }
})
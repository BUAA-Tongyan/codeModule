// pages/act/sso.js
let {service} = require("../../../config");

Page({

  /**
   * Page initial data
   */
  data: {
    message: '',
    src:'',
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {
    let that = this;
    wx.login({
      success (res) {
        if (res.code) {
          let url= service+'/buaa/v2/sso/auth?code='+res.code+'&session='+options.scene+'#wechat_redirect';
          console.log(url);
          that.setData({src: url});
        } else {
          that.setData({message: '登录失败！'});
          console.log('登录失败！' + res.errMsg)
        }
      }
    })
  },

  onmessage: function(data){
    console.log('onmessage', data);
  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function () {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {

  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function () {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function () {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function () {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function () {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function () {

  }
})
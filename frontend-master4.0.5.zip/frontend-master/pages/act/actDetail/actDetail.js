import {$wuxToptips} from "../../components/wux-index";

const app = getApp()
const {
  api_GetActivityInfo,
  api_uc_GetInfoByToken,
  api_GetCardExt,
  api_refundTicket,
  api_shareAct,
  api_DeleteActivity
} = require("../../api/getData.js")

Page({

  data: {
    userInfo: {}, // 用户信息
    dataSource: { // 传入模板文件的数据源,整个模板文件不涉及数据交互,只负责展示
      actInfo: {}, // 用于展示数据源
      selectedFlag: false, // 参与人展开标记
    },
    showPaticipate: false, // 参与人是否展开，默认不展开
    btnText: '我要报名',
    loadingShow: false,
    isDisable: false,
    hasUserInfo: null,
    fromShare: false, // 场景判断
    canceled: false, // 取消活动操作
    share: [], // 朋友圈分享的数据
    showDeleteBtnConfirm:false,  // 显示活动删除确认框
    color:"",//风格颜色
  },
   onShareAppMessage: function() {
        const promise = new Promise(resolve => {
          setTimeout(() => {
            resolve({
              title: '同研————开启新视界'
            })
          }, 20) /*20是延时*/ 
        })
        return {
          title: '同研————开启新视界',
          path: 'pages/act/myIndex/myIndex',
          promise 
        }
    },
      //转发到朋友圈
     onShareTimeline(){},
  onLoad: function (options) {
    // 风格变换
    let style = wx.getStorageSync('style')
    switch (style){
      case "lightblue" : this.setData({
        color:"#3367DD"
      })
      break
      case "blue" : this.setData({
        color:"#475793"
      })
      break
      case "black" : this.setData({
        color:"black"
      })
      break
      case "red" : this.setData({
        color:"#C32B20"
      })
      break

    }
    // TODO 封装到函数中，保持onload的简洁
    console.log('传入页面的参数 --> ', options)

    // 获取用户信息
    if (app.globalData.userInfo) {
      console.log('globalData用户信息 -->', app.globalData.userInfo)
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    }
    // 获取活动详情
    let params = options.actId || options.scene;  // 通过动态生成的小程序码进入时，actId保存在options.scene中
    console.log("活动id：", params);
    api_GetActivityInfo(params, res => {
      var data = res.data.data
      console.log("拿到的活动详情 --> ", data)
      var imgUrl=data.summary.split("imgUrl:")[1]

      this.setData({
        imgUrl: imgUrl
      })

      console.log("拿到的附图链接 --> ", imgUrl)
      data.summary = data.summary.split("imgUrl:")[0]
      data.imgUrl = imgUrl
      this.setData({
        ['dataSource.actInfo']: data,
      })
    })

    // 判断小程序进入场景
    console.log("小程序进入场景 -->", app.globalData.resultScene)
    if (app.globalData.resultScene[0] === 1007 || app.globalData.resultScene[0] === 1008) {
      this.setData({
        fromShare: true
      })
    }
  },

  /**
   * 用户点击右上角分享配置
   */
  onShareAppMessage: function () {
    let actId = this.data.dataSource.actInfo.actId
    let title = this.data.dataSource.actInfo.title
    return {
      title: title,
      path: 'pages/act/actDetail/actDetail?actId=' + actId,
      success: function (res) {
        console.log('ok')
        if (res.errMsg === 'shareAppMessage:ok') {
          // 分享赚积分
          let params = {
            actId: actId
          }
          api_shareAct(params, res => {
            console.log('分享活动增加积分==>', res)
          })
        }
      },
      fail: function () {}
    }
  },


  /**************以上是生命周期********************以下是函数定义**************************/
  // 点击图片查看大图 并且能够调用微信内部的扫描二维码
  previewImage: function (e) {
    var current = e.target.dataset.src;
    wx.previewImage({
      current: this.data.imgUrl, // 当前显示图片的http链接 
      urls: [this.data.imgUrl] // 需要预览的图片http链接列表 
    })
  },


  // 从分享入口进入时返回主页
  // 为什么不用wx.navigateTo来保存前一个页面？
  goHome: function (e) {
    wx.reLaunch({
      url: '../home/home',
    })
  },

  // 参与人展开折叠选择 TODO 该事件的监听写到了模板里
  showPaticipate: function (e) {
    console.log(this.data.dataSource.selectedFlag)
    let tmp = this.data.dataSource.selectedFlag
    // this.setData使用[]，https://www.cnblogs.com/simuhunluo/p/7989461.html
    let str = 'dataSource.selectedFlag'
    this.setData({
      [str]: !tmp
    })
    this.data.showPaticipate = !this.data.showPaticipate
  },

  //取消活动报名
  cancelActApply: function (e) {
    let _this = this
    let actId = _this.data.dataSource.actInfo.actId
    let param = {
      actId: actId
    }
    wx.showModal({
      title: '确认取消报名？',
      content: "提示：取消报名后不能再次报名该活动；在活动开始前1小时内取消报名会扣除信用分，且取消报名后不能再次报名，详情见信用分规则。",
      success: function (res) {
        if (res.confirm) {
          console.log('用户点击确定')
          api_refundTicket(param, (res) => {
            console.log("活动取消结果==>", res)
            if (res.errcode == 0) {
              wx.showToast({
                title: '取消成功',
                icon: 'success',
              })
              _this.setData({
                canceled: true,
              })
            } else {
              wx.showModal({
                title: '错误提示',
                content: res.errmsg,
              })
            }
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }

      }
    })

  },


  addCard: function (cardNum) {
    let _this = this
    let cardId = this.data.dataSource.actInfo['cardId']
    console.log("cardId: ", cardId)
    console.info("==>活动的限制院系代码：", this.data.dataSource.actInfo.assignedAcademies)
    // console.info("==>用户所属的院系代码：", this.$store.getters.userInfo['academyId'])
    // console.info('==>活动信息中是否有院系限制字段', this.data.dataSource.actInfo.hasOwnProperty('assignedAcademies'))
    let params = {
      cardId: cardId,
      amount: cardNum
    }
    console.log(params)
    api_GetCardExt(params, (res) => {
      console.log("卡券返回的数据 --> ", res.data.data);
      let data = res.data.data
      // 生成卡券列表
      let cardList = []
      for (let i = 0; i < cardNum; i++) {
        let card = {
          cardId: data.cardIdList[i],
          cardExt: JSON.stringify(data.cardExtList[i]),
        }
        console.log('cart', card)
        cardList.push(card)
      }


      console.log("卡券列表 --> ", cardList)
      wx.addCard({
        cardList: cardList,
        success: function (res) {
          console.log('添加卡券结果 --> ', res.cardList) // 卡券添加结果
          _this.setData({
            btnText: "已成功",
          })
          wx.redirectTo({
            url: '../msg/partin_success?type=actParticipate&actId=' + _this.data.dataSource.actInfo.actId,
          })

        }
      })
    })
  },

  login(userinfo) { // 参数来额外接收用户数据
    var _this = this
    if (app.globalData.userInfoByToken) {
      // _this.addCard(1)
      console.log('==>全局变量中已有用户信息', app.globalData.userInfoByToken)
      // 检查状态并添加卡券
      _this.checkUserState(app.globalData.userInfoByToken.state)
    } else {
      app.login(userinfo, (err, res) => {
        if (err) return console.log('login function has error') // 如果登录方法出错则报错
        console.log('登录后存在全局变量中的用户信息==>', app.globalData)
        // 登录完毕后，调用用户数据等信息，使用 that.setData 写入
        console.log('==>进入登录流程')
        _this.setData({
          btnText: "自动登录中...",
          loadingShow: true,
          isDisable: true
        })
        /*获取用户信息并存在全局变量中*/
        api_uc_GetInfoByToken((res) => {
          console.log('用户信息bytoken==>', res.data.data)
          app.globalData.userInfoByToken = res.data.data
        })
        // _this.addCard(1)
        _this.checkUserState(app.globalData.userInfoByToken.state)
      })
    }

  },

  checkUserState(state) {
    if (state === '通过审核') {
      this.howToAddCard()
    } else {
      var _this = this;
      wx.showModal({
        title: '提示',
        content: '账户状态异常，请点击确定查看！',
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
            wx.navigateTo({
              url: '../../uc/userInfo/userInfo',
            })
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    }
  },
  /**
   * 判断是发一张还是发多张卡券
   */
  howToAddCard() {
    // 先判断是否为特殊的活动类型
    
    this.addCard(1)
  },
  /**
   * 分享到朋友圈，采用shareMoments组件
   */
  handleShareMoments: function () {
    // TODO 这里的名字起得有点混乱，因为是从别人的组件拷贝的
    let userInfo = this.data.userInfo
    let actInfo = this.data.dataSource.actInfo
    let avatar = userInfo.headimgurl
    console.log('avatar', avatar);
    let nickname = userInfo.nickname
    let adName = actInfo.title
    let adTime = actInfo.place
    let joinAvatarList = [] // 参与人的头像
    actInfo.participationList.forEach((item) => {
      joinAvatarList.push(item.headImg)
    })
    let joinNumber = joinAvatarList.length
    // joinAvatarList = joinAvatarList.filter((item, index) => index <= 8)
    let incomeMoney = `${actInfo.startTime}-${actInfo.endTime.slice(-5)}`
    this.setData({
      share: {
        avatar,
        nickname,
        incomeMoney,
        joinNumber,
        joinAvatarList,
        adName,
        adTime, //地点
        // 只能是网络图片，不能是本地图片. 图片通过七牛云存储托管
        adImageUrl: 'https://7365-server-0d9db-1259368714.tcb.qcloud.la/images_background/shareband.jpg?sign=957a4d320b634da0dfe6c010c8bdee2e&t=1597062528',
        showShareModel: true,
        qrcode_url: 'pages/act/actDetail/actDetail?' + this.data.dataSource.actInfo.actId
      },
    })
  },

  confirmDelete:function(){
    this.setData({
      showDeleteBtnConfirm: true
    })
  },
  /*
  * 删除活动
  * */
  delActivity:function (e) {
    let that = this
    console.log(e)
    console.log('formId==>', e.detail.formId)
    console.log('取消原因==>', e.detail.value.reason)
    that.setData({
      formId: e.detail.formId
    })
    let reason = e.detail.value.reason
    if (reason.length > 0) {
      console.log('要取消的活动ID==>', that.data.dataSource.actInfo.actId)
      let result = {
        actId: that.data.dataSource.actInfo.actId,
        reason: reason
      }
      console.log('要提交的取消信息==>', result)
      wx.showModal({
        title: '提示',
        content: '此操作不可撤回，确认删除？',
        success: function(e) {
          api_DeleteActivity(result, (res) => {
            console.log('删除结果==>', res)
            if (res.errmsg == 'ok') {
              //发送模板消息
              // that.sendPassTemplateMessage()
              wx.showToast({
                title: '删除成功',
                icon: 'success',
                duration: 2000
              })
              setTimeout(function () {
                wx.navigateBack({
                  delta: 1
                })
              }, 2000)
            }else{
              $wuxToptips().show({
                icon: 'cancel',
                hidden: false,
                text: '删除失败 - '+ res.errmsg,
                duration: 2000,
                success() {},
              })
            }
          })
        }
      })
    } else {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '请填写活动取消原因',
        duration: 2000,
        success() {},
      })
    }
  }

})
let {
    api_AddFeed
} = require("../../api/getData.js")
import {
    $wuxToptips
} from '../../components/wux-index'
var app = getApp()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        lengthOfInfo: 0,
        desription: `。`
    },


    sendFeed: function(e) {
        var temp = e.detail.value;
        temp["type"] = "0"
        if (this.userInfo) {
            temp["phone"] = this.userInfo.phone
        } else {
            temp["phone"] = "" //this.userInfo.phone
        }

        if (temp.title.length < 5) {
            $wuxToptips().show({
                icon: 'cancel',
                hidden: false,
                text: '标题不能少于5个字',
                duration: 2000,
                success() {},
            })
        } else if (temp.detail.length == 0) {
            $wuxToptips().show({
                icon: 'cancel',
                hidden: false,
                text: '具体描述不能为空',
                duration: 2000,
                success() {},
            })
        } else {
            api_AddFeed(temp, (res) => {
                console.log(res)
                wx.showToast({
                    title: '发送成功！',
                    icon: 'success',
                    duration: 2000
                })
                wx.navigateBack({
                    delta: 1
                })
            })

        }

    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        if (app.globalData.userInfoByToken) {
            console.log('userInfoByToken###############', app.globalData.userInfoByToken)
            this.setData({
                userInfo: app.globalData.userInfoByToken,
                hasUserInfo: true
            })
        }

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {

    },

    getLengthOfInfo: function(e) {
        var length = e.detail.value.length;
        this.setData({
            lengthOfInfo: length
        })
    }
})
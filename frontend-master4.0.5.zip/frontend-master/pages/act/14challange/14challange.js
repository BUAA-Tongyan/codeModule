// pages/act/14challange/14challange.js
let {
  api_LikeAct,
  api_GetHundredActList
} = require("../../api/getData.js")
Page({
  /**
   * 页面的初始数据
   */
  data: {
    currentTab: 0,
    dataSource: [],
    dataSourceDone: [],
    curPage: 1,
    maxSize: 0,
    dataSource_1: [],
    curPage_1: 1,
    maxSize_1: 0,
    noDataFlag1: false,
    noDataFlag2: false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    // 获取banner
    this.setData({
      swiperList: [{
        url: 'https://mp.weixin.qq.com/s/kA3n7FF9xjh6kanMF8F_ag', // 后面需要更换
        img: 'https://7365-server-0d9db-1259368714.tcb.qcloud.la/images_swiper/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20201124230918.jpg?sign=29c8ce5b60c0ab18d2f914458bdd4342&t=1606230599', // 后面需要更换
        title: '百日挑战'
      }]
    })
    console.log("#########--百日挑战的轮播图--##########", this.data.swiperList)

    /*获取学术活动列表*/
    this.getActList()

  },
  onReachBottom: function() {
    // 页面相关事件处理函数--监听下拉触底
    this.getActList()
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    this.refresh()
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    this.loadHActivies()
  },

  //滑动切换
  swiperTab: function(e) {
    var that = this;
    that.setData({
      currentTab: e.detail.current
    });
  },

  //点击切换
  clickTab: function(e) {
    var that = this;
    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  },

  /*获取初始的活动列表*/
  getActList: function(e) {
    /*获取所有活动列表*/
    api_GetHundredActList((res) => {
      console.log("#########--所有百日活动--##########", res)
      if (res.status == 200) {
        wx.showToast({
          title: '数据加载中',
          icon: 'loading',
          duration: 3000,
        });

        let activeData = res.data.active
        let doneData = res.data.done

        activeData.state = "正在报名"
        doneData.state = "已完成"
        this.setData({
          dataSource: activeData,
          dataSourceDone: doneData,
        })
        wx.hideToast()
      } else {
        wx.showToast({
          title: '服务器开小差中，TnT',
          icon: 'loading',
          duration: 3000,
        });
        // wx.hideToast()
      }
    });
  },

  /*上拉加载*/
  loadHActivies: function(e) {
    console.log("==> 加载函数执行")
    //先行判断是哪个tab
    if (this.data.currentTab == 0) {
      console.log("bottom: ", this.data.bottom)
      console.log("maxSize: ", this.data.maxSize)
      if (this.data.bottom >= this.data.maxSize) {
        console.log("==> 到达底部");
        this.setData({
          noDataFlag1: true
        })
        return
      } else {
        let params = {
          page: this.data.curPage + 1,
          size: 6
        };
        let temp = this.data.dataSource
        api_GetAcadActListOn(params, (res) => {
          console.log("#########", res.data)
          wx.showToast({
            title: '数据加载中',
            icon: 'loading',
            duration: 3000,
          });
          res.data.list.forEach(i => {
            temp.push(i)
          })
          this.setData({
            bottom: temp.length,
            dataSource: temp,
            curPage: res.data.curPage,
            maxSize: res.data.maxSize,
          })
          wx.hideToast()
        })
      }
    } else {
      console.log("bottom_1 ", this.data.bottom_1)
      console.log("maxSize_1: ", this.data.maxSize_1)
      if (this.data.bottom_1 >= this.data.maxSize_1) {
        console.log("==> 到达底部");
        this.setData({
          noDataFlag2: true
        })
        return
      } else {
        let params = {
          page: this.data.curPage_1 + 1,
          size: 6
        };
        let temp = this.data.dataSource_1
        api_GetAcadActListOff(params, (res) => {
          console.log("#########--加载的已结束学术活动列表--##########", res.data)
          wx.showToast({
            title: '数据加载中',
            icon: 'loading',
            duration: 3000,
          });
          res.data.list.forEach(i => {
            temp.push(i)
          })
          this.setData({
            bottom_1: temp.length,
            dataSource_1: temp,
            curPage_1: res.data.curPage,
            maxSize_1: res.data.maxSize,
          })
          wx.hideToast()
        })
      }
    }
  },
  /* 下拉刷新 */
  refresh: function() {
    console.log("==> 下拉刷新")
    this.setData({
      bottom: -1,
      dataSource_0: [],
      dataSource: [],
      dataSource_1: [],
      curPage: 0,
      maxSize: 0,
    })
    this.getActList();
  },


  //点击跳转活动详情页
  onClickTODO: function(e) {
    var actID = e.currentTarget.dataset.actid;
    var punchcard = e.currentTarget.dataset.finished;
    wx.navigateTo({
      url: '../14cDetail/14cDetail?actId=' + actID + '&finished=' + punchcard,
      success: function(res) {
        // success
      },
      fail: function() {
        // fail
      },
      complete: function() {
        // complete
      }
    })
  },

  //////////////////////////////////////////////////////////////////////////////////////
  handletouchmove: function(event) {
    if (this.data.flag !== 0) {
      return
    }
    let currentX = event.touches[0].pageX;
    let currentY = event.touches[0].pageY;
    let tx = currentX - this.data.lastX;
    let ty = currentY - this.data.lastY;
    let text = "";
    //左右方向滑动
    if (Math.abs(tx) > Math.abs(ty)) {
      if (tx < 0) {
        text = "向左滑动";
        this.data.flag = 1
      } else if (tx > 0) {
        text = "向右滑动";
        this.data.flag = 2
      }
    }
    //上下方向滑动
    else {
      if (ty < 0) {
        text = "向上滑动";
        this.data.flag = 3
        // wx.hideTabBar({
        //   animation: false
        // })

      } else if (ty > 0) {
        text = "向下滑动";
        this.data.flag = 4
        // wx.showTabBar({
        //   animation: true
        // })

      }
    }
    //将当前坐标进行保存以进行下一次计算
    this.data.lastX = currentX;
    this.data.lastY = currentY;
    this.setData({
      text: text,
    });
  },

  handletouchtart: function(event) {
    // console.log(event)
    this.data.lastX = event.touches[0].pageX;
    this.data.lastY = event.touches[0].pageY;
  },
  handletouchend: function(event) {
    this.data.flag = 0
    this.setData({
      text: "没有滑动",
    });
  },


})
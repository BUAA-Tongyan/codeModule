// pages/act/actDiscover/actDiscover.js
let {
  api_GetCreditChangeRecords
} = require("../../api/getData.js")
Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentTab: 0,
    totalPoints: 0,
    level: "未知",
    dataSource: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    console.log('#####################', options)
    let points = options.credit
      // < 60 较差  60 - 90 一般  90 - 110 良好   110 - 130 优秀 > 130极好

    if (points > 130) {
      this.setData({
        level: "极好"
      })
    } else if (points > 110) {
      this.setData({
        level: "优秀"
      })
    } else if (points > 90) {
      this.setData({
        level: "良好"
      })
    } else if (points > 60) {
      this.setData({
        level: "一般"
      })
    } else {
      this.setData({
        level: "较差"
      })
    }

    let params = {
      page: 1,
      size: 50
    }
    api_GetCreditChangeRecords(params, (res) => {
      console.log('信用分变更记录==>', res)
      this.setData({
        dataSource: res.data.list,
        totalPoints: points
      })

    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  // onShareAppMessage: function() {

  // },
  //点击切换

})
let {
  api_RemoveDiscover,
  api_GetDiscoverList
} = require("../../api/getData.js")
Page({
  data: {
    curPage: -1,
    maxPage: null,
    disList: [
      /*{
        id: 1,
        title: "零下5摄氏度，你想要一杯免费热咖啡吗？",
        introduction:
        "北航·同研学术平台是旨在为充分利用北京航空航天大学校内的学术资源，以“学术互助、交叉互融，移动互联”为宗旨，面向北航在校师生，全新打造的基于移动互联网的新型平台。",
        type: "通知公告",
        headImg: "",
        contentLink: "http://yan.shminjs.com:9000/article/do_you_want_caffe",
        lastEditedTime: "2018/03/15"
      },
      {
        id: 2,
        title: "零下5摄氏度，你想要一杯免费热咖啡吗？",
        introduction:
        "北航·同研学术平台是旨在为充分利用北京航空航天大学校内的学术资源，以“学术互助、交叉互融，移动互联”为宗旨，面向北航在校师生，全新打造的基于移动互联网的新型平台。",
        type: "通知公告",
        headImg: "",
        contentLink: "http://yan.shminjs.com:9000/article/do_you_want_caffe",
        lastEditedTime: "2018/03/15"
      }*/
    ],
    items: [],
  },


  onDelete: function(e) {
    var _this = this;
    wx.showModal({
      title: '提示',
      content: '确定删除这条发现吗？',
      success: function(res) {

        if (res.confirm) {
          var $data = e.currentTarget.dataset.index;
          console.log($data)
          api_RemoveDiscover($data, (res) => {
            console.log(res)
            if (res.errcode == 0) {
              wx.showToast({
                title: '删除成功！',
                icon: 'success',
                duration: 2000
              })
              _this.setData({
                currentPage: 1,
                disList: []
              });
              //用onLoad周期方法重新加载，实现当前页面的刷新
              _this.onLoad()
            }
          })
        } else if (res.cancel) {
          console.log("取消删除")
        }
      }
    })

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.GetDiscoverList();

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.GetDiscoverList();
  },

  GetDiscoverList: function(){

    if (this.data.curPage === this.data.maxPage || this.data.maxPage === 0) {
      wx.hideToast();
      return;
    }

    let params = {
      page: this.data.curPage+1,
      size: '20',
      type: '0'
    };

    let that = this;
    api_GetDiscoverList(params, (res) => {
      console.log("#########--发现列表--##########", res.data)
      let temp = that.data.disList;
      res.data.data.list.forEach(i => {
        temp.push(i)
      })
      console.log(temp)
      this.setData({
        disList: temp,
        curPage: res.data.data.curPage,
        maxPage: res.data.data.maxPage - 1,
      })
    })
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    this.GetDiscoverList();
  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },


  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }

})
// pages/act/home/home.js
let {
  api_uc_GetInfoByToken,
  api_GetAllBanners,
  api_GetAllAuthorities,
  api_GetActList,
  api_LikeAct
} = require("../../api/getData.js")
const app = getApp()

Page({
  data: {
    upshow:false,
    swiperList: [],
    indicatorDots: true,
    autoplay: true,
    interval: 2000,
    duration: 1000,
    previousMargin: 0,
    nextMargin: 0,
    dataSource: [],
    isloading: false,
    // 上拉加载
    curPage: 0,
    maxSize: 0,
    // 滑动事件监控
    lastX: 0, //滑动开始x轴位置
    lastY: 0, //滑动开始y轴位置
    text: "没有滑动",
    flag: 0,
    // 无更多数据标记
    noDataFlag: false,
    showHome:0,
    showBack:0,
    color :"",
    mainColor:app.store.$state.mainColor,
  },
  goTop: function(e){
    if (wx.pageScrollTo){
      
      wx.pageScrollTo({
        scrollTop: 0,
      })
      }
    
  },
  onPageScroll: function(e){
    var that=this;
    if (e.scrollTop>50){
      up_show:true
    }
    if (e.scrollTop<50){
      up_show: false
    }
  },
  /**
   * 生命周期函数--监听页面加载
      this.setData({
      mainColor:app.store.$state.mainColor
    }) */
  onLoad: function(options) {

    let style = wx.getStorageSync('style')
    switch (style){
      case "lightblue" : this.setData({
        color:"#3367DD"
      })
      break
      case "blue" : this.setData({
        color:"#475793"
      })
      break
      case "black" : this.setData({
        color:"black"
      })
      break
      case "red" : this.setData({
        color:"#C32B20"
      })
      break
    }

    wx.showToast({
      title: '数据加载中',
      icon: 'loading',
      duration: 3000,
    });

    // if (wx.getStorageSync('token')) {
      /*获取轮播图地址,没有则读取本地轮播图数据*/
    api_GetAllBanners((res) => {
      if (res.length) {
        this.setData({
          swiperList: res
        });
      } else {
        this.setData({
          swiperList: [{
            url: '',
            img: 'http://www.buaa.edu.cn/__local/D/A6/CF/285952AD92970F08226AECCD5E3_C8F39F61_106FF.jpg',
            title: '学院路校区'
          }, {
            url: '',
            img: 'http://www.buaa.edu.cn/__local/8/18/50/33226DE0493305EA215E7F40655_C7255710_15B18.jpg',
            title: '图书馆'
          }, {
            url: '',
            img: 'http://www.buaa.edu.cn/__local/6/CE/0C/E18BA593FC960A0B53E7C1CD455_6532815F_38D87.jpg',
            title: '沙河校区'
          }]
        })
      }
      console.log("#########--轮播图--##########", this.data.swiperList)
    })
    /*获取主页活动列表*/
    this.getHomeActList();
    // };

  },
  onShow:function(options) {
    this.setData({
      mainColor:app.store.$state.mainColor
    })
    //console.log("onShow==>");
    api_GetAllBanners((res) => {
      if (res.length) {
        this.setData({
          swiperList: res
        });
      } else {
        this.setData({
          swiperList: [{
            url: '',
            img: 'http://www.buaa.edu.cn/__local/D/A6/CF/285952AD92970F08226AECCD5E3_C8F39F61_106FF.jpg',
            title: '学院路校区'
          }, {
            url: '',
            img: 'http://www.buaa.edu.cn/__local/8/18/50/33226DE0493305EA215E7F40655_C7255710_15B18.jpg',
            title: '图书馆'
          }, {
            url: '',
            img: 'http://www.buaa.edu.cn/__local/6/CE/0C/E18BA593FC960A0B53E7C1CD455_6532815F_38D87.jpg',
            title: '沙河校区'
          }]
        })
      }
      console.log("#########--轮播图--##########", this.data.swiperList)
    })
    this.getHomeActList();
  },
  onReady: function(options) {
    // wx.hideToast()
  },

  onPullDownRefresh: function() {
    // 页面相关事件处理函数--监听用户下拉动作
    this.refresh();
    /*this.setData({
      mainColor:app.store.$state.mainColor
    });*/
  },
  onReachBottom: function() {
    // 页面相关事件处理函数--监听下拉触底
    this.getHomeActList();
  },

  /**************以上是生命周期********************以下是自定义函数**************************/

  /*获取主页活动列表*/
  getHomeActList: function() {
    console.log("==> 加载函数执行")
    wx.showToast({
      title: '数据加载中',
      icon: 'loading',
      duration: 3000,
    });
    console.log("bottom: ", this.data.bottom)
    if (this.data.bottom >= this.data.maxSize) {
      console.log("==> 到达底部");
      this.setData({
        noDataFlag: true
      })
      wx.hideToast()
      return
    } else {
      let params = {
        page: this.data.curPage + 1,
        size: 20
      };
      let weishalong = this.data.dataSource
      api_GetActList(params, (res) => {
        console.log("#########--活动列表--##########", res.data)
        //下拉刷新停止
        wx.stopPullDownRefresh()
        res.data.list.forEach(i => {
          console.log("==> 选定展示数据", i);
          if (i.domains[0] != '跳蚤市场') {
            weishalong.push(i)
          }
        })
        this.setData({
          bottom: weishalong.length,
          dataSource: weishalong,
          curPage: res.data.curPage,
          maxSize: res.data.maxSize,
        })
        wx.hideToast()
      })
    }
  },
  /* 下拉刷新 */
  refresh: function() {
    console.log("==> 下拉刷新")
    this.setData({
      bottom: -1,
      dataSource: [],
      curPage: 0,
      maxSize: 0,
    })
    this.getHomeActList();
  },
   onShareAppMessage: function() {
        const promise = new Promise(resolve => {
          setTimeout(() => {
            resolve({
              title: '同研————开启新视界'
            })
          }, 20) /*20是延时*/ 
        })
        return {
          title: '同研————开启新视界',
          path: 'pages/act/myIndex/myIndex',
          promise 
        }
    },
      //转发到朋友圈
     onShareTimeline(){},

  /*点击喜欢活动，只在微沙龙和活动广场首页显示*/
  loveButtonClick: function(e) {
    let loveId = e.currentTarget.dataset.index.actId
    let index = 0
    //渲染层样式改变
    this.data.dataSource.forEach(i => {
      if (i.actId == loveId) {
        let step = i.favoritedQuantity
        if (i.hasFavorited) {
          step--
        } else {
          step++
        }
        let str1 = 'dataSource[' + index + '].hasFavorited'
        let str2 = 'dataSource[' + index + '].favoritedQuantity'
        this.setData({
          [str1]: !i.hasFavorited,
          [str2]: step
        })
      }
      index++
    })
    // 同步更改后台数据
    console.log('点击活动的actID==>', loveId)
    let param = 'actId='
    param += loveId
    api_LikeAct(param, (res) => {
      console.log('更改喜爱状态回调==>', res)
    })
  },

  //点击跳转活动详情页
  onClickTODO: function(e) {
    var $data = e.currentTarget.dataset.index;
    console.log('当前点击的活动ID --> ', $data.actId)
    wx.navigateTo({
      url: '../actDetail/actDetail?actId=' + $data.actId,
      success: function(res) {
        // success
      },
      fail: function() {
        // fail
      },
      complete: function() {
        // complete
      }
    })
  },

  //////////////////////////////////////////////////////////////////////////////////////
  handletouchmove: function(event) {
    // console.log(event)
    if (this.data.flag !== 0) {
      return
    }
    let currentX = event.touches[0].pageX;
    let currentY = event.touches[0].pageY;
    let tx = currentX - this.data.lastX;
    let ty = currentY - this.data.lastY;
    let text = "";
    //左右方向滑动
    if (Math.abs(tx) > Math.abs(ty)) {
      if (tx < 0) {
        text = "向左滑动";
        this.data.flag = 1
      } else if (tx > 0) {
        text = "向右滑动";
        this.data.flag = 2
      }
    }
    //上下方向滑动
    else {
      if (ty < 0) {
        text = "向上滑动";
        this.data.flag = 3
        // wx.hideTabBar({
        //   animation: true //是否加载隐藏动画
        // })

      } else if (ty > 0) {
        text = "向下滑动";
        this.data.flag = 4
        // wx.showTabBar({
        //   animation: true
        // })//不隐藏tabbar

      }
    }
    //将当前坐标进行保存以进行下一次计算
    this.data.lastX = currentX;
    this.data.lastY = currentY;
    this.setData({
      text: text,
    });
  },

  handletouchtart: function(event) {
    // console.log(event)
    this.data.lastX = event.touches[0].pageX;
    this.data.lastY = event.touches[0].pageY;
  },
  handletouchend: function(event) {
    this.data.flag = 0
    this.setData({
      text: "没有滑动",
    });
  },
  onShareAppMessage: function () {
    return {
      title: '北航同研小程序',
      path: 'pages/act/home/home',
      success: function (res) {
        console.log('分享主界面成功')
        // if (res.errMsg === 'shareAppMessage:ok') {
        //   // 分享赚积分
        //   let params = {
        //     actId: actId
        //   }
        //   api_shareAct(params, res => {
        //     console.log('分享活动增加积分==>', res)
        //   })
        // }
      },
      fail: function () {}
    }
  },
  handleContact (e) {
    console.log(e.detail.path)
    console.log(e.detail.query)
}
})
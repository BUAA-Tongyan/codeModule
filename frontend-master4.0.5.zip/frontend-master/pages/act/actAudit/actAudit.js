// pages/act/actAudit/actAudit.js
let {
  api_GetActivitiesToAudit,
  api_GetActivitiesAudited
} = require("../../api/getData.js")

Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentTab: 0,
    dataSource: [],
    curPage: 1,
    maxSize: 0,
    dataSource_1: [],
    curPage_1: 1,
    maxSize_1: 0,
    noDataFlag: false,
    noDataFlag_1: false,
    color:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    // 获取初始的审核活动列表
    this.getActivitiesAudit()
    // 风格
    let style = wx.getStorageSync('style')
    switch (style){
      case "lightblue" : this.setData({
        color:"#3367DD"
      })
      break
      case "blue" : this.setData({
        color:"#475793"
      })
      break
      case "black" : this.setData({
        color:"black"
      })
      break
      case "red" : this.setData({
        color:"#C32B20"
      })
      break

    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.refresh()
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    this.refresh()
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    this.loadActivitiesAudit()
  },

  /**
   * 用户点击右上角分享
   */
  // onShareAppMessage: function() {

  // },
  /**************以上是生命周期********************以下是自定义函数**************************/
  //滑动切换
  swiperTab: function(e) {
    var that = this;
    that.setData({
      currentTab: e.detail.current
    });
  },

  //点击切换
  clickTab: function(e) {
    var that = this;
    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  },

  /*点击跳转活动详情页*/
  onClickTODO: function(e) {
    var $data = e.currentTarget.dataset.index;
    console.log('当前点击的活动ID==>', $data.actApplyFormId)
    wx.navigateTo({
      url: '../actAuditDetail/actAuditDetail?actApplyFormId=' + $data.actApplyFormId,
      success: function(res) {
        // success
      },
      fail: function() {
        // fail
      },
      complete: function() {
        // complete
      }
    })
  },
  loadActivitiesAudit: function(e) {
    console.log("==> 加载函数执行")
    //先判断是哪个tab
    if (this.data.currentTab == 0) {
      console.log("bottom: ", this.data.bottom)
      console.log("maxSize: ", this.data.maxSize)
      if (this.data.bottom >= this.data.maxSize) {
        console.log("==> 到达底部");
        this.setData({
          noDataFlag: true
        })
        return
      } else {
        let params = {
          page: this.data.curPage + 1,
          size: 6
        };
        let actstoaudit = this.data.dataSource
        api_GetActivitiesToAudit(params, (res) => {
          console.log("#########--活动列表--##########", res.data)
          wx.showToast({
            title: '数据加载中',
            icon: 'loading',
            duration: 3000,
          });
          res.data.data.list.forEach(i => {
            // actstoaudit.push(i)
            var t = i
            // 题目修改
            if (t.title.search("transaction") != -1) {
              t.title = '【' + JSON.parse(t.title).transaction + '】' + JSON.parse(t.title).title
            } else {
              t.title = t.title
            }
            // 发起人修改
            if (t.contactName.search("qrcode") != -1) {
              t.contactName = JSON.parse(t.contactName).contactName
            } else {
              t.contactName = t.contactName
            }
            actstoaudit.push(t)
          })
          this.setData({
            bottom: actstoaudit.length,
            dataSource: actstoaudit,
            curPage: res.data.data.page,
            maxSize: res.data.data.maxSize,
          })
          wx.hideToast()
        })
      }
    } else {
      console.log("bottom_1 ", this.data.bottom_1)
      console.log("maxSize_1: ", this.data.maxSize_1)
      if (this.data.bottom_1 >= this.data.maxSize_1) {
        console.log("==> 到达底部");
        this.setData({
          noDataFlag_1: true
        })
        return
      } else {
        let params = {
          page: this.data.curPage_1 + 1,
          size: 6
        };
        let actsaudited = this.data.dataSource_1
        api_GetActivitiesAudited(params, (res) => {
          console.log("#########--活动列表--##########", res.data)
          wx.showToast({
            title: '数据加载中',
            icon: 'loading',
            duration: 3000,
          });
          res.data.data.list.forEach(i => {
            var t = i
            // 题目修改
            if (t.title.search("transaction") != -1) {
              t.title = '【' + JSON.parse(t.title).transaction + '】' + JSON.parse(t.title).title
            } else {
              t.title = t.title
            }
            // 发起人修改
            if (t.contactName.search("qrcode") != -1) {
              t.contactName = JSON.parse(t.contactName).contactName
            } else {
              t.contactName = t.contactName
            }
            actstoaudit.push(t)
          })
          this.setData({
            bottom_1: actsaudited.length,
            dataSource_1: actsaudited,
            curPage_1: res.data.data.page,
            maxSize_1: res.data.data.maxSize,
          })
          wx.hideToast()
        })
      }
    }
  },
  /* 下拉刷新 */
  refresh: function() {
    console.log("==> 下拉刷新")
    this.setData({
      bottom: -1,
      dataSource: [],
      curPage: 0,
      maxSize: 0,
      bottom_1: -1,
      dataSource_1: [],
      curPage_1: 1,
      maxSize_1: 0,
    })
    this.getActivitiesAudit();
  },

  /*获取初始的审核活动列表*/
  getActivitiesAudit: function(e) {
    /*获取未审核的活动列表*/
    let params = {
      page: 1,
      size: 6
    };
    api_GetActivitiesToAudit(params, (res) => {
      console.log("#########--未审核的活动--##########", res.data)
      wx.showToast({
        title: '数据加载中',
        icon: 'loading',
        duration: 3000,
      });
      var dataSource=[]
      for (var index in res.data.data.list) {
        var t=res.data.data.list[index]
        // 题目修改
        if (t.title.search("transaction")!=-1) {
          t.title = '【'+JSON.parse(t.title).transaction+'】'+ JSON.parse(t.title).title
        } else{
          t.title=t.title
        }
        // 发起人修改
        if (t.contactName.search("qrcode") != -1) {
          t.contactName = JSON.parse(t.contactName).contactName
        } else {
          t.contactName = t.contactName
        }
        dataSource.push(t)
      }
      this.setData({
        // dataSource: res.data.data.list,
        dataSource: dataSource,
        bottom: res.data.data.list.length,
        curPage: res.data.data.page,
        maxSize: res.data.data.maxSize,
      })
      wx.hideToast()
    });

    /*获取已审核的活动列表*/
    let params_1 = {
      page: 1,
      size: 10
    };
    api_GetActivitiesAudited(params_1, (res) => {
      console.log("#########--已审核的活动--##########", res.data)
      wx.showToast({
        title: '数据加载中',
        icon: 'loading',
        duration: 3000,
      });
      var dataSource1 = []
      for (var index in res.data.data.list) {
        var t = res.data.data.list[index]
        // 题目修改
        if (t.title.search("transaction") != -1) {
          t.title = '【' + JSON.parse(t.title).transaction + '】' + JSON.parse(t.title).title
          console.log("#aaaaaa")
        } else {
          t.title = t.title
          console.log("#bbb", t.title.search("transaction"))
        }
        // 发起人修改
        if (t.contactName.search("qrcode") != -1) {
          t.contactName = JSON.parse(t.contactName).contactName
        } else {
          t.contactName = t.contactName
        }
        dataSource1.push(t)
      }
      this.setData({
        dataSource_1: dataSource1,
        bottom_1: res.data.data.list.length,
        curPage_1: res.data.data.page,
        maxSize_1: res.data.data.maxSize,
      })
      wx.hideToast()
    });
    wx.stopPullDownRefresh();
  },
})
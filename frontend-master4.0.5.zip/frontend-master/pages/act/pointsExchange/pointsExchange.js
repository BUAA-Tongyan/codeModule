const app = getApp()
const {
  formatDate,
  formatTime
} = require('../../../utils/util')
const {
  api_GetUserState
} = require("../../api/getData.js")
Page({
  /*-------------------- 数据 --------------------*/
  data: {
    points: 0, // 总积分
    currentTab: 0, // 当前tab的索引
    cartHidden: false, // 是否要显示购物车图标
    sumCredit: 0, // 要扣除的积分
    cartCount: 0, // 红色徽章中的数字
    commodityList: [], // 积分商品列表
    cart: [], //购物车
  },


  /*-------------------- 生命周期函数 --------------------*/
  onLoad: function () {
    wx.showToast({
      title: '数据加载中',
      icon: 'loading',
      duration: 3000,
    })
    wx.cloud.init({
      env: 'server-0d9db'
    })
    const db = wx.cloud.database()

    this.fetchUserInfo() // 获取全局用户信息和积分
    this.fetchCommoodityList() // 获取商品列表
    this.fetchOrder() // 获取用户订单列表 
    this.fetchOrderHistory() // 获取用户历史订单列表
  },
  onReady: function () {
    wx.hideToast()
  },


  /*-------------------- 路由切换 --------------------*/
  // 点击tab切换
  clickTab: function (e) {
    this.setData({
      currentTab: e.target.dataset.current
    })
  },
  // 点击图案切换
  clickCircle: function () {
    this.setData({
      currentTab: 1,
    })
  },
  // 滑动切换
  swiperTab: function (e) {
    this.setData({
      // 点击和滑动获取事件宿主属性的具体操作不太一样
      currentTab: e.detail.current
    })
  },


  /*-------------------- 事件监听函数 --------------------*/
  // 点击"加入购物车"后的事件 
  chooseItem: function (e) {
    // 通过事件机制，获取绑定到dom元素上的id
    let datasetId = e.target.dataset.id // 当前商品的_id
    let index = e.target.dataset.index // 当前商品是第几个
    let thisCommodity = this.data.commodityList.find(item => item._id === datasetId) // 当前商品
    let currentCartNum = (this.data.cart.filter(item => item._id === datasetId) || []).length // 当前物品已选数量
    if (thisCommodity.count <= 0) {
      return wx.showModal({
        title: '提示',
        content: '库存不足！',
        showCancel: false
      })
    }
    if (currentCartNum >= thisCommodity.max) {
      return wx.showModal({
        title: '提示',
        content: `该商品每次最多兑换${thisCommodity.max}个！`,
        showCancel: false
      })
    }
    this.data.commodityList[index].count--
    // 将该物品放到购物车中并缩减数量
    this.setData({
      // commodityList[index]: this.data.commodityList[index].
      commodityList: this.data.commodityList,
      cart: this.data.cart.concat([thisCommodity])
    })
    // this.data.cart.push(this.data.commodity[index])
    // 这种方法无法做到双向绑定实时更新,必须使用setData
    this.sumCredit()
    wx.showToast({
      title: '添加成功!',
      duration: 400
    })
  },
  sumCredit: function () {
    let sum = 0
    this.data.cart.forEach(item => sum += parseInt(item.cost))
    this.setData({
      sumCredit: sum,
      cartCount: this.data.cart.length
    })
  },

  // 在购物车中删除商品
  deleteItem: function (e) {
    let datasetId = e.target.dataset.id // 当前商品的_id
    let index = e.target.dataset.index // 当前商品是第几个
    let thisCommodity = this.data.commodityList.find(item => item._id === datasetId) // 当前商品
    let currentCartNum = (this.data.cart.filter(item => item._id === datasetId) || []).length // 当前物品已选数量
    // 在购物车中删除该商品
    this.data.cart.splice(index, 1)
    thisCommodity.count++
    this.setData({
      cart: this.data.cart,
      commodityList: this.data.commodityList
    })
    this.sumCredit()
  },

  // 提交购物车数据
  submit: function () {
    let newCart = this.changeToNewCart(this.data.cart)
    this.setData({
      newCart
    })
    // 如果逻辑上不允许，则不进行确认，直接退出submit
    if (!this.canISubmit()) {
      return
    }
    // 逻辑上允许的清空下，进行提交确认
    wx.showModal({
      title: '提示',
      content: '确认兑换？',
      success: res => {
        if (res.confirm) {
          // TODO 发送请求，扣除用户积分，需要补充
          wx.showModal({
            title: '结果',
            content: '用户' + this.data.userInfo.buaaId + '扣分' + this.data.sumCredit
          })
          this.addOrder() // 增加订单
          this.updateCommodity() // 更新商品信息
            .then(() => {
              this.fetchCommoodityList()
              this.fetchOrder()
              this._reset()
            })
            .catch(console.error)
        } else if (res.cancel) {
          console.log('动作：用户点击取消')
        }
      }
    })
  },
  // 客服消息来源
  handleContact(e) {
    console.log('客服消息来源', e.path, e.query)
  },
  /*-------------------- 普通函数 --------------------*/
  /**
   * 获取用户信息
   */
  fetchUserInfo: function () {
    if (app.globalData.userInfoByToken) { // 获取用户详细信息
      this.setData({
        userInfo: app.globalData.userInfoByToken,
        hasUserInfo: true
      })
    } else {
      return wx.showModal({
        title: '提示',
        content: '请先登录',
        showCancel: false,
        success: res => {
          if (res.confirm) {
            wx.switchTab({
              url: '/pages/act/myIndex/myIndex'
            })
          }
        }
      })
    }
    api_GetUserState((res) => { // 获取用户信息（积分）
      this.setData({
        points: res.data.data.points
      })
    })
  },
  /**
   * 获取商品列表
   */
  fetchCommoodityList: function () {
    // 再次发起请求，刷新商品数量
    const db = wx.cloud.database()
    db.collection('pointsExchange')
      .get()
      .then(res => {
        this.setData({
          commodityList: res.data
        })
      })
  },
  /**
   * 获取订单列表
   */
  fetchOrder: function () {
    let that = this
    const db = wx.cloud.database()
    db.collection('order')
      .where({
        // buaaId: '12312',
        isFinished: false,
        buaaId: that.data.userInfo.buaaId,
      })
      .get()
      .then(res => {
        console.log('fetchOrder', res)
        if (res.data[0]) {
          this.setData({
            order: res.data[0]
          })
        }
      })
  },

  /**
   * 获取历史订单列表
   */
  fetchOrderHistory: function () {
    let that = this
    const db = wx.cloud.database()
    db.collection('order')
      .where({
        // buaaId: '12312',
        isFinished: true,
        buaaId: that.data.userInfo.buaaId,
      })
      .get()
      .then(res => {
        console.log('fetchOrderHistory', res.data)
        if (res.data[0]) {
          this.setData({
            orderHistory: res.data
          })
        }
      })
  },

  /**
   * 添加订单
   */
  addOrder: function () {
    let order = {}
    order.buaaId = this.data.userInfo.buaaId
    order.time = `${ formatDate(new Date())}  ${formatTime(new Date()) }`
    order.isFinished = false
    order.nickname = this.data.userInfo.nickname
    order.cart = this.data.newCart
    const db = wx.cloud.database()
    db.collection('order').add({
      data: order,
      success: function (res) {
        console.log('添加订单成功', res)
      }
    })
  },

  /**
   * 更新订单
   */
  updateCommodity: function () { // 返回一个Promise对象
    return wx.cloud.callFunction({
      // 云函数名称
      name: 'reduceCommodity',
      // 传给云函数的参数
      data: {
        buaaId: this.data.userInfo.buaaId,
        cart: this.data.newCart
      }
    })
  },

  /**
   * 清空‘计算属性’
   */
  _reset: function () {
    this.setData({
      cart: [],
      cartCount: 0,
      sumCredit: 0,
    })
  },

  /**
   * 将不带数量的购物车数组转化为带数量num的购物车数组
   */
  changeToNewCart: function (oldCart) {
    let newCart = []
    let idList = []
    oldCart.forEach(i => {
      if (idList.indexOf(i._id) === -1) {
        let item = {}
        item.name = i.name
        item._id = i._id
        item.cost = i.cost
        item.imgSrc = i.imgSrc
        item.num = 1
        newCart.push(item)
        idList.push(i._id)
      } else {
        newCart.forEach(j => {
          if (j._id === i._id) {
            j.num++
          }
        })
      }
    })
    return newCart
  },
  /**
   * 核实该用户是否可以将购物车数据发送到服务器
   */
  canISubmit: function () {
    if (this.data.points < this.data.sumCredit) {
      wx.showModal({
        title: '提示',
        content: '对不起，您的积分不足',
      })
      return false
    }
    if (this.data.cartCount == 0) {
      wx.showModal({
        title: '提示',
        content: '请先将要兑换的商品加入购物车',
      })
      return false
    }
    if (this.data.order) {
      wx.showModal({
        title: '提示',
        content: '请先将上次的订单找客服小姐姐兑换',
        showCancel: false
      })
      return false
    }
    return true
  }
})
Component({
  properties: {
      idx: {
          type: Number,
          value: 0
      },
  },
  
  data: {
      backgroundColor:"",
      backgroundImgTab:"",
      unselectedColor: "",
      selectedColor: "#4285f4",
      selectedPlusColor: "#4285f4",
      unselectedPlusColor: "#4285f4",
      tabNum:5,
      
      tabBar: [
        {
          "current": 0,
          "pagePath": "../../../pages/act/home/home",
          "text": "微沙龙",
          "classPath" : 'fas fa-coffee',
          "classText" : '',
          "color":'red',
          "selectedColor": 'red',
        },
        {
          "current": 0,
          "pagePath": "/pages/act/acadHome/acadHome",
          "text": "活动广场",
          "classPath" : 'fas fa-users',
          "classText" : '',
          "color":'red',
          "selectedColor": 'red',
        },
        {
          "current": 0,
          "classPath" : 'material-icons',  // fa图标库只需要赋值这个          
          "pagePath": "/pages/act/actApply/actApply",
          "text": "发起活动",
          "classText" : 'add_circle_outline',  //md图标库特有
          "color":'red',
          "selectedColor": 'red',
          
        },
        {
          "current": 0,
          "classPath" : 'fas fa-paper-plane',
          "pagePath": "/pages/act/actDiscover/actDiscover",
          "text": "发现",
          "classText" : '',
          "color":'red',
          "selectedColor": 'red',
        },
        {
          'current': 0,
          "classPath" : 'fas fa-user',
          "pagePath": "/pages/act/myIndex/myIndex",
          "text": "我的",
          "classText" : '',
          "color":'red',
          "selectedColor": 'red',

        }
    ]
  },
  ready: function(options) {

    /*当前风格*/
    let style = wx.getStorageSync('style')
    switch(style) {
      case "blue" :
        this.setData(
          {
            backgroundColor : "#485693",
            backgroundImgTab : "",
            selectedColor : "#DEAA34",
            unselectedColor : "#E8E8E8",
            unselectedPlusColor : "#DEAA34",
            selectedPlusColor : "#DEAA34",
            "tabBar[2].classPath" : "material-icons",
            "tabBar[2].classText" : "add_circle_outline",
          }
        );
        break;
      case "lightblue":
        this.setData(
          {
            backgroundColor : "#FFFFFF",
            backgroundImgTab : "",
            selectedColor : "#3468DE",
            unselectedColor : "#848286",
            unselectedPlusColor : "#3468DE",
            selectedPlusColor : "#3468DE",
            "tabBar[2].classPath" : "material-icons",
            "tabBar[2].classText" : "add_circle_outline",
          }
        );

        break;
      case "red":
        this.setData(
          {
            backgroundColor : "#C32B20",
            backgroundImgTab : "",
            selectedColor : "rgba(237,191,188,1)",
            unselectedColor : "rgba(237,191,188,0.8)",
            unselectedPlusColor : "rgba(237,191,188,1)",
            selectedPlusColor : "rgba(237,191,188,1)",
            "tabBar[2].classPath" : "fab fa-telegram",
            "tabBar[2].classText" : "",
          }
        );
        break;
      case "black":
        this.setData(
          {
            backgroundColor : "",
            backgroundImgTab : "https://7365-server-0d9db-1259368714.tcb.qcloud.la/images_background/statusBarBack.jpg?sign=e20c06de2452f45476a4ce90e8a9ec8e&t=1600323230",
            selectedColor : "#FFFFFF",
            unselectedColor : "#848286",
            unselectedPlusColor : "rgba(176,28,28,1)",
            selectedPlusColor : "rgba(176,28,28,1)",
            "tabBar[2].classPath" : "material-icons",
            "tabBar[2].classText" : "add_circle_outline",
          }
        );
        break;
      default:

        break;
    }
  },
  observers: {
    'idx' (idx) {
      var otabbar = this.data.tabBar
      var id = parseInt(idx)
      console.log("#########--替换中--##########", id)
      var i = 0
      for(i=0 ; i < this.data.tabNum;i++){
        if (i == id){
          otabbar[i]['current'] = 1
        }
        else{
          otabbar[i]['current'] = 0
        }

      }
      this.setData({ tabBar: otabbar});
    }
  },
 
  methods: {

    goToTab: function(e){
      var url = e.currentTarget.dataset.url
      // console.log("#########--跳转中--##########", url)
      wx.switchTab({
        url: url,
        success: function(res) {
          // console.log("#########--跳转成功--##########", url)
        },
        fail: function(res) {
          // console.log("#########--跳转失败--##########", url)
        },
        complete: function(res) {
      
        },
       })
    }
  }
});
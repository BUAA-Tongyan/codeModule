const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}

const formatTime = date => {
  const hour = date.getHours()
  const minute = date.getMinutes()
  return [hour, minute].map(formatNumber).join(':')
}

const formatDate = (date) => {
  let year = date.getFullYear()
  let month = date.getMonth() + 1
  let day = date.getDate()
  return [year, month, day].map(formatNumber).join('-')
}

const formatTomDate = (date) => {
  var day1 = date;
  day1.setTime(day1.getTime() + 24 * 60 * 60 * 1000);
  let year = day1.getFullYear()
  let month = day1.getMonth() + 1
  let day = day1.getDate()
  return [year, month, day].map(formatNumber).join('-')
}

module.exports = {
  formatTime: formatTime,
  formatDate: formatDate,
  formatTomDate: formatTomDate,
}
// 配置后端网址1
module.exports = {
  // service: "https://test.buaagsu.com"
  // service: "http://buaawx.nat300.top"
  service: "https://www.buaagsu.com"
  // service: "https://10.212.31.53:18888"
}
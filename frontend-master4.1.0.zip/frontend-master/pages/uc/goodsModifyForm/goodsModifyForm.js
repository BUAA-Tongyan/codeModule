let {  // 应该没用
  api_ApplyNewAct,
} = require("../../api/getData.js")

import {
  $wuxToptips
} from '../../components/wux-index'
const app = getApp()
Page({

  data: {
    addNew: true,  // 是否为添加新商品，false则为修改已有商品信息
    id: '',  // 商品在数据库中的id号
    goodsName: '',  // 商品名
    goodsPoint: '',  // 商品所需积分
    goodsNumber: '',  // 商品库存
    goodsImg: '',  // 商品封面
    goodsUpper: '',  // 商品单次可兑换上限

    __killBlur: false// 私有属性：触发修改speaks事件时，禁止blur事件
  },

  onLoad: function (options) {
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      duration: 3000,
    })
    wx.cloud.init({
      env: 'server-0d9db'
    })

    if (options.addNew == 'true') {
      console.log('addNew: true')
      this.setData({
        id: options.id,
        addNew: true
      })
    }else {
      console.log('addNew: false')
      const db = wx.cloud.database()
      db.collection('pointsExchange').doc(options.id).get().then(res => {
        console.log('初始化表单', res.data);
        this.setData({
          id: options.id,
          addNew: false,
          goodsName: res.data.name,
          goodsPoint: res.data.cost,
          goodsNumber: res.data.count,
          goodsImg: res.data.imgSrc,
          goodsUpper: res.data.max,
        })
      })
    }
  },

  onReady: function () {
    wx.hideToast()
  },

  onShow: function (options) {
  },




  // 商品名称设置
  setName: function (e) {
    this.setData({
      goodsName: e.detail.value
    });
    console.log('商品名称设置', this.data.goodsName)
  },

  //商品积分设置
  setPoint: function (e) {
    this.setData({
      goodsPoint: e.detail.value
    });
    console.log('商品所需积分设置', this.data.goodsPoint)
  },
 
  //商品库存设置
  setNumber: function (e) {
    this.setData({
      goodsNumber: e.detail.value
    });
    console.log('商品库存设置', this.data.goodsNumber)
  },

  // 商品图片选择
  setImg: function (e) {
    var _this = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        console.log('商品图片添加成功', res)
        _this.setData({
          goodsImg: res.tempFilePaths[0]
        })
        console.log('tmp filePath', _this.data.goodsImg);
      }
    })
  },

  // 长按删除商品图片
  delImg: function (e) {
    var that = this;
    wx.showModal({
      title: '系统提醒',
      content: '确定要删除图片吗？',
      success: function(res) {
        if (res.confirm) {
          that.setData({
            goodsImg: ''
          });
          console.log('图片删除成功')
        }
      }
    })
  },

  // 设置单次可兑上限
  setUpper: function(e) {
    this.setData({
      goodsUpper: e.detail.value
    })
    console.log('单次可兑上限', this.data.goodsUpper)
  },

  // 提示可兑上限的详情
  showInfo: function(e) {
    wx.showModal({
      title: '提示',
      content: '允许用户每次可兑换该商品的上限数量'
    })
  },

  // 提交表单
  submitApply: function(e) {
    var _this = this
    let form = {
      cost: String(_this.data.goodsPoint).trim(),
      count: String(_this.data.goodsNumber).trim(),
      imgSrc: String(_this.data.goodsImg).trim(),
      max: String(_this.data.goodsUpper).trim(),
      name: String(_this.data.goodsName).trim()
    }
    // 检查表单数据有效性
    if (form.name.length == 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '商品名称不能为空',
        duration: 2000,
        success() {},
      })
    }else if (form.cost.length == 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '所需积分不能为空',
        duration: 2000,
        success() {},
    })
    }else if (isNaN(+form.cost) == true) {  // 输入不为数字的情况
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '请输入正确积分数值',
        duration: 2000,
        success() {},
    })
    }else if (+form.cost % 1 != 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '所需积分必须为整数',
        duration: 2000,
        success() {},
    })
    }else if (+form.cost < 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '所需积分必须不小于零',
        duration: 2000,
        success() {},
    })
    }else if (form.count.length == 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '商品库存不能为空',
        duration: 2000,
        success() {},
    })
    }else if (isNaN(+form.count) == true) {  // 输入不为数字的情况
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '请输入正确库存数值',
        duration: 2000,
        success() {},
    })
    }else if (+form.count % 1 != 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '商品库存必须为整数',
        duration: 2000,
        success() {},
    })
    }else if (+form.count < 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '商品库存必须不小于零',
        duration: 2000,
        success() {},
    })
    }else if (form.max.length == 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '可兑上限不能为空',
        duration: 2000,
        success() {},
    })
    }else if (isNaN(+form.max) == true) {  // 输入不为数字的情况
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '请输入正确可兑上限数值',
        duration: 2000,
        success() {},
    })
    }else if (+form.max % 1 != 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '可兑上限必须为整数',
        duration: 2000,
        success() {},
    })
    }else if (+form.max <= 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '可兑上限必须大于零',
        duration: 2000,
        success() {},
    })
    }else if (form.imgSrc.length == 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '商品封面不能为空',
        duration: 2000,
        success() {},
    })
    }else {
      if (form.imgSrc.match(/tcb\.qcloud\.la/) == null) {  // 若所选图片不在云端，则首先上传图片再提交表单
        console.log('not in cloud');
        // 上传图片到云存储，并提交表单
        var timestamp = (new Date()).valueOf();  // 采集时间戳作为图片名，防止重名
        var type = form.imgSrc.substring(form.imgSrc.lastIndexOf('.'));  // 文件后缀名
        wx.cloud.uploadFile({
          cloudPath: 'images_commodity/' + timestamp + type,
          filePath: form.imgSrc,
          success: (res) => {
            console.log('图片上传成功', res);
            wx.cloud.getTempFileURL({  // 获取云端图片url
              fileList: [res.fileID],
              success: (res) => {
                form.imgSrc = res.fileList[0].tempFileURL,
                console.log('商品图片url', form.imgSrc);

                // 提交表单
                const db = wx.cloud.database()
                if (_this.data.addNew == true) {  // 新建商品
                  db.collection('pointsExchange').add({
                    data: {
                      cost: +form.cost,
                      count: +form.count,
                      imgSrc: form.imgSrc,
                      max: +form.max,
                      name: form.name
                    },
                    success: function(res) {
                      console.log('提交成功')
                      wx.showModal({
                        title: '提示',
                        content: '提交成功',
                      })
                    }
                  })
                }else {  // 修改已有商品
                  db.collection('pointsExchange').doc(_this.data.id).update({
                    data: {
                      cost: +form.cost,
                      count: +form.count,
                      imgSrc: form.imgSrc,
                      max: +form.max,
                      name: form.name
                    },
                    success: function(res) {
                      wx.showModal({
                        title: '提示',
                        content: '提交成功',
                      })
                    }
                  })
                }
              }
            })
          },
        })
      }else {  // 若所选图片已经在云端，则无需上传，且说明当前一定属于是对已有商品的修改
        console.log('in cloud', _this.data.id)
        // 提交表单
        const db = wx.cloud.database()
          db.collection('pointsExchange').doc(_this.data.id).update({
            data: {
              cost: +form.cost,
              count: +form.count,
              max: +form.max,
              name: form.name
            },
            success: function(res) {
              console.log('提交成功')
              wx.showModal({
                title: '提示',
                content: '提交成功',
              })
            }
          })
      }
    }
  },

  delGoods: function(e) {
    var _this = this;
    wx.showModal({
      content: '确认删除该商品？',
      success (res) {
        if (res.confirm) {
          console.log('确认删除')
          const db = wx.cloud.database()
          db.collection('pointsExchange').doc(_this.data.id).remove({
            success: function(res) {
              console.log('删除成功', res.data)
              wx.showModal({
                title: '提示',
                content: '删除成功!',
                success (res) {
                  wx.navigateBack({
                    delta: 1,
                  })
                }
              })
            }
          })
        }
      }
    })
  },

  // 恢复blur
  recoverBlur() {
    console.log('现在恢复blur事件')
    this.data.__killBlur = false
  },
})
// pages/uc/userAuditDetail/userAuditDetail.js
var app = getApp()
let {
  api_GetRegisterFormById,
  api_SubmitPassAuditResult,
  api_SubmitRejectAuditResult,
  api_uc_SendTemplateMessage
} = require("../../api/getData.js")

Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    console.log('上级页面传值==>', options)
    let applyId = options.applyId
    api_GetRegisterFormById(applyId, (res) => {
      console.log('审核详情==>', res.data.data)
      this.setData({
        applyUserInfo: res.data.data
      })
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },


  onPass: function (e) {
    console.log('formId==>', e.detail.formId)
    var that = this
    that.setData({
      rejectFlag: false,
      // formId: e.detail.formId
    })
    console.log('要通过的用户ID==>', that.data.applyUserInfo.applyId)
    let tmp = JSON.stringify(that.data.applyUserInfo.applyId);
    let result = 'registerFormId='
    result += tmp
    api_SubmitPassAuditResult(result, (res) => {
      console.log('审核结果==>', res)
      if (res.errmsg == 'ok') {
        wx.showToast({
          title: '通过成功！',
          icon: 'success',
          duration: 2000
        })
        //发送模板消息
        that.sendPassTemplateMessage()
        // 以全局变量作为上一层是否刷新的标记
        app.globalData.refreshUserToAuditList = true,
        app.globalData.refreshUserInfoDetail = true,

        wx.navigateBack({
          delta: 1
        })
      }
    })
  },

  onReject: function (e) {
    this.setData({
      rejectFlag: true
    })
  },

  //拒绝原因
  setRejectReason: function (e) {
    this.setData({
      rejectReason: e.detail.value
    })
  },

  onRejectConfirm: function (e) {
    let that = this
    console.log('formId==>', e.detail.formId)
    console.log('拒绝原因==>', that.data.rejectReason)
    //此处不再需要提交formId
    // that.setData({
    //   formId: e.detail.formId
    // })
    let tmp = that.data.rejectReason
    if (tmp !== '') {
      console.log('要拒绝的活动ID==>', that.data.applyUserInfo.applyId)
      let result = {
        registerFormId: that.data.applyUserInfo.applyId,
        reason: tmp
      }
      console.log('要提交的拒绝信息==>', result)
      api_SubmitRejectAuditResult(result, (res) => {
        console.log('审核结果==>', res)
        if (res.errmsg == 'ok') {
          //发送模板消息
          that.sendPassTemplateMessage()
          wx.showToast({
            title: '拒绝成功！',
            icon: 'success',
            duration: 2000
          })
          app.globalData.refreshUserToAuditList = true,
          app.globalData.refreshUserInfoDetail = true,
          wx.navigateBack({
            delta: 1
          })
        }
      })
    } else {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '请填写拒绝原因',
        duration: 2000,
        success() { },
      })
    }

  },

  sendPassTemplateMessage: function (e) {
    let that = this
    // 模板消息关键词参数
    let keywords = {
      "keyword1": {
        "value": that.data.rejectFlag ? "未通过" : "通过",
        "color": "#173177"
      },
      "keyword2": {
        "value": that.data.rejectFlag ? that.data.rejectReason : "欢迎注册同研",
        "color": "#173177"
      },
      "keyword3": {
        "value": that.data.applyUserInfo.nickname,
        "color": "#173177"
      },
    }
    let data = JSON.stringify(keywords);
    let messageData = {
      templateId: 'UlEUnIKaZkX_j_PuQ4t98v3sgazLakS_GlRBrRMjahs',
      page: '/pages/act/home/home',
      formId: that.data.applyUserInfo.formId,
      data: data,
      emphasisKeyword: "keyword1.DATA"
      // color: "#173177",
    }
    console.log('==>待发送的模板消息数据：', messageData)
    //调用发送模板消息API
    api_uc_SendTemplateMessage(messageData, (res) => {
      console.log('发送用户审核结果模板消息==>', res)
    })
  },
})
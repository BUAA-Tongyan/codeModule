// pages/uc/userAudited/userAudited.js
let {
  api_GetAuditDoneList
} = require("../../api/getData.js")

Page({

  /**
   * 页面的初始数据
   */
  data: {
    dataSource: [],
    // 上拉加载
    curPage: 0,
    maxSize: 0,
    bottom: -1,
    noDataFlag: false,

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.getAuditDoneList();
  },

  /*获取已审核用户列表*/
  getAuditDoneList: function() {
    console.log("加载函数执行==>")
    wx.showToast({
      title: '数据加载中',
      icon: 'loading',
      duration: 3000,
    });
    console.log("bottom: ", this.data.bottom)

    if (this.data.bottom >= this.data.maxSize) {
      console.log("==> 到达底部");
      this.setData({
        noDataFlag: true
      })
      wx.hideToast()
      return
    } else {
      let params = {
        page: this.data.curPage + 1,
        size: 15
      };

      console.log("请求头==========>", params)
      let auditedUsers = this.data.dataSource
      api_GetAuditDoneList(params, (res) => {
        console.log("#########--获取已审核用户列表--##########", res.data)
        //下拉刷新停止
        wx.stopPullDownRefresh()
        res.data.data.list.forEach(i => {
          auditedUsers.push(i)
        })
        this.setData({
          bottom: auditedUsers.length,
          dataSource: auditedUsers,
          curPage: res.data.data.curPage,
          maxSize: res.data.data.maxSize,
        })
        wx.hideToast()
      })
    }
  },

  /* 下拉刷新 */
  refresh: function () {
    console.log("==> 下拉刷新")
    this.setData({
      bottom: -1,
      dataSource: [],
      curPage: 0,
      maxSize: 0,
    })
    this.getAuditDoneList();
  },

  /*点击进入审核详情*/
  onClickDONE: function(e) {
    console.log('当前点击用户的applyId==>', e.currentTarget.dataset.index)
    wx.navigateTo({
      url: '../userAuditDetail/userAuditDetail?applyId=' + e.currentTarget.dataset.index
    })
  },

  //点击跳转活动详情页
  onClickTODO: function(e) {
    var $data = e.currentTarget.dataset.index;
    console.log('当前点击的活动ID==>', $data.actId)
    wx.navigateTo({
      url: '../actDetail/actDetail?actId=' + $data.actId,
      success: function(res) {
        // success
      },
      fail: function() {
        // fail
      },
      complete: function() {
        // complete
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    // 页面相关事件处理函数--监听用户下拉动作
    this.refresh();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    // 页面相关事件处理函数--监听下拉触底
    this.getAuditDoneList();
  },

  /**
   * 用户点击右上角分享
   */
  // onShareAppMessage: function() {

  // }
})
const app = getApp()
Page({
  data: {
    adminName: null
  },
  onLoad: function () {
    wx.cloud.init()
    this.fetchOrderList()
    this.data.adminName = app.globalData.userInfo.nickname
  },
  finishExchange: function (e) {
    wx.showModal({
      title: '提示',
      content: '确定核销？',
      success: res => {
        if (res.confirm) {
          wx.showLoading({
            title: '核销中...',
          })
          this.updateOrderList(e.target.dataset.id, this.data.adminName)
            .then(() =>
              this.fetchOrderList())
            .then(() => {
              wx.hideLoading()
              wx.showToast({
                title: '核销成功！',
              })
            })


        }
      }
    })
  },
  fetchOrderList: function () {
    const db = wx.cloud.database()
    db.collection('order')
      .where({
        isFinished: false
      })
      .get({
        success: res => {
          this.setData({
            orderList: res.data
          })
        }
      })
  },
  updateOrderList: function (id, adminName) {
    return wx.cloud.callFunction({
      name: 'updateOrderList',
      data: {
        id: id,
        adminName: adminName
      }
    }).then(res => console.log(res))
  }


})
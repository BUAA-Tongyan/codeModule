const app = getApp()
const {
  formatDate,
  formatTime
} = require('../../../utils/util')
const {
  api_GetUserState
} = require("../../api/getData.js")
Page({
  /*-------------------- 数据 --------------------*/
  data: {
    commodityList: [], // 积分商品列表
  },


  /*-------------------- 生命周期函数 --------------------*/
  onLoad: function () {
    wx.showToast({
      title: '数据加载中',
      icon: 'loading',
      duration: 3000,
    })
    wx.cloud.init({
      env: 'server-0d9db'
    })
    const db = wx.cloud.database()

    this.fetchCommoodityList() // 获取商品列表
  },
  onReady: function () {
    wx.hideToast()
  },

  onShow: function () {
    this.fetchCommoodityList() // 获取商品列表
  },

  
  /*-------------------- 普通函数 --------------------*/
  /**
   * 获取商品列表
   */
  fetchCommoodityList: function () {
    // 再次发起请求，刷新商品数量
    const db = wx.cloud.database()
    db.collection('pointsExchange')
      .get()
      .then(res => {
        this.setData({
          commodityList: res.data
        })
      })
  },

})
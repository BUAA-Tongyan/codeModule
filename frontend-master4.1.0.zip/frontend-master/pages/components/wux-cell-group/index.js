Component({
    externalClasses: ['wux-class'],
    relations: {
        '../wux-cell/index': {
            type: 'child',
            linked() {
                this.updateIsLastElement('../wux-cell/index')
            },
            linkChanged() {
                this.updateIsLastElement('../wux-cell/index')
            },
            unlinked() {
                this.updateIsLastElement('../wux-cell/index')
            },
        },
    },
    properties: {
        title: {
            type: String,
            value: '',
        },
        label: {
            type: String,
            value: '',
        },
    },
    methods: {
        updateIsLastElement() {
            const elements = this.getRelationNodes('../wux-cell/index')
            if (elements.length > 0) {
                const lastIndex = elements.length - 1
                elements.forEach((element, index) => {
                    element.updateIsLastElement(index === lastIndex)
                })
            }
        },
    },
})
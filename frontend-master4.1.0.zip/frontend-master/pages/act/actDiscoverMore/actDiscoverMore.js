// pages/act/actDiscover/actDiscover.js

let {
  api_GetDiscoverList,
  api_GetAllBanners,
} = require("../../api/getData.js")
Page({

  /**
   * 页面的初始数据
   */
  data: {
    swiperList: [],
    indicatorDots: true,
    autoplay: true,
    interval: 2000,
    duration: 1000,
    previousMargin: 0,
    nextMargin: 0,
    discoverList: [],

    curPage: -1,
    maxSize: 0,
    bottom: -1,
    //发现列表采用maxPage判断
    maxPage: 0,
    noDataFlag: true,
    isChecked_0: true,
    isChecked_1: true,
    isChecked_2: true,
    isChecked_3: true,
    isChecked_4: true,
    isChecked_5: true,
    isChecked_6: true,
    isChecked_7: true,

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    /*查找菜单值 */
    this.setData({
      isChecked_1:!wx.getStorageSync("club_info_1"),
      isChecked_0:!wx.getStorageSync("site_info_0"),
      isChecked_2:!wx.getStorageSync("shop_info_2"),
      isChecked_3:!wx.getStorageSync("minipro_info_3"),
      isChecked_4:!wx.getStorageSync("ministory_info_4"),
      isChecked_5:!wx.getStorageSync("calendar_info_5"),
      isChecked_6:!wx.getStorageSync("challenge14_6"),
      isChecked_7:!wx.getStorageSync("offeryes_7"),

    })
    /*获取发现列表*/
    api_GetAllBanners((res) => {
      if (res.length) {
        this.setData({
          swiperList: res
        });
      } else {
        this.setData({
          swiperList: [{
            url: '',
            img: 'http://www.buaa.edu.cn/__local/D/A6/CF/285952AD92970F08226AECCD5E3_C8F39F61_106FF.jpg',
            title: '学院路校区'
          }, {
            url: '',
            img: 'http://www.buaa.edu.cn/__local/8/18/50/33226DE0493305EA215E7F40655_C7255710_15B18.jpg',
            title: '图书馆'
          }, {
            url: '',
            img: 'http://www.buaa.edu.cn/__local/6/CE/0C/E18BA593FC960A0B53E7C1CD455_6532815F_38D87.jpg',
            title: '沙河校区'
          }]
        })
      }
      console.log("#########--轮播图--##########", this.data.swiperList)
    })
  },

  //点击关闭菜单
  switchblockonClickTODO: function (e) {
    var $data = e.currentTarget.dataset.id;
    console.log('当前点击的活动ID --> ', e.detail.value, e.target.id)
    var that = this;
    wx.setStorageSync(e.target.id,!e.detail.value)
    this.setData({
      // isChecked_1:!wx.getStorageSync("club_info_1"),
      // isChecked_0:!wx.getStorageSync("site_info_0"),
      // isChecked_2:!wx.getStorageSync("shop_info_2"),
      // isChecked_3:!wx.getStorageSync("minipro_info_3"),
      // isChecked_4:!wx.getStorageSync("ministory_info_4"),
      // isChecked_5:!wx.getStorageSync("calendar_info_5"),

    })
    // that.setData({
    //   isChecked_1:!
    // })
 
    // wx.navigateTo({
    //   url: '../actDetail/actDetail?actId=' + $data.actId,
    //   success: function (res) {
    //     // success
    //   },
    //   fail: function () {
    //     // fail
    //   },
    //   complete: function () {
    //     // complete
    //   }
    // })
  },

})

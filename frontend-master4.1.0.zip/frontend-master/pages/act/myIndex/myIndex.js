//  pages/act/myIndex/myIndex.js
var app = getApp()
let {
  api_GetUserState
} = require("../../api/getData.js")

Page({

  /**
   * 页面的初始数据
   */
  data: {
    motto: '你好',
    userInfo: {},
    userState: null,
    hasUserInfo: false,
    adminShow: false,
    showBack:false,
  },

  onShow: function(options){
    this.setData({
      mainColor:app.store.$state.mainColor
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {

    if (app.globalData.userInfoByToken) {
      console.log('userInfoByToken###############', app.globalData.userInfoByToken)
      this.setData({
        userInfo: app.globalData.userInfoByToken,
        hasUserInfo: true,
        adminShow: this.hasAuthorities(['ROLE_013_Admin', 'ROLE_005_Admin', 'ROLE_010_Admin'])
      })
    }
    /* 获取用户状态，包括信用分等 */
    api_GetUserState((res) => {
      console.log('用户状态==>', res.data.data)
      this.setData({
        userState: res.data.data
      })
    })

    /* 问候语设置 */
    let now = new Date();
    let hour = now.getHours();
    if (hour < 6) {
      this.setData({
        motto: "凌晨好！"
      })
    } else if (hour < 9) {
      this.setData({
        motto: "早上好！"
      })
    } else if (hour < 12) {
      this.setData({
        motto: "上午好！"
      })
    } else if (hour < 14) {
      this.setData({
        motto: "中午好！"
      })
    } else if (hour < 17) {
      this.setData({
        motto: "下午好！"
      })
    } else if (hour < 19) {
      this.setData({
        motto: "傍晚好！"
      })
    } else if (hour < 22) {
      this.setData({
        motto: "晚上好！"
      })
    } else {
      this.setData({
        motto: "夜里好！"
      })
    };
  },

  onPullDownRefresh: function () {
    // 页面相关事件处理函数--监听用户下拉动作
    wx.showToast({
      title: '数据加载中',
      icon: 'loading',
      duration: 1000,
    })
    this.refresh()
  },

  /**
   * 验证用户权限
   */
  hasAuthorities: function (checkList) {
    let authList = wx.getStorageSync("allAuthorities")
    for (let j = 0; j < checkList.length; j++) {
      for (let i = 0; i < authList.length; i++) {
        if (authList[i] === checkList[j]) {
          return true
        }
      }
    }
    return false
  },

  login(userinfo) { // 参数来额外接收用户数据
    app.login(userinfo, (err, res) => {
      if (err) return console.log('login function has error') // 如果登录方法出错则报错
      console.log('登录后存在全局变量中的用户信息==>', app.globalData)
      // 登录完毕后，调用用户数据等信息，使用 that.setData 写入
      this.setData({
        userInfo: app.globalData.userInfoByToken,
        hasUserInfo: true
      })
      /* 获取用户状态，包括信用分等 */
      api_GetUserState((res) => {
        console.log('用户状态==>', res.data.data)
        this.setData({
          userState: res.data.data
        })
      })
      let authList = wx.getStorageSync("allAuthorities")
      console.log('用户权限==>', authList)
      if (authList) {
        this.setData({
          adminShow: this.hasAuthorities(['ROLE_013_Admin', 'ROLE_005_Admin', 'ROLE_010_Admin'])
        })
      }
    })
  },

  logout: function (e) {
    this.setData({
      hasUserInfo: false,
      adminShow: false,
      userInfo: {},
      userState: null,
    })
    app.globalData.authoList = null,
      app.globalData.userInfoByToken = null
  },

  refresh: function (e) {
    console.log('动作:下拉刷新')
    /* 获取用户状态，包括信用分等 */
    api_GetUserState((res) => {
      console.log('用户状态==>', res.data.data)
      this.setData({
        userState: res.data.data
      })
      //下拉刷新停止
      wx.stopPullDownRefresh()
      wx.hideToast()
    })
  }

})
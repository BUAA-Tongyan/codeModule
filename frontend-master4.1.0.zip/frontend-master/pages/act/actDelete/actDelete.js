let {
  api_GetActivityInfo,
  api_DeleteActivity
} = require("../../api/getData.js")
import {
  $wuxToptips
} from '../../components/wux-index'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    showDeleteBtnConfirm: false,
    deleteReason: '',
    value: '',
    dataSource: {
      actInfo: {},
      selectedFlag: false, // 参与人展开折叠标记
    },
    onSearchFlag: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },
  //搜索相关函数
  onChange(e) {
    this.setData({
      value: e.detail
    });
  },
  onSearch(e) {
    let str = 'dataSource.actInfo'
    this.setData({
      [str]: {},
      showDeleteBtnConfirm: false,
      // onSearchFlag: true
    })

    console.log('需要搜索的活动ID==>', e.detail)
    /*获取活动详情*/
    let params = this.data.value;
    api_GetActivityInfo(params, (res) => {
      console.log("#########--活动详情--##########", res.data.data)
      let str = 'dataSource.actInfo'
      var data=res.data.data


      var imgUrl = data.summary.split("imgUrl:")[1]
      console.log("拿到的附图链接 --> ", imgUrl)
      data.summary = data.summary.split("imgUrl:")[0]
      data.imgUrl = imgUrl


      if (data.summary.search("itemprice") != -1) {
        var items = JSON.parse(data.summary)
        data.itemprice = "物品价格：" + items.itemprice;
        data.itemtype = "物品种类：" + items.itemtype;
        data.detailImg = items.detailImg;
        data.summary = "物品详情：" + items.summary;
      } else {
        data.summary = data.summary
      }
      if (data.title.search("transaction") != -1) {
        var titleitems = JSON.parse(data.title)
        data.transaction = titleitems.transaction;
        if (titleitems.headImg.indexOf("http://www.buaagsu.com/yan/static/") != -1) {
          data.headImg = titleitems.headImg
        }
        else {
          data.headImg = "http://www.buaagsu.com/yan/static/buaainfoImg" + titleitems.headImg
        }
        // data.headImg = titleitems.headImg;
        data.title = titleitems.title;
      } else {
        data.title = data.title
      }
      if (data.contactName.search("qrcode") != -1) {
        data.qrcode = JSON.parse(data.contactName).qrcode;
        data.contactName = JSON.parse(data.contactName).contactName;
      } else {
        data.contactName = data.contactName
      }
      data.imgUrl=data.headImg
      if (data) {
        this.setData({
          [str]: data,
          showDeleteBtn: true,
          onSearchFlag: true
        })
      }
    })
  },

  toDeleteAct: function(e) {
    this.setData({
      showDeleteBtnConfirm: true
    })
  },
  setDeleteReason: function(e) {
    this.setData({
      deleteReason: e.detail.value
    })
  },

  deleteActivity: function(e) {
    let that = this
    console.log('formId==>', e.detail.formId)
    console.log('取消原因==>', that.data.deleteReason)
    that.setData({
      formId: e.detail.formId
    })
    let tmp = that.data.deleteReason
    if (tmp.length > 0) {
      console.log('要取消的活动ID==>', that.data.dataSource.actInfo.actId)
      let result = {
        actId: that.data.dataSource.actInfo.actId,
        reason: tmp
      }
      console.log('要提交的取消信息==>', result)
      wx.showModal({
        title: '提示',
        content: '此操作不可撤回，确认删除？',
        success: function(e) {
          api_DeleteActivity(result, (res) => {
            console.log('删除结果==>', res)
            if (res.errmsg == 'ok') {
              //发送模板消息
              // that.sendPassTemplateMessage()
              wx.showToast({
                title: '删除成功',
                icon: 'success',
                duration: 2000
              })
              setTimeout(function () {
                wx.navigateBack({
                  delta: 1
                })
              }, 2000)
            }
          })
        }
      })
    } else {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '请填写活动取消原因',
        duration: 2000,
        success() {},
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },

  // 参与人展开折叠选择 
  showPaticipate: function(e) {
    console.log(this.data.dataSource.selectedFlag)
    let tmp = this.data.dataSource.selectedFlag
    let str = 'dataSource.selectedFlag'
    this.setData({
      [str]: !tmp
    })
  },
})
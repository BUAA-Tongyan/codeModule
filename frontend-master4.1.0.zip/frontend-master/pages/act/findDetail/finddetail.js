// pages/act/actDiscover/actDiscover.js

let {
    api_GetDiscoverList
} = require("../../api/getData.js")
Page({

    /**
     * 页面的初始数据
     */
    data: {
        swiperList: [{
            url: "",
            img: "",
        }],

        discoverList: [],
        curType: -1, // 当前显示的类别
        typeName: '', // 当前显示的类别名称
        curSearch: "",  // 当前搜索内容
        curPage: -1,
        maxSize: 0,
        bottom: -1,
        //发现列表采用maxPage判断
        maxPage: null,
        noDataFlag: false,
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        let title;
        if (options.type) {
            title = {"5": "场所信息", "6": "社团组织", "7": "微故事"}[parseInt(options.type)];
            this.setData({
                curType: options.type,
                typeName: title
            });
            wx.setNavigationBarTitle({title: title});
        }
        /*获取发现列表*/
        this.getDiscoverList();

        /*获取顶部banner*/
        this.getBanner(title);
    },

    getBanner: function (title) {
        wx.cloud.init();
        const db = wx.cloud.database();
        let this_ = this;
        console.log('finddetail-'+title);
        db.collection('banner').doc('finddetail-'+title).get({
            success: function (res) {
                this_.setData({swiperList: [res.data]});
                console.log(res.data)
            }
        })
    },


    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {
        this.refresh();
    },


    getDiscoverList: function (e) {
        wx.showToast({
            title: '数据加载中',
            icon: 'loading',
            duration: 3000,
        });

        let params = {
            page: this.data.curPage + 1,
            size: 3,
            type: this.data.curType,
            search: this.data.curSearch ? encodeURIComponent('%' + this.data.curSearch + '%') : "",
        };
        let tmp = this.data.discoverList;
        api_GetDiscoverList(params, (res) => {
            console.log("#########--获取发现列表--##########", res.data)
            //下拉刷新停止
            wx.stopPullDownRefresh()
            wx.hideToast()
            res.data.data.list.forEach(i => {
                // 临时处理
                if (i.headImgLink == "") {
                    i.headImgLink = '/images/discDemo-2.35x1.jpg'
                }
                let t = i.introduction.split('\n');
                if (t.length != 2) {
                    i.keywords = i.type
                } else {
                    i.keywords = t[1].split(' ').join('、');
                    i.introduction = t[0];
                }
                tmp.push(i)
            })
            this.setData({
                bottom: tmp.length,
                discoverList: tmp,
                curPage: res.data.data.curPage,
                // maxSize: res.data.data.size,
                maxPage: res.data.data.maxPage - 1,
            });

            if (res.data.data.curPage === res.data.data.maxPage || res.data.data.maxPage === 0) {
                console.log("==> 到达底部");
                this.setData({
                    noDataFlag: true
                })
                wx.hideToast()
                return
            }
        })
    },

    /* 下拉刷新 */
    refresh: function () {
        console.log("==> 下拉刷新")
        this.setData({
            bottom: -1,
            discoverList: [],
            curPage: -1,
            maxSize: 0,
        })
        this.getDiscoverList();
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
        this.getDiscoverList();
    },

    onChange: function (e) {
        console.log('onChange', e);
        this.setData({
            curSearch: e.detail
        });
    },
    onSearch: function (e) {
        console.log('onSearch', e);
        this.setData({
            discoverList: [],
            curPage: -1,
            maxSize: 0,
            bottom: -1,
            maxPage: null,
            noDataFlag: false,
        });
        this.getDiscoverList();
    }
});
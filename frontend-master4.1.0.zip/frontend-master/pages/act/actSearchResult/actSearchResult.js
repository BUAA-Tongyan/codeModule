// pages/act/actSearchResult/actSearchResult.js
let {
  api_SearchAct
} = require("../../api/getData.js")

Page({

  /**
   * 页面的初始数据
   */
  data: {
    curPage: 0,
    // dataSource: [],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    console.log('===========================', options)
    let keywords = options.keywords
    let searchType = options.searchType
    let params = {
      keywords: keywords,
      searchType: searchType,
      page: this.data.curPage + 1,
      size: 10
    };

    api_SearchAct(params, (res) => {
      if (res.errcode == 0) {
        console.log("#########--搜索结果--##########", res.data.list)

        let researchResult = []
        res.data.list.forEach(i => {
          if (i.state !== "已取消") {
            researchResult.push(i)
          }
        })

        this.setData({
          dataSource: researchResult,
        })

        if (res.data.list.length == 0) {
          setTimeout(function() {
            wx.navigateBack({
              delta: 1
            })
          }, 2000)
        }
      } else {
        wx.showToast({
          title: res.errmsg,
          icon: 'none',
          duration: 2000
        })
        setTimeout(function() {
          wx.navigateBack({
            delta: 1
          })
        }, 2000)
      }
    })
  },

  //点击跳转活动详情页
  onClickTODO: function(e) {
    var $data = e.currentTarget.dataset.index;
    console.log('当前点击的活动ID==>', $data.actId)
    wx.navigateTo({
      url: '../actDetail/actDetail?actId=' + $data.actId,
      success: function(res) {
        // success
      },
      fail: function() {
        // fail
      },
      complete: function() {
        // complete
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  // /**
  //  * 用户点击右上角分享
  //  */
  // onShareAppMessage: function() {

  // }
})
// pages/act/itemFleaMarket/itemFleaMarket.js

let {
  api_uc_GetInfoByToken,
  api_GetAllBanners,
  api_GetAllAuthorities,
  api_GetActList,
  api_GetActivityInfo,
  api_LikeAct
} = require("../../api/getData.js")
const app = getApp()

Page({
  data: {
    currentTab: 0,
    swiperList: [],
    indicatorDots: true,
    autoplay: true,
    interval: 2000,
    duration: 1000,
    previousMargin: 0,
    nextMargin: 0,
    dataSource: [],
    dataSourceSell:[],
    dataSourceRecycle:[],
    isloading: false,
    imgtemp: '',
    // 上拉加载
    curPage: 0,
    maxSize: 0,
    // 滑动事件监控
    lastX: 0, //滑动开始x轴位置
    lastY: 0, //滑动开始y轴位置
    text: "没有滑动",
    flag: 0,
    // 无更多数据标记
    noDataFlag: false,
    color:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let style = wx.getStorageSync('style')
    switch (style){
      case "lightblue" : this.setData({
        color:"#3367DD"
      })
      break
      case "blue" : this.setData({
        color:"#475793"
      })
      break
      case "black" : this.setData({
        color:"black"
      })
      break
      case "red" : this.setData({
        color:"#C32B20"
      })
      break

    }
    wx.showToast({
      title: '数据加载中',
      icon: 'loading',
      duration: 3000,
    });

    // if (wx.getStorageSync('token')) {
    /*获取轮播图地址,没有则读取本地轮播图数据*/
    api_GetAllBanners((res) => {

      this.setData({
        swiperList: [{
          url: 'https://mp.weixin.qq.com/s/mg7-GkOwL5Qn2Xhs18Ns9Q',
          img: 'http://www.buaagsu.com/yan/static/buaaBanner/FleaBanner.jpg',
          title: '同研交易规则（试行）'
        }]
      })
      console.log("#########--轮播图--##########", this.data.swiperList)
    })
    /*获取主页活动列表*/
    this.getHomeActList();
    // this.refresh();
    console.log("==> 当前页面数据加载为", this.data)
  },

  onReady: function (options) {
    // wx.hideToast()
  },

  onPullDownRefresh: function () {
    // 页面相关事件处理函数--监听用户下拉动作
    this.refresh();
  },
  onReachBottom: function () {
    // 页面相关事件处理函数--监听下拉触底
    this.getHomeActList();
  },

  /**************以上是生命周期********************以下是自定义函数**************************/

  /*获取主页活动列表*/
  getHomeActList: function () {
    console.log("==> 加载函数执行")
    wx.showToast({
      title: '数据加载中',
      icon: 'loading',
      duration: 3000,
    });
    console.log("bottom: ", this.data.bottom)
    if (this.data.bottom >= this.data.maxSize) {
      console.log("==> 到达底部");
      this.setData({
        noDataFlag: true
      })
      wx.hideToast()
      return
    } else {
      let params = {
        page: this.data.curPage + 1,
        size: 5
      };
      let alldata = this.data.dataSource

      let c=0;
      while (true) {
        c=c+1
        api_GetActList(params, (res) => {
          console.log("#########--活动列表--##########", res.data)
          //下拉刷新停止
          wx.stopPullDownRefresh()

          var dataSource = []
          if (this.data.dataSource) {
            dataSource = this.data.dataSource
          }
          var sells = []
          if (this.data.dataSourceSell) {
            sells = this.data.dataSourceSell
          }
          var recycles = []
          if (this.data.dataSourceRecycle) {
            recycles = this.data.dataSourceRecycle
          }

          console.log("#########--recycles--##########", recycles)
          for (var index in res.data.list) {
            var t = res.data.list[index]

            if (t.domains[0] == '跳蚤市场') {
              var titlestr = JSON.parse(t.title)
              // 题目修改
              if (t.title.search("transaction") != -1) {
                if (titlestr.headImg.indexOf("http://www.buaagsu.com/yan/static/") != -1) {
                  t.headImg = titlestr.headImg
                }
                else {
                  t.headImg = "http://www.buaagsu.com/yan/static/buaainfoImg" + titlestr.headImg
                }
                t.title = '【' + titlestr.transaction + '】' + titlestr.title
              } else {
                t.title = t.title
              }
              t.price = titlestr.itemprice
              t.contactName = titlestr.plc
              if (titlestr.transaction == '售') {
                sells.push(t)
              }
              else {
                recycles.push(t)
              }
              // weishalong.push(t)
            }
          }
          this.setData({
            dataSourceSell: sells,
            dataSourceRecycle: recycles,
            curPage: res.data.curPage,
            maxSize: res.data.maxSize,
          })
          if (this.data.currentTab == 0) {
            this.setData({
              dataSource: sells,
            })
          }
          else {
            this.setData({
              dataSource: recycles,
            })
          }
          console.log("==> 展示数据出售", this.data.dataSourceSell);
          console.log("==> 展示数据回收", this.data.dataSourceRecycle);
          wx.hideToast()
        })
        var _this=this
        params.page = params.page+1
        console.log("条件", _this.data.dataSourceSell.length, _this.data.dataSourceRecycle.length)
        // if (sells.length > 6 && recycles.length > 6){
        //   break
        // }
        if (c>1){
          break
        }
      }

    }
  },
  /* 下拉刷新 */
  refresh: function () {
    console.log("==> 下拉刷新")
    this.setData({
      bottom: -1,
      dataSource: [],
      dataSourceSell:[],
      dataSourceRecycle:[],
      curPage: 0,
      maxSize: 0,
    })
    this.getHomeActList();
  },

  //滑动切换
  swiperTab: function (e) {
    var that = this;
    that.setData({
      currentTab: e.detail.current
    });

    if (e.detail.current == 0) {

      console.log("==> 当前再售卖区")
      that.setData({
        currentTab: e.detail.current,
        dataSource: that.data.dataSourceSell,
      })
    }
    else {

      console.log("==> 当前再会收区")
      that.setData({
        currentTab: e.detail.current,
        dataSource: that.data.dataSourceRecycle,
      })
    }
  },
  //点击切换
  clickTab: function (e) {
    var that = this;
    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      
      if (e.target.dataset.current==0){

        that.setData({
          currentTab: e.target.dataset.current,
          dataSource: that.data.dataSourceSell,
        })
      }
      else {

        that.setData({
          currentTab: e.target.dataset.current,
          dataSource: that.data.dataSourceRecycle,
        })
      }
    }
  },
  /*点击喜欢活动，只在微沙龙和活动广场首页显示*/
  loveButtonClick: function (e) {
    let loveId = e.currentTarget.dataset.index.actId
    let index = 0
    //渲染层样式改变
    this.data.dataSource.forEach(i => {
      if (i.actId == loveId) {
        let step = i.favoritedQuantity
        if (i.hasFavorited) {
          step--
        } else {
          step++
        }
        let str1 = 'dataSource[' + index + '].hasFavorited'
        let str2 = 'dataSource[' + index + '].favoritedQuantity'
        this.setData({
          [str1]: !i.hasFavorited,
          [str2]: step
        })
      }
      index++
    })
    // 同步更改后台数据
    console.log('点击活动的actID==>', loveId)
    let param = 'actId='
    param += loveId
    api_LikeAct(param, (res) => {
      console.log('更改喜爱状态回调==>', res)
    })
  },

  //点击跳转活动详情页
  onClickTODO: function (e) {
    var $data = e.currentTarget.dataset.index;
    console.log('当前点击的物品ID --> ', $data.actId)
    wx.navigateTo({
      url: '../itemDetail/itemDetail?actId=' + $data.actId,
      success: function (res) {
        // success
      },
      fail: function () {
        // fail
      },
      complete: function () {
        // complete
      }
    })
  },

  //////////////////////////////////////////////////////////////////////////////////////
  handletouchmove: function (event) {
    // console.log(event)
    if (this.data.flag !== 0) {
      return
    }
    let currentX = event.touches[0].pageX;
    let currentY = event.touches[0].pageY;
    let tx = currentX - this.data.lastX;
    let ty = currentY - this.data.lastY;
    let text = "";
    //左右方向滑动
    if (Math.abs(tx) > Math.abs(ty)) {
      if (tx < 0) {
        text = "向左滑动";
        this.data.flag = 1
      } else if (tx > 0) {
        text = "向右滑动";
        this.data.flag = 2
      }
    }
    //上下方向滑动
    else {
      if (ty < 0) {
        text = "向上滑动";
        this.data.flag = 3
        wx.hideTabBar({
          animation: true
        })
      } else if (ty > 0) {
        text = "向下滑动";
        this.data.flag = 4
        wx.showTabBar({
          animation: true
        })
      }
    }
    //将当前坐标进行保存以进行下一次计算
    this.data.lastX = currentX;
    this.data.lastY = currentY;
    this.setData({
      text: text,
    });
  },

  handletouchtart: function (event) {
    // console.log(event)
    this.data.lastX = event.touches[0].pageX;
    this.data.lastY = event.touches[0].pageY;
  },
  handletouchend: function (event) {
    this.data.flag = 0
    this.setData({
      text: "没有滑动",
    });
  },

})


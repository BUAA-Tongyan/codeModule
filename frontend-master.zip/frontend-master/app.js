//app.js
const Store = require('./utils/Store')
const $ = require('./utils/promisify')
let {
  formatDate,
  formatTime,
  formatTomDate
} = require('./utils/util.js')
let config = require("./config.js")
let {
  api_GetRealUserInfo,
  api_uc_GetInfoByToken,
  api_GetAllAuthorities
} = require("./pages/api/getData.js")

let store = new Store({
  state: {
    mainColor: 'blue'
  }
})
App({
  store,


  /************************************************** 全局初始信息 **************************************************/
  globalData: {},
  /**
   *小程序初始化完成时，会触发onLaunch（全局只触发一次）
   */
  onLaunch: function() {

    wx.cloud.init({
      traceUser: true,
    })
    const mainColor = wx.getStorageSync('mainColor') // 从本地存储中获取
    if (mainColor) {
      this.store.setState({
        mainColor
      })
    }
    const db = wx.cloud.database() // 从云端获取
    const openId = wx.getStorageSync('openId')
    if (openId) {
      db.collection('userSkins').doc(openId)
        .get()
        .then(res => {
          console.log('获取:用户设置', res)
          this.store.setState({
            mainColor: res.data.color
          })
        })

    }


    var _this = this
    wx.setStorageSync("club_info_1", false)
    wx.setStorageSync("site_info_0", false)
    wx.setStorageSync("shop_info_2", false)
    wx.setStorageSync("minipro_info_3", false)
    wx.setStorageSync("calendar_info_5", false)
    wx.setStorageSync("ministory_info_4", false)  
    wx.setStorageSync("challenge14_6", false)  
    wx.setStorageSync("offeryes_7", false)  
    wx.setStorageSync("style", "blue")
    wx.login({
      success: res => {
        console.log("微信登录获取code==>", res)
        if (res.code) {
          // 发送 res.code 到后台换取 openId, sessionKey, unionId
          wx.request({
            url: config.service + '/buaa/autho/wx_app_auth',
            data: {
              code: res.code,
            },
            method: "GET",
            success: function(res) {
              console.log('向后端发送code换取信息==>:', res.data.data)
              wx.setStorageSync("session_id", res.data.data.session_id)
              wx.setStorageSync("token", res.data.data.user_info.token)
              //控制菜单显示的缓存
              // 获取用户的当前设置。返回值中只会出现小程序已经向用户请求过的权限。
              wx.getSetting({
                success(res) {
                  console.log('已经向用户请求过的权限==>', res.authSetting)
                  if (res.authSetting["scope.userInfo"]) {
                    wx.getUserInfo({
                      success: function(res) {
                        console.log('获取的用户信息==>', res)
                        let formData = {
                          encryptedData: res.encryptedData,
                          iv: res.iv
                        }
                        api_GetRealUserInfo(formData, (res) => {
                          // 将用户信息、匿名识别符发送给服务器
                          console.log('获取用户解密后的信息==>', res)
                          if (res.errmsg == 'ok') {
                            wx.setStorageSync("token", res.data.token)
                            _this.globalData.userInfo = res.data

                            /*获取用户权限*/
                            api_GetAllAuthorities((res) => {
                              console.log("登录动作之获取用户权限==>", res.data)
                              wx.setStorageSync("allAuthorities", res.data.data)
                            })

                            /*获取用户信息并存在全局变量中*/
                            api_uc_GetInfoByToken((res) => {
                              console.log('登录动作之获取同研用户信息==>', res)
                              if (res.data.errmsg == "未注册") {
                                console.log('该用户未注册==>')
                                _this.globalData.userNotSignUp = true
                              } else {
                                _this.globalData.userInfoByToken = res.data.data
                              }
                            })

                          }
                        })

                      }
                    })
                  }

                }
              })
            },
            fail: function(errMsg) {
              console.log(errMsg)
            }
          })
        } else {
          console.log('获取用户登录态失败！' + res.errMsg)
        }
      }
    })
  },
 onShareAppMessage: function() {
    const promise = new Promise(resolve => {
      setTimeout(() => {
        resolve({
          title: '同研————开启新视界'
        })
      }, 20) /*20是延时*/ 
    })
    return {
      title: '同研————开启新视界',
      path: 'pages/act/myIndex/myIndex',
      promise 
    }
},
  //转发到朋友圈
 onShareTimeline(){},
  onShow: function(options) {
    //验证成功后，验证码小程序页面关闭，验证结果会返回给调用验证码的小程序页面。捕获验证结果captchaResult
    // 解决各类回调的兼容问题
    if (!this.captchaTicketExpire) this.captchaTicketExpire = {};

    if (options.scene === 1038 && options.referrerInfo.appId === 'wx5a3a7366fd07e119') {
      const result = options.referrerInfo.extraData;
      if (result.ret === 0) {
        const ticket = result.ticket;
        if (!this.captchaTicketExpire[ticket]) {
          this.captchaResult = result;
          this.captchaTicketExpire[ticket] = true;
        }
      } else {
        // 用户关闭了验证码
      }
    }

    let option = JSON.stringify(options);
    console.log('app.js option-----' + option)
    console.log('app.js>>options.scene--------------------' + options.scene);
    this.globalData.resultScene = this.sceneInfo(options.scene);

  },

  login(userinfo, callback) {
    var _this = this
    wx.login({}) // 只有当你需要使用微信登录鉴别用户，才需要用到它，用来获取用户的匿名识别符
    if (userinfo.detail.errMsg == 'getUserInfo:ok') {
      console.log('===============用户信息', userinfo)
      let formData = {
        encryptedData: userinfo.detail.encryptedData,
        iv: userinfo.detail.iv
      }
      api_GetRealUserInfo(formData, (res) => {

        // 将用户信息、匿名识别符发送给服务器
        console.log('获取用户解密后的信息==>', res)
        if (res.errmsg == 'ok') {
          wx.setStorageSync("token", res.data.token)
          // wx.setStorageSync("userinfo", res.data)
          _this.globalData.userInfo = res.data

          /*获取用户权限*/
          api_GetAllAuthorities((res) => {
            console.log("登录动作之获取用户权限==>", res.data)
            // globalData方法会遇到同步问题，故弃用
            // _this.globalData.authoList = res.data.data
            wx.setStorageSync("allAuthorities", res.data.data)
          })

          /*获取用户信息并存在全局变量中*/
          api_uc_GetInfoByToken((res) => {
            console.log('登录动作之获取同研用户信息==>', res)
            if (res.data.errmsg == "未注册") {
              wx.navigateTo({
                url: '/pages/act/register/register',
              })
            } else {
              _this.globalData.userInfoByToken = res.data.data
              callback(null, res)
            }
          })

        }
      })
    } else if (userinfo.detail.errMsg == 'getUserInfo:fail auth deny') { // 当用户点击拒绝时
      wx.showModal({
        title: '提示',
        content: '需要授权才能登录',
      })
      callback('fail to modify scope', null)
    }
  },

  //场景值判断
  sceneInfo: function(s) {
    var scene = [];
    switch (s) {
      case 1001:
        scene.push(s, "发现栏小程序主入口");
        break;
      case 1005:
        scene.push(s, "顶部搜索框的搜索结果页");
        break;
      case 1006:
        scene.push(s, "发现栏小程序主入口搜索框的搜索结果页");
        break;
      case 1007:
        scene.push(s, "单人聊天会话中的小程序消息卡片");
        break;
      case 1008:
        scene.push(s, "群聊会话中的小程序消息卡片");
        break;
      case 1011:
        scene.push(s, "扫描二维码");
        break;
      case 1012:
        scene.push(s, "长按图片识别二维码");
        break;
      case 1014:
        scene.push(s, "手机相册选取二维码");
        break;
      case 1017:
        scene.push(s, "前往体验版的入口页");
        break;
      case 1019:
        scene.push(s, "微信钱包");
        break;
      case 1020:
        scene.push(s, "公众号profile页相关小程序列表");
        break;
      case 1022:
        scene.push(s, "聊天顶部置顶小程序入口");
        break;
      case 1023:
        scene.push(s, "安卓系统桌面图标");
        break;
      case 1024:
        scene.push(s, "小程序profile页");
        break;
      case 1025:
        scene.push(s, "扫描一维码");
        break;
      case 1026:
        scene.push(s, "附近小程序列表");
        break;
      case 1027:
        scene.push(s, "顶部搜索框搜索结果页“使用过的小程序”列表");
        break;
      case 1028:
        scene.push(s, "我的卡包");
        break;
      case 1029:
        scene.push(s, "卡券详情页");
        break;
      case 1031:
        scene.push(s, "长按图片识别一维码");
        break;
      case 1032:
        scene.push(s, "手机相册选取一维码");
        break;
      case 1034:
        scene.push(s, "微信支付完成页");
        break;
      case 1035:
        scene.push(s, "公众号自定义菜单");
        break;
      case 1036:
        scene.push(s, "App分享消息卡片");
        break;
      case 1037:
        scene.push(s, "小程序打开小程序");
        break;
      case 1038:
        scene.push(s, "从另一个小程序返回");
        break;
      case 1039:
        scene.push(s, "摇电视");
        break;
      case 1042:
        scene.push(s, "添加好友搜索框的搜索结果页");
        break;
      case 1044:
        scene.push(s, "带shareTicket的小程序消息卡片");
        break;
      case 1047:
        scene.push(s, "扫描小程序码");
        break;
      case 1048:
        scene.push(s, "长按图片识别小程序码");
        break;
      case 1049:
        scene.push(s, "手机相册选取小程序码");
        break;
      case 1052:
        scene.push(s, "卡券的适用门店列表");
        break;
      case 1053:
        scene.push(s, "搜一搜的结果页");
        break;
      case 1054:
        scene.push(s, "顶部搜索框小程序快捷入口");
        break;
      case 1056:
        scene.push(s, "音乐播放器菜单");
        break;
      case 1058:
        scene.push(s, "公众号文章");
        break;
      case 1059:
        scene.push(s, "体验版小程序绑定邀请页");
        break;
      case 1064:
        scene.push(s, "微信连Wifi状态栏");
        break;
      case 1067:
        scene.push(s, "公众号文章广告");
        break;
      case 1068:
        scene.push(s, "附近小程序列表广告");
        break;
      case 1072:
        scene.push(s, "二维码收款页面");
        break;
      case 1073:
        scene.push(s, "客服消息列表下发的小程序消息卡片");
        break;
      case 1074:
        scene.push(s, "公众号会话下发的小程序消息卡片");
        break;
      case 1089:
        scene.push(s, "微信聊天主界面下拉");
        break;
      case 1090:
        scene.push(s, "长按小程序右上角菜单唤出最近使用历史");
        break;
      case 1092:
        scene.push(s, "城市服务入口");
        break;
      default:
        scene.push("未知入口");
        break;
    }
    return scene;
  },

  globalData: {
    userInfo: null,
    userInfoByToken: null,
    authoList: null,
    resultScene: null,
    refreshUserToAuditList: false,
    refreshUserInfoDetail: false,
    userNotSignUp: false,
    systemInfo: wx.getSystemInfoSync() || {},
  },

  timePicker: {
    date: formatDate(new Date()),
    time: formatTime(new Date()),
    nextdate: formatTomDate(new Date()),
  },

  //多张图片上传
  uploadimg: function(data) {
    var that = this,
      i = data.i ? data.i : 0, //当前上传的哪张图片
      success = data.success ? data.success : 0, //上传成功的个数
      fail = data.fail ? data.fail : 0; //上传失败的个数
    wx.uploadFile({
      url: data.url,
      filePath: data.path[i],
      name: 'file', //这里根据自己的实际情况改
      formData: null, //这里是上传图片时一起上传的数据
      success: (resp) => {
        success++; //图片上传成功，图片上传成功的变量+1
        // console.log(resp)
        // console.log(i);
        //这里可能有BUG，失败也会执行这里,所以这里应该是后台返回过来的状态码为成功时，这里的success才+1
      },
      fail: (res) => {
        fail++; //图片上传失败，图片上传失败的变量+1
        // console.log('fail:' + i + "fail:" + fail);
        wx.showModal({
          title: '提示',
          content: '上传失败',
          showCancel: false
        })
      },
      complete: () => {
        console.log(i);
        i++; //这个图片执行完上传后，开始上传下一张
        if (i == data.path.length) { //当图片传完时，停止调用          
          console.log('所有图片上传完毕');
          console.log('成功：' + success + " 失败：" + fail);
        } else { //若图片还没有传完，则继续调用函数
          console.log(i);
          data.i = i;
          data.success = success;
          data.fail = fail;
          that.uploadimg(data);
        }

      }
    });
  },
})
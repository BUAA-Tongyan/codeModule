/**
 * promise化接口
 */
function wxPromisify(functionName, params) {
    return new Promise((resolve, reject) => {
        wx[functionName]({
            ...params,
            success: res => resolve(res),
            fail: res => reject(res)
        });
    });
}

/**
 * 延时函数
 */
function sleep(interval) {
    return new Promise(resovle => {
        setTimeout(() => {
            resovle()
        }, interval)
    })
}

/**
 * 登录
 */
function login(params = {}) {
    return wxPromisify('login', params);
}

/**
 * 获取用户信息
 */
function getUserInfo(params = {}) {
    return wxPromisify('getUserInfo', params);
}

/**
 * 获取用户权限
 */
function getSetting(params = {}) {
    return wxPromisify('getSetting', params);
}

/**
 * 向后台发送 get 请求
 */
function request(params = {}) {
    return wxPromisify('request', params);
}

/**
 * 模态框
 */
function showModal(params = {}) {
    return wxPromisify('showModal', params);
}

/**
 * 模态框,简约版本
 */
function remind(content){
    return showModal({
        title:'提示',
        showCancel:false,
        content:content
    })
}

module.exports = {
    sleep,
    login,
    getUserInfo,
    getSetting,
    request,
    showModal,
    remind
}
// 配置后端网址1
module.exports = {
  // service: "https://test.buaagsu.com"
  // service: "http://buaawx.nat300.top"
  service: "https://www.buaagsu.com"
}
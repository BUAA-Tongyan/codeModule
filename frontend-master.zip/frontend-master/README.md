# 同研微信小程序
 北京航空航天大学研究生会同研创新中心核心业务，长期维护。

## 开发工作流
master分支为线上代码，每人新建一个自己名字的分支进行开发，开发并测试完毕后，通过PR合并到master分支


## 小程序提交版本号规范
小程序上传的代码需要在git中提交，以git提交id作为小程序的版本号的最后一段：

<img src="https://user-images.githubusercontent.com/8682073/113545960-b03df300-961d-11eb-93b1-83760ad6e466.png" width=600/>

## 开发原则与规范
### 1. 代码精简
- 提倡可复用、模块化，在保证功能的前提下，代码尽量简洁。鼓励在合适的时候对自己所写的部分进行重构。

### 2. 样式风格统一
- UI设计要整体风格一致，注重细节（比如背景，圆角等），提供商业产品级的用户体验；
- 注意不同客户端的样式兼容问题，布局和大小尽量使用rpx等单位；
- 注意wxss文件的污染问题，尽量少在app.json里引入template的样式文件。

### 3. 注释清晰
- 为了增强代码的可读性，便于后来者理解代码，应在必要的地方写上注释。

---
## 开发者工具
* [官方文档](https://mp.weixin.qq.com/debug/wxadoc/dev/index.html?t=2017727)
* [Github微信小程序开发资源汇总](https://github.com/justjavac/awesome-wechat-weapp)
---
* [推荐轻量级代码编辑器 **VSCode** ](https://code.visualstudio.com)

> 官方微信开发者工具渐趋完善，第三方代码编辑器推荐VS Code。Visual Studio Code (简称 VS Code / VSC) 是一款免费开源的现代化轻量级代码编辑器，支持几乎所有主流的开发语言的语法高亮、智能代码补全、自定义热键、括号匹配、代码片段、代码对比 Diff、GIT 等特性，支持插件扩展，并针对网页开发和云端应用开发做了优化。软件跨平台支持 Win、Mac 以及 Linux。

---

## Git使用建议
- Git教程可参见官网文档和网上资源，如 [廖雪峰Git教程](https://www.liaoxuefeng.com/wiki/0013739516305929606dd18361248578c67b8067c8c017b000)；


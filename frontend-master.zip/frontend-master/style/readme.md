base/widget/iconfont.wxss/weui均是weui
material和awesome5
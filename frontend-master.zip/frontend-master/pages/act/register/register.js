import {
  $wuxToptips
} from '../../components/wux-index'
let {
  api_SubmitUserInfo,
  api_VerifyByPhone,
  api_GetRegisterFormData
} = require("../../api/getData.js")
import {
  $wuxCountDown
} from '../../components/wux-index'
const app = getApp()

Page({
  data: {
    gender: ["男", "女"],
    indexGender: 0,
    types: ["学生", "教职工"],
    indexType: 0,
    institutes: ["--请选择--","材料科学与工程学院", "电子信息工程学院", "自动化科学与电气工程学院", "能源与动力工程学院", "航空科学与工程学院", "计算机学院", "机械工程及自动化学院", "经济管理学院", "数学与系统科学学院", "生物与医学工程学院", "人文社会科学学院（公共管理学院）", "外国语学院", "交通科学与工程学院", "可靠性与系统工程学院", "宇航学院", "飞行学院", "仪器科学与光电工程学院", "物理科学与核能工程学院", "法学院", "软件学院", "高等工程学院", "中法工程师学院", "国际学院", "新媒体艺术与设计学院", "化学学院", "马克思主义学院", "人文与社会科学高等研究院", "空间与环境学院", "大飞机班"],
    instituteNum: [0,1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 19, 20, 21, 23, 24, 25, 26, 27, 28, 29, 30, 36],
    indexInstitute: 0,
    grades: ["本科生", "硕士研究生", "博士研究生"],
    indexGrade: 1,
    fGender: "男",
    fType: "学生",
    fGrade: "硕士研究生",
    fInstitute: "材料科学与工程学院",
    fName: "",
    fEmail: "",
    fPhone: "",
    fNumber: "",
    fImg: "",
    fVCode: "",
    vCodeShow: false,
    getVCodeEnable: true,
    btnEnable: false
  },
  onLoad: function(options) {
    api_GetRegisterFormData((res) => {
      console.log("获取学院列表==>", res)
      let institutes = []
      let instituteNum = []
      res.data.data.academy_options.forEach(i => {
        instituteNum.push(i['key'])
        institutes.push(i['value'])
      })
      this.setData({
        instituteNum: instituteNum,
        institutes: institutes
      })
      console.log("获取的学院代号==>", instituteNum)
      console.log("获取的学院列表==>", institutes)
    })

  },
  onShow: function() {

    const captchaResult = app.captchaResult;
    console.log('验证回调==>', captchaResult)
    app.captchaResult = null; // 验证码的票据为一次性票据，取完需要置空
    if (captchaResult && captchaResult.ret === 0) {
      this.setData({
        vCodeShow: true,
      })

      let params = {
        ticket: captchaResult.ticket,
        randstr: captchaResult.randstr,
        phone: this.data.fPhone,
      }
      api_VerifyByPhone(params, (res) => {
        console.log('手机验证码发送结果==>', res)
        if (res.errcode == 0) {
          wx.showToast({
            title: '验证码发送成功',
            icon: 'success'
          })
        } else {
          wx.showToast({
            title: '验证码发送失败',
            icon: 'none'
          })
        }
      })
      // 将验证码的结果返回至服务端校验
      // const ticket = captchaResult.ticket;
      // const randstr = captchaResult.randstr;
    }

  },

  //设置姓名
  setName: function(e) {
    this.setData({
      fName: e.detail.value
    })
  },
  //设置邮箱
  setEmail: function(e) {
    this.setData({
      fEmail: e.detail.value
    })
  },
  //设置手机号
  setPhone: function(e) {
    // this.setData({
    //   fPhone: e.detail.value
    // })
  },
  // 验证手机号长度,并设置手机号
  getLengthOfPhone: function(e) {
    var length = e.detail.value.length;
    if (length == 11) {
      this.setData({
        btnEnable: true,
        fPhone: e.detail.value
      })
    }
  },
  //设置验证码
  setVCode: function(e) {
    this.setData({
      fVCode: e.detail.value
    })
  },

  //设置学号
  setNumber: function(e) {
    this.setData({
      fNumber: e.detail.value
    })
  },


  genderChange: function(e) {

    this.setData({
      indexGender: e.detail.value,
      fGender: this.data.gender[e.detail.value]
    })
  },
  typeChange: function(e) {

    this.setData({
      indexType: e.detail.value,
      fType: this.data.types[e.detail.value]
    })
  },
  instituteChange: function(e) {
    this.setData({
      indexInstitute: e.detail.value,
      fInstitute: this.data.institutes[e.detail.value]
    })
  },
  gradeChange: function(e) {
    this.setData({
      indexGrade: e.detail.value,
      fGrade: this.data.grades[e.detail.value]
    })
  },

  chooseImage: function(e) {
    var _this = this;
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original'],
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function(res) {
        _this.setData({
          fImg: res.tempFilePaths[0]
        })
        console.log('===>', res)
      }
    })
  },

  formSubmit: function(e) {
    console.log('formId==>', e.detail.formId)
    let formId = e.detail.formId
    //发起活动前数据的处理与验证
    var _this = this
    let that = this.data
    // let academy = (parseInt(that.indexInstitute) + 1).toString()
    console.log("当前学院的数组序号==>", that.indexInstitute)
    console.log("当前学院的名称==>", that.institutes[that.indexInstitute])
    console.log("当前学院的代号==>", that.instituteNum[that.indexInstitute])
    let academy = that.instituteNum[that.indexInstitute].toString()
    let form = {
      name: that.fName,
      email: that.fEmail,
      phone: that.fPhone,
      phoneVCode: that.fVCode,
      sex: that.fGender,
      accType: that.fType,
      buaaId: that.fNumber,
      grade: that.fGrade,
      academy: academy,
      formId: formId
      // buaaCardImg: that.fImg
    }
    console.log('提交前组装成的表单==>', form)

    if (form.name.length == 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '姓名不能为空',
        duration: 2000,
        success() {},
      })
    } else if (form.email.length == 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '邮箱不能为空',
        duration: 2000,
        success() {},
      })
    } else if (form.phone.length == 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '手机号格式不正确',
        duration: 2000,
        success() {},
      })
    } else if (form.phoneVCode.length == 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '手机验证码不能为空',
        duration: 2000,
        success() {},
      })
    } else if (form.buaaId.length == 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '学号或工号不能为空',
        duration: 2000,
        success() {},
      })
    } else if (_this.data.fImg.length == 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '请上传证件照片',
        duration: 2000,
        success() {},
      })
    } else {
      api_SubmitUserInfo(form, this.data.fImg, (res) => {
        // console.log('提交信息结果反馈==>', res)
        let resForm = JSON.parse(res)
        console.log('提交信息结果反馈==>', resForm)
        if (resForm.errcode == 0) {
          wx.showToast({
            title: '添加成功,请耐心等待管理员审核',
            icon: 'success',
          })
          setTimeout(function() {
            wx.reLaunch({
              url: '../home/home',
            })
          }, 2000)
        } else if (resForm.errcode == 205) {
          wx.showModal({
            title: '错误提示',
            content: '欢迎回来！系统检测到您的账号已在同研2.0注册，请点击下方按钮进行账号迁移',
          })
        } else {
          wx.showModal({
            title: '错误提示',
            content: resForm.errmsg,
          })
        }
      })

    }
  },

  //跳转到用户迁移页面
  goToUserMigrate: function(e) {
    wx.navigateTo({
      url: '../../uc/userMigrate/userMigrate',
      success: function(res) {
        // success
      },
      fail: function() {
        // fail
      },
      complete: function() {
        // complete
      }
    })
  },

  // 处理验证码
  vcode() {

    this.setData({
      getVCodeEnable: false
    })
    if (this.c2 && this.c2.interval) return !1
    this.c2 = new $wuxCountDown({
      date: +(new Date) + 60000,
      onEnd() {
        this.setData({
          c2: '重新获取',
          getVCodeEnable: true
        })
      },
      render(date) {
        const sec = this.leadingZeros(date.sec, 2) + ' 秒 '
        date.sec !== 0 && this.setData({
          c2: sec,
        })
      },
    })
  },
})
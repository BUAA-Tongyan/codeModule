// pages/act/actApply/actApply.js
let {
  api_GetActApplyForm,
  api_ApplyNewAct,
  api_uc_GetInfoByToken,
  // api_SendTemplateMessage
} = require("../../api/getData.js")
import {
  $wuxToptips
} from '../../components/wux-index'
const app = getApp()
Page({

  data: {
    // popShow: false,
    // isAssignAcademy: false,
    // canAssignAcademy: false,
    // agreeFlag: false,
    // assignedAcademies: [], //院系限制
    // departNum: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30],
    // departName: ['1系', '2系', '3系', '4系', '5系', '6系', '7系', '8系', '9系', '10系', '11系', '12系', '13系', '14系', '15系', '16系', '17系', '18系',
    //     '19系', '20系', '21系', '22系', '23系', '24系', '25系', '26系', '27系', '28系', '29系', '30系',
    // ],
    lengthOfTheme: 0,
    lengthOfInfo: 0,
    actTypeIndex: 0,
    actTypes: [],
    domainTypes: [],
    domainIndex: 0,
    startdate: '2018-09-01',
    starttime: '12:00',
    enddate: '2018-09-01',
    endtime: '12:00',
    commitment: [{
      name: "yes",
      value: "我同意活动发起承诺书"
    }],
    guestNum: 0, //主讲人数
    buttonDisabled: true, //提交按钮状态
    maxNum: 1000, //最大参与人数
    sponsorIsShow: false, //是否显示主办方信息

    //待提交的表单数据
    title: '', //活动标题
    actType: '微沙龙', //活动类型
    domains: [], //学科方向
    place: '', //活动地点
    maxQuantity: 3, // 可参与人数
    hasTeacher: false, // 教师参与
    summary: '', //活动简介
    infoimg: '', //活动图片
    fImg: '', //图片临时路径
    speakers: [], //主讲人
    contactEmail: '',
    contactName: '',
    contactTel: '',
    cardHasSeat: false, // 是否含有座位信息
    cardSeatInfo: '', // 座位信息
    cardTitle: '', //报名所领取的卡券名称，必填，否则卡券名称会出现空白
    cardCanGive: false,
    cardGetLimit: 1,
    needSignOut: false,//wxml不再展示是否签退


    // 私有属性：触发修改speaks事件时，禁止blur事件
    __killBlur: false,

    showBack: false,
    //活动签到类型
    signTypeList:['仅签到','签到+签退','无签到'],
    signTypeIdx:0,
  },

  onLoad: function(options) {

    /*通过token获取用户信息*/
    api_uc_GetInfoByToken((res) => {
      console.log('通过token获取用户信息==>', res.data.data)
      // this.setData({
      //   contactEmail: res.data.data.email,
      //   contactName: res.data.data.nickname,
      //   contactTel: res.data.data.phone
      // })
      this.setData({
        userContactEmail: res.data.data.email,
        userContactName: res.data.data.nickname,
        userContactTel: res.data.data.phone
      })

      this.sponsorIsShow()
    })

    // 设置默认时间，这里不能用onShow
    this.setData({
      _startdate: app.timePicker.date,
      startdate: app.timePicker.date,
      starttime: app.timePicker.time,
      enddate: app.timePicker.date,
      endtime: app.timePicker.time,
    })
  },

  onShow: function(options) {
    if (app.globalData.userNotSignUp) {
      wx.showModal({
        title: '提示',
        content: '注册同研平台后才可发起活动！',
        confirmText: "前往注册",
        cancelText: "随便逛逛",
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
            wx.navigateTo({
              url: '../register/register',
            })
          } else if (res.cancel) {
            console.log('用户点击取消')
            wx.reLaunch({
              url: '../home/home',
            })
          }
        }
      })
    }


    /*获取活动类型和学科方向*/
    api_GetActApplyForm((res) => {
      if (res.data.errcode !== 0) {
        console.log(res)
        wx.showModal({
          title: '提示',
          content: res.data.errmsg,
          confirmText: "查看状态",
          cancelText: "随便逛逛",
          success(res) {
            if (res.confirm) {
              console.log('用户点击确定')
              wx.navigateTo({
                url: '../../uc/userInfo/userInfo',
              })
            } else if (res.cancel) {
              console.log('用户点击取消')
              wx.reLaunch({
                url: '../home/home',
              })
            }
          }
        })
      } else {
        console.log("#########--发起活动表单--##########", res.data.data)
        let tmp1 = []
        let tmp2 = ['自定义']
        let tmp3 = []
        let tmp4 = []
        res.data.data.actTypes.forEach(i => {
          if (i.name != '跳蚤市场') {
            tmp1.push(i.name)
            tmp3.push(i.canAssignAcademy)
            tmp4.push(i.canSignOut)

          }
        })
        res.data.data.domains.forEach(i => {
          tmp2.push(i.name)
        })
        this.setData({
          actTypes: tmp1,
          domainTypes: tmp2,
          canAssignAcademyList: tmp3,
          canSignOut: tmp4,
          // _startdate: app.timePicker.date,
          // startdate: app.timePicker.date,
          // starttime: app.timePicker.time,
          // enddate: app.timePicker.date,
          // endtime: app.timePicker.time,
        })
      }

    })

  },
  // 活动图片添加
  chooseImage: function (e) {
    var _this = this;
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original'],
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: (res) => {

        console.log('活动图片添加成功', res)
        var tempFilePath = res.tempFilePaths[0];
        var url = '/buaa/act/uploadInfoImg';
        var name = 'actInfoImg';
        _this.setData({
          fImg: tempFilePath
        })
        console.log('tmp filePath', _this.data.fImg);
        wx.uploadFile({
          url: 'https://www.buaagsu.com' + url,
          filePath: tempFilePath,
          name: name,
          header: {
            'content-type': 'multipart/form-data',
            'hellobuaa': wx.getStorageSync("token"),
            "Cookie": "SESSION=" + wx.getStorageSync("session_id")
          },
          success: (res) => {
            console.log('res', res);
            if (res.statusCode != 200) {
              wx.showModal({
                title: '提示',
                content: '上传失败',
                showCancel: false
              })
              return;
            }
            var data=res.data
            console.log('活动附图url', JSON.parse(res.data).imgUrl);
            _this.setData({
              infoimg: JSON.parse(res.data).imgUrl
            })
          },
          fail: function (e) {
            console.log(e);
            wx.showModal({
              title: '提示',
              content: '上传失败',
              showCancel: false
            })
          },
        })
      }
    })
    
  },
  //活动主题设置
  setActFormTitle: function(e) {
    //活动主题长度
    var length = e.detail.value.length;
    this.setData({
      lengthOfTheme: length,
      title: e.detail.value
    })
  },
  //活动类型改变
  actTypeChange: function(e) {
    this.setData({
      actTypeIndex: e.detail.value,
      actType: this.data.actTypes[e.detail.value],
      canAssignAcademy: this.data.canAssignAcademyList[e.detail.value]
    })
    this.sponsorIsShow()
    if (this.data.actType !== "微沙龙") {
      this.setData({
        maxNum: 2000
      })
    } else if (this.data.hasTeacher == true) {
      this.setData({
        maxNum: 12
      })
    } else {
      this.setData({
        maxNum: 12
      })
    }
    // 解决头像会出现两次的现象？
    if (this.data.actType === '其他') {
      this.setData({
        cardGetLimit: 2
      })
    }else{
      this.setData({
        cardGetLimit: 1
      })
    }
  },
  //学科方向设置
  domainTypeChange: function(e) {
    let tmp = []
    tmp.push(this.data.domainTypes[e.detail.value])
    this.setData({
      domainIndex: e.detail.value,
      domains: tmp
    })
  },
  //学科方向自定义
  setUserDefineddomain: function(e) {
    let str = 'domains[0]'
    this.setData({
      [str]: e.detail.value
    })
  },
  //活动地点设置
  setActFormPlace: function(e) {
    this.setData({
      place: e.detail.value
    })
  },
  //参与人数设置
  setActFormMaxQuantity: function(e) {
    this.setData({
      maxQuantity: e.detail
    })
  },
  //教师参与设置
  ifTeacherChange: function(e) {
    console.log('设置教师参与', e)
    if (e.detail == true && this.data.actTypeIndex == 0) {
      this.setData({
        maxNum: 12
      })
    } else if (this.data.maxQuantity > 12 && this.data.actTypeIndex == 0) {
      this.setData({
        maxNum: 12,
        maxQuantity: 12
      })
    }
    this.setData({
      hasTeacher: e.detail
    });
  },
  // 抢座开关设置
  onCardHasSeatChange() {
    console.log(111)
    this.setData({
      cardHasSeat: !this.data.cardHasSeat
    })
  },

  //签退功能设置
  ifSignOutChange: function(e) {
    console.log('设置签退', e)
    this.setData({
      needSignOut: e.detail
    });
  },

  //活动简介长度
  getLengthOfInfo: function(e) {
    var length = e.detail.value.length;
    this.setData({
      lengthOfInfo: length
    })
  },
  //活动简介设置
  setActFormSummary: function(e) {
    this.setData({
      summary: e.detail.value
    })
  },
  // 座位信息设置
  setCartInfo(e) {
    console.log(e)
    this.setData({
      cardSeatInfo: e.detail.value
    })
  },
  //设置活动开始时间
  bindDateChange1: function(e) {
    // console.log('startDate++++++++++++++++++++++',e)
    this.setData({
      startdate: e.detail.value
    })
  },
  bindTimeChange1: function(e) {
    this.setData({
      _starttime: e.detail.value,
      starttime: e.detail.value
    })
  },
  // 设置活动结束时间
  // bindDateChange2: function(e) {
  //   this.setData({
  //     enddate: e.detail.value
  //   })
  // },
  bindTimeChange2: function(e) {
    this.setData({
      endtime: e.detail.value
    })
  },
  // 恢复blur
  recoverBlur() {
    console.log('现在恢复blur事件')
    this.data.__killBlur = false
  },
  //更改主讲人数
  changeGuestNum: function(e) {
    console.log('更改主讲人数', e)
    let tmp = []
    for (let i = 0; i < e.detail; i++) {
      tmp.push({
        index: i,
        name: '',
        studentId: '',
        summary: ''
      })
      console.log(tmp)
    }
    console.log('tmp是', tmp)
    this.setData({
      speakers: tmp
    })
    this.data.__killBlur = true
  },
  //设置主讲人姓名
  setSpeakerName: function(e) {
    if (this.data.__killBlur) {
      this.data.__killBlur = false
      return
    }
    console.log('输入值==>', e.detail.value)
    console.log('speaker定位==>', e.currentTarget.dataset.index)
    let index = e.currentTarget.dataset.index
    let name = e.detail.value
    let str = 'speakers[' + index + '].name'
    this.setData({
      [str]: name
    })
  },
  //设置主讲人学工号
  setSpeakerStudentId: function(e) {
    if (this.data.__killBlur) {
      this.data.__killBlur = false
      return
    }
    console.log('输入值==>', e.detail.value)
    console.log('speaker定位==>', e.currentTarget.dataset.index)
    let index = e.currentTarget.dataset.index
    let studentid = e.detail.value
    let str = 'speakers[' + index + '].studentId'
    this.setData({
      [str]: studentid
    })
  },
  //设置主讲人简介
  setSpeakerSummary: function(e) {
    if (this.data.__killBlur) {
      this.data.__killBlur = false
      return
    }
    console.log('我擦,这里有个坑，当改变speaker数量时会触发这个函数')
    console.log('输入值==>', e.detail.value)
    console.log('speaker定位==>', e.currentTarget.dataset.index)
    let index = e.currentTarget.dataset.index
    console.log(index)
    let summary = e.detail.value
    let str = 'speakers[' + index + '].summary'
    this.setData({
      [str]: summary
    })
    console.log('我擦,这里有个坑，当改变speaker数量时会触发这个函数')
  },

  //是否显示主办方信息
  sponsorIsShow() {
    let userContactEmail = this.data.userContactEmail
    let userContactName = this.data.userContactName
    let userContactTel = this.data.userContactTel

    if (this.data.actType == '微沙龙') {
      this.setData({
        contactName: userContactName,
        contactEmail: userContactEmail,
        contactTel: userContactTel,
        sponsorIsShow: false,
      })
    } else {
      this.setData({
        contactName: '',
        contactEmail: '',
        contactTel: '',
        sponsorIsShow: true,
      })
    }
  },

  //主办方信息设置
  //主办方名称
  setContactName: function(e) {
    //活动主题长度
    this.setData({
      contactName: e.detail.value
    })
  },
  //主办方邮箱
  setContactEmail: function(e) {
    //活动主题长度
    this.setData({
      contactEmail: e.detail.value
    })
  },
  //主办方联系电话
  setContactTel: function(e) {
    //活动主题长度
    this.setData({
      contactTel: e.detail.value
    })
  },


  // 获取卡券的标题，卡券标题不能过长，否则影响小程序后台申请卡券
  // 需要对过长的标题进行截取
  getCardTitle: function(e) {
    var titleStr = this.data.title
    var titleLength = this.data.title.length;
    var codeLength = 0;
    var cardTitle = new String()
    for (let i = 0; i < titleLength; i++) {
      var charCode = titleStr.charCodeAt(i);
      console.log("charCode[" + i + "]" + charCode)
      var charIndex = titleStr.charAt(i);
      if (charCode >= 0 && charCode <= 128) {
        cardTitle += charIndex;
        codeLength += 1;
      } else {
        cardTitle += charIndex;
        codeLength += 3;
      }
      if (codeLength === 24) {
        cardTitle += '…'
        break;
      }
      if (codeLength > 24) {
        break;
      }
    }
    if (codeLength > 24) {
      cardTitle = cardTitle.substring(0, cardTitle.length - 1)
      cardTitle += "…"
    }
    console.log("titleLength: ", titleLength)
    console.log("codeLength: ", codeLength)
    console.log("cardTitle: ", cardTitle)
    this.data.cardTitle = cardTitle
  },

  //活动发起承诺书弹窗
  checkboxChange: function(e) {
    console.log('checkbox发生change事件，携带value值为：', e.detail.value)
    if (e.detail.value.length == 1) {
      this.setData({
        buttonDisabled: false
      })
      wx.showModal({
        title: '活动发起承诺书',
        content: '我承诺，本次活动是以学术交流为目的，主题积极向上。我将严格遵守《用户协议》，保证活动内容不涉及政治、宗教、性别歧视、地域歧视或种族歧视等违法违规事项。如有违反任何法律法规及相关条款，本人愿意承担所有责任。',
        showCancel: false,
        confirmText: "了解了"
      })
    } else {
      this.setData({
        buttonDisabled: true
      })
    }
  },
  testSummary: function() {

  },
  //提交发起活动表单
  submitApply: function(e) {
    console.log('formId==>', e.detail.formId)
    this.getCardTitle() //处理卡券标题
    //发起活动前数据的处理与验证
    let that = this.data
    let form = {
      title: that.title, //活动主题
      actType: that.actType, //活动类型
      domains: that.domains, //学科方向
      startTime: that.startdate + ' ' + that.starttime, //开始时间
      endTime: that.startdate + ' ' + that.endtime, //结束时间
      place: that.place, //活动地点
      maxQuantity: that.maxQuantity, // 可参与人数
      hasTeacher: that.hasTeacher, // 教师参与
      summary: that.summary + 'imgUrl:' + that.infoimg, //活动简介及图片
      speakers: that.speakers, //主讲人
      contactEmail: that.contactEmail,
      contactName: that.contactName,
      contactTel: that.contactTel,
      cardHasSeat: that.cardHasSeat, // 是否含有座位信息
      cardSeatInfo: that.cardSeatInfo, // 座位信息
      cardTitle: that.cardTitle,
      cardCanGive: that.cardCanGive,
      cardGetLimit: that.cardGetLimit,
      needSignOut: that.needSignOut, //签到或者签退
      // assignedAcademies: '', //限制院系
      formId: e.detail.formId,
      signType: that.signTypeList[that.signTypeIdx]
    }
    console.log(form.summary)
    console.log('发起活动前组装成的表单==>', form)
    ///////////////////////////////////////////////表单验证
    if (form.title.length == 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '活动标题不能为空',
        duration: 2000,
        success() {},
      })
    } else if (form.domains.length == 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '学科方向不能为空',
        duration: 2000,
        success() {},
      })
    } else if (form.place.length == 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '活动地点不能为空',
        duration: 2000,
        success() {},
      })

    } else if (form.summary.length == 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '活动简介不能为空',
        duration: 2000,
        success() {},
      })
    } else if (form.contactName.length == 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '主办方名称不能为空',
        duration: 2000,
        success() {},
      })
    } else if (form.contactEmail.length == 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '主办方邮箱不能为空',
        duration: 2000,
        success() {},
      })
    } else if (form.contactTel.length == 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '主办方联系电话不能为空',
        duration: 2000,
        success() {},
      })
    } else {
      let st = new Date(form.startTime);
      let et = new Date(form.endTime);
      let cuttime = (Date.parse(et) - Date.parse(st)) / 86400000 * 24;
      console.log('开始时间==>', st)
      console.log('结束时间==>', et)
      console.log('时间间隔==>', cuttime)
      if (cuttime < 1) {
        $wuxToptips().show({
          icon: 'cancel',
          hidden: false,
          text: '活动时间不能低于1小时',
          duration: 2000,
          success() {},
        })
      } else {
        ////////////////////////////////////////////////
        let formJsonStr = JSON.stringify(form);
        console.log('转换后的json字符串==>', formJsonStr);
        this.setData({
          formJsonStr: formJsonStr,
          formId: e.detail.formId
        })
        let tmp = this.data.formJsonStr

        wx.showModal({
          title: '确认发起此活动？',
          success: (res) => {
            if (res.confirm) {
              console.log('用户点击确定发起活动')

              // let url = '/buaa/act/applyNewAct'
              // var fileImgPath = this.data.fImg
              // console.log('活动提交图像地址==> ', fileImgPath)
              
              // wx.uploadFile({
              //   url: 'https://www.buaagsu.com' + url,
              //   filePath: fileImgPath,
              //   // name: 'imgFile',
              //   // name: 'buaaCardImg',
              //   name: 'actInfoImg',
              //   formData: form,
              //   header: {
              //     'content-type': 'multipart/form-data',
              //     'hellobuaa': wx.getStorageSync("token"),
              //     "Cookie": "SESSION=" + wx.getStorageSync("session_id")
              //   },
              //   success: function (res) {
              //     console.log('活动chengg==>', res)
              //   },
              //   fail: function (res) {
              //     console.log('活动shibai==>', res)
              //   },
              // })




              // 调用发起活动API
              api_ApplyNewAct({
                actApplyFormJsonStr: formJsonStr
              }, (res) => {
                console.log('活动发起结果==>', res)
                if (res.errmsg == "ok") {
                  //发送模板消息
                  // _this.sendTemplateMessage()
                  wx.redirectTo({
                    url: '../msg/msg_success?type=actApply',
                  })
                } else {
                  wx.showModal({
                    title: '失败',
                    content: res.errmsg || '请尝试重新发起',
                    success: function(res) {
                      if (res.confirm) {
                        console.log('用户点击确定')
                      } else if (res.cancel) {
                        console.log('用户点击取消')
                      }
                    }
                  })
                }
              })
            } else if (res.cancel) {
              console.log('用户点击取消')
            }
          }
        })
      } // if time>1
    } //else
  },
  signTypeChange:function(e) {
    console.log('活动签到类型序号',e.detail.value)
    this.setData({
        signTypeIdx:e.detail.value
    })
    // console.log(this.data.signTypeIdx);
    this.setData({
      needSignOut: (this.data.signTypeIdx==1)
    })
  },
  showSignRule:function(e) {
    console.log("查看签到规则====>");
    wx.showModal({
      title: '签到规则',
      content: '您可以在【我的】—【签到签退】中，对自己发布的活动进行签到/签退。同研提供两种签到/签退方式，可同时进行：                                      \n1.逐一扫描核销活动参与人的活动卡券进行签到/签退。签到/签退链接可转发给其它工作人员，同时多人进行签到/签退。此方法可一定程度上防止代签。                                     \n2.生成签到/签退码，参与人在现场用微信扫描二维码即可签到/签退成功。                                            \n注意：当参与人未能完成签到/签退时，将被扣除同研信用分。详见《同研平台信用分规则》。                    ',
      showCancel: false,
      confirmText: "了解了"
    })
  },
  showNumRule:function(e) {
    console.log("查看人数限制====>");
    wx.showModal({
      title: '人数限制',
      content: '【微沙龙】类型的活动中，除航向标、英语角等已报备的研会活动外，暂不支持用户发起15人以上的活动。若您的活动人数超过15人，将很可能无法通过审核。',
      showCancel: false,
      confirmText: "了解了"
    })
  },
})
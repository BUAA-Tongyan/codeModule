const app = getApp()
const {
  api_GetActivityInfo,
  api_uc_GetInfoByToken,
  api_GetCardExt,
  api_refundTicket,
  api_shareAct,
  api_DeleteActivity,
  api_GetHundredRegisterActDetail,
  api_HundredSign,
} = require("../../api/getData.js")

Page({

  data: {
    userInfo: {}, // 用户信息
    dataSource: { // 传入模板文件的数据源,整个模板文件不涉及数据交互,只负责展示
      actInfo: {}, // 用于展示数据源
      selectedFlag: false, // 参与人展开标记
      punchcard:true,
    },
    showPaticipate: false, // 参与人是否展开，默认不展开
    btnText: '我要报名',
    loadingShow: false,
    isDisable: false,
    hasUserInfo: null,
    fromShare: false, // 场景判断
    canceled: false, // 取消活动操作
    share: [], // 朋友圈分享的数据
    showDeleteBtnConfirm: false, // 显示活动删除确认框
    userContactEmail: '',
    userContactName: '',
    userContactTel: '',
    signpic:'',
  },

  onLoad: function(options) {
    // TODO 封装到函数中，保持onload的简洁
    console.log('传入页面的参数 --> ', options)

    // 获取用户信息
    if (app.globalData.userInfo) {
      console.log('globalData用户信息 -->', app.globalData.userInfo)
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    }
    api_uc_GetInfoByToken((res) => {
      console.log('通过token获取用户信息==>', res.data.data)
      this.setData({
        userContactEmail: res.data.data.email,
        userContactName: res.data.data.nickname,
        userContactTel: res.data.data.phone
      })
    })
    // 获取活动详情
    let act_id = options.actId || options.scene; // 通过动态生成的小程序码进入时，actId保存在options.scene中
    let punchcard=options.finished;
    if (options.finished=='false'){
      punchcard=false
    }else{
      punchcard=true
    }
    // this.setData({
    //   ['dataSource.punchcard']: punchcard,
    // })
    console.log("活动id：", act_id);
    api_GetHundredRegisterActDetail(act_id, res => {
      if (res.status == 200) {
        // 服务器成功返回数据
        var data = res.data
        data.userContactEmail = this.data.userContactEmail
        data.userContactName = this.data.userContactName
        data.userContactTel = this.data.userContactTel
        var datestr = app.timePicker.date
        var dateToday = new Date(datestr)
        var datestr2 = data.start_day.slice(0, 4) + '-' + data.start_day.slice(4, 6) + '-' + data.start_day.slice(6, 8)
        var dateStart = new Date(datestr2)
        var todaystr = app.timePicker.date.replace(/-/, "").replace(/-/, "")
        if (dateToday < dateStart) {
          // 活动尚未开始
          data.state = '未开始'
        } else {
          // 活动已经开始
          if (todaystr == data.latest_record_day) {
            data.state = '已打卡'
          } else {
            data.state = '未打卡'
          }
        }
        this.setData({
          ['dataSource.actInfo']: data,
          ['dataSource.punchcard']: punchcard,

        })
        console.log("拿到的活动详情 --> ", this.data.dataSource)
      } else {
        wx.showToast({
          title: '服务器开小差中，QAQ',
          icon: 'loading',
          duration: 3000,
        });
      }
    })

    // 判断小程序进入场景
    console.log("小程序进入场景 -->", app.globalData.resultScene)
    if (app.globalData.resultScene[0] === 1007 || app.globalData.resultScene[0] === 1008) {
      this.setData({
        fromShare: true
      })
    }
  },

  /**
   * 用户点击右上角分享配置
   */
  onShareAppMessage: function() {
    let actId = this.data.dataSource.actInfo.actId
    let title = this.data.dataSource.actInfo.title
    return {
      title: title,
      path: 'pages/act/actDetail/actDetail?actId=' + actId,
      success: function(res) {
        console.log('ok')
        if (res.errMsg === 'shareAppMessage:ok') {
          // 分享赚积分
          let params = {
            actId: actId
          }
          api_shareAct(params, res => {
            console.log('分享活动增加积分==>', res)
          })
        }
      },
      fail: function() {}
    }
  },


  /**************以上是生命周期********************以下是函数定义**************************/
  // 点击图片查看大图 并且能够调用微信内部的扫描二维码
  previewImage: function(e) {
    var current = e.target.dataset.src;
    wx.previewImage({
      current: this.data.imgUrl, // 当前显示图片的http链接 
      urls: [this.data.imgUrl] // 需要预览的图片http链接列表 
    })
  },


  // 从分享入口进入时返回主页
  // 为什么不用wx.navigateTo来保存前一个页面？
  goHome: function(e) {
    wx.reLaunch({
      url: '../home/home',
    })
  },

  // 参与人展开折叠选择 TODO 该事件的监听写到了模板里
  showPaticipate: function(e) {
    console.log(this.data.dataSource.selectedFlag)
    let tmp = this.data.dataSource.selectedFlag
    // this.setData使用[]，https://www.cnblogs.com/simuhunluo/p/7989461.html
    let str = 'dataSource.selectedFlag'
    this.setData({
      [str]: !tmp
    })
    this.data.showPaticipate = !this.data.showPaticipate
  },

  //取消活动报名
  cancelActApply: function(e) {
    let _this = this
    let actId = _this.data.dataSource.actInfo.actId
    let signpic = ''
    let param = {
      actId: actId
    }
    wx.showModal({
      title: '确认取消报名？',
      content: "提示：取消报名后不能再次报名该活动；在活动开始前1小时内取消报名会扣除信用分，且取消报名后不能再次报名，详情见信用分规则。",
      success: function(res) {
        if (res.confirm) {
          console.log('用户点击确定')
          api_refundTicket(param, (res) => {
            console.log("活动取消结果==>", res)
            if (res.errcode == 0) {
              wx.showToast({
                title: '取消成功',
                icon: 'success',
              })
              _this.setData({
                canceled: true,
              })
            } else {
              wx.showModal({
                title: '错误提示',
                content: res.errmsg,
              })
            }
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }

      }
    })

  },

  uploadPic: function (e) {
    // 上传图片
    var _this = this; 
    let actId = _this.data.dataSource.actInfo.act_id

    wx.chooseImage({
      count: 1, // 默认9 选择图片的最大数量
      sizeType: ['original'],
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: (res) => {
        var tempFilePaths = res.tempFilePaths[0];
        var url = '/buaa/act/uploadInfoImg';
        var name = 'actInfoImg';

        wx.uploadFile({
          url: 'https://www.buaagsu.com' + url,
          filePath: tempFilePaths,
          name: name,
          header: {
            'content-type': 'multipart/form-data',
            'hellobuaa': wx.getStorageSync("token"),
            "Cookie": "SESSION=" + wx.getStorageSync("session_id")
          },
          success: (res) => {
            if (res.statusCode != 200) {
              wx.showModal({
                title: '提示',
                content: '上传失败',
                showCancel: false
              })
              return;
            }
            var data = res.data
            _this.setData({
              signpic: JSON.parse(res.data).imgUrl
            })
            _this.data.dataSource.signpic=_this.data.signpic

            var picurl=JSON.parse(res.data).imgUrl
            if (!app.globalData.userInfoByToken) {
              //No user's information. Get it from servive website.
              console.log('==>进入登录流程')
              _this.setData({
                btnText: "登录中...",
                loadingShow: true,
                isDisable: true
              })
              /*获取用户信息并存在全局变量中*/
              api_uc_GetInfoByToken((res) => {
                console.log('用户信息bytoken==>', res.data.data)
                app.globalData.userInfoByToken = res.data.data
              })
              //Check the state after user loging in
              // _this.checkUserState(app.globalData.userInfoByToken.state)
            } 
            else {
              // 提交签到表单
              let submitform = {
                act_id: actId, // 活动id
                image_url: picurl //图片url
              }
              console.log('提交表单数据==> ', submitform)
              wx.showModal({
                title: '确认完成打卡',
                success: (res) => {
                  if (res.confirm) {
                    console.log('签到数据==> ', submitform)
                    // 调用签到API
                    api_HundredSign(submitform, (res) => {
                      console.log('签到结果==>', res)
                      // console.log('签到链接==>', '/pages/act/out/out?auth=1&outlink=https://www.buaagsu.com/buaa/v2/api/100day_game/do_share?act_id=' + actId)
                      if (res.status == 200) {
                        //发送模板消息

                        wx.navigateTo({
                          url: '/pages/act/out/out?auth=1&outlink=https://www.buaagsu.com/buaa/v2/api/100day_game/do_share&act_id='+actId
                        })
                      } else {
                        wx.showModal({
                          title: '失败',
                          content: '请尝试重新打卡',
                          success: function (res) {
                            if (res.confirm) {
                              console.log('用户点击确定')
                            } else if (res.cancel) {
                              console.log('用户点击取消')
                            }
                          }
                        })
                      }
                    })
                  } else if (res.cancel) {
                    console.log('用户点击取消')
                  }
                }
              })

            }
          },
          fail: function (e) {
            console.log(e);
            wx.showModal({
              title: '提示',
              content: '上传失败',
              showCancel: false
            })
          },
        })
      }
    })

  },



  login(userinfo) { // 参数来额外接收用户数据
    var _this = this
    if (app.globalData.userInfoByToken) {
      // _this.addCard(1)
      console.log('==>全局变量中已有用户信息', app.globalData.userInfoByToken)
      // 检查状态并添加卡券
      _this.checkUserState(app.globalData.userInfoByToken.state)
    } else {
      app.login(userinfo, (err, res) => {
        if (err) return console.log('login function has error') // 如果登录方法出错则报错
        console.log('登录后存在全局变量中的用户信息==>', app.globalData)
        // 登录完毕后，调用用户数据等信息，使用 that.setData 写入
        console.log('==>进入登录流程')
        _this.setData({
          btnText: "自动登录中...",
          loadingShow: true,
          isDisable: true
        })
        /*获取用户信息并存在全局变量中*/
        api_uc_GetInfoByToken((res) => {
          console.log('用户信息bytoken==>', res.data.data)
          app.globalData.userInfoByToken = res.data.data
        })
        // _this.addCard(1)
        _this.checkUserState(app.globalData.userInfoByToken.state)
      })
    }

  },

  checkUserState(state) {
    if (state === '通过审核') {
      this.howToAddCard()
    } else {
      var _this = this;
      wx.showModal({
        title: '提示',
        content: '账户状态异常，请点击确定查看！',
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
            wx.navigateTo({
              url: '../../uc/userInfo/userInfo',
            })
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    }
  },

  /**
   * 分享到朋友圈，采用shareMoments组件
   */
  handleShareMoments: function() {
    // TODO 这里的名字起得有点混乱，因为是从别人的组件拷贝的
    let userInfo = this.data.userInfo
    let actInfo = this.data.dataSource.actInfo
    let avatar = userInfo.headimgurl
    console.log('avatar', avatar);
    let nickname = userInfo.nickname
    let adName = actInfo.title
    let adTime = actInfo.place
    let joinAvatarList = [] // 参与人的头像
    actInfo.participationList.forEach((item) => {
      joinAvatarList.push(item.headImg)
    })
    let joinNumber = joinAvatarList.length
    // joinAvatarList = joinAvatarList.filter((item, index) => index <= 8)
    let incomeMoney = `${actInfo.startTime}-${actInfo.endTime.slice(-5)}`
    this.setData({
      share: {
        avatar,
        nickname,
        incomeMoney,
        joinNumber,
        joinAvatarList,
        adName,
        adTime, //地点
        // 只能是网络图片，不能是本地图片. 图片通过七牛云存储托管
        adImageUrl: 'https://7365-server-0d9db-1259368714.tcb.qcloud.la/images_background/shareband.jpg?sign=957a4d320b634da0dfe6c010c8bdee2e&t=1597062528',
        showShareModel: true,
        qrcode_url: 'pages/act/actDetail/actDetail?' + this.data.dataSource.actInfo.actId
      },
    })
  },

})
// pages/act/actCheckin/actCheckin.js
import {
  api_GetParticipatedList,
  api_SignIn
} from '../../api/getData.js'
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    curPage: 0,
    maxSize: 0,
    fromShare: false,

  },
  cardId:'',
  needSignOut:false,
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    console.log('要签到的活动==>', options)
    let actId = options.actId
    let consumeToken = options.consumeToken
    let needSignOut = options.needSignOut;
    this.needSignOut = needSignOut;
    this.cardId = options.cardID;
    this.setData({
      consumeToken: consumeToken,
      needSignOut: needSignOut,
    })

    let params = {
      actId: actId,
      consumeToken: consumeToken,
      page: this.data.curPage + 1,
      size: 400
    };
    api_GetParticipatedList(params, (res) => {
      console.log("#########--参与人列表-##########", res.data.data)
      this.setData({
        dataSource: res.data.data.list,
        curPage: res.data.data.curPage,
        maxSize: res.data.data.maxSize,
      })
    })

    console.log("小程序进入场景==>", app.globalData.resultScene)
    if (app.globalData.resultScene[0] == 1007 || app.globalData.resultScene[0] == 1008) {
      this.setData({
        fromShare: true
      })
    }
  },

  submitButtonClick: function(e) {
    let _this = this
    wx.scanCode({
      needResult: 1,
      scanType: ["qrCode", "barCode"],
      success: (res) => {
        console.log("扫码结果==>", res);
        let code = res.result;
        let ctoken = _this.data.consumeToken
        console.log('consumeToken==>', ctoken)
        wx.showModal({
          title: '提示',
          content: '是否签到: ' + code,
          success: function(e) {
            //提交卡券码以及token
            let formData = {
              consumeToken: ctoken,
              code: code,
              signAction: "sign_in"
            }
            api_SignIn(formData, (res) => {
              console.log("==> 卡券核销成功: ", res)
              if (res.errcode == 0) {
                wx.showToast({
                  title: '卡券核销成功',
                  icon: 'success'
                })
              }
            })
          },
        })
      },
      fail: (res) => {
        console.log(res);
      }
    })
  },

  quitButtonClick: function(e) {
    let _this = this
    wx.scanCode({
      needResult: 1,
      scanType: ["qrCode", "barCode"],
      success: (res) => {
        console.log("扫码结果==>", res);
        let code = res.result;
        let ctoken = _this.data.consumeToken
        console.log('consumeToken==>', ctoken)
        wx.showModal({
          title: '提示',
          content: '是否签退: ' + code,
          success: function(e) {
            //提交卡券码以及token
            let formData = {
              consumeToken: ctoken,
              code: code,
              signAction: "sign_out"
            }
            api_SignIn(formData, (res) => {
              console.log("==> 卡券核销成功: ", res)
              if (res.errcode == 0) {
                wx.showToast({
                  title: '卡券核销成功',
                  icon: 'success'
                })
              }
            })
          },
        })
      },
      fail: (res) => {
        console.log(res);
      }
    })
  },
  /**
   * 生成可用报名用户自主签到/签退二维码
   */
  genQrCode:function(){
    let itemList =this.needSignOut ? ['生成签到码', '生成签退码']:['生成签到码'];
    let _this = this;
    wx.showActionSheet({
      itemList: itemList,
      success (res) {
        _this.getQrcode(res.tapIndex===0, _this.cardId)
      }
    })
  },

  getQrcode:function(is_signin, cardId){
    wx.cloud.init();
    let scene =  is_signin?'0':'1';
    scene += cardId;

    function failMsg(msg){
      return function(){
        wx.showToast({
          title: msg,
          icon: 'none'
        });
        console.error('getQrcode fail:', arguments)
      };
    }

    console.log('getQrcode:scene', scene);

    wx.cloud.callFunction({
      name: 'getQRCode',
      data: {
        scene: scene,
        page: 'pages/act/actSignSelf/actSignSelf',
        width: 512
      },
      success: function(res) {
        if(res.result.errCode)
          return failMsg("生成二维码失败")();

        const filePath = `${wx.env.USER_DATA_PATH}/${is_signin?"签到码":"签退码"}.png`;
        console.log(res.result, filePath);
        const fsm = wx.getFileSystemManager();
        fsm.writeFile({
          filePath: filePath,
          data: res.result.buffer,
          encoding: 'binary',
          success: function() {
            wx.authorize({
              scope: 'scope.writePhotosAlbum',
              success () {
                wx.saveImageToPhotosAlbum({
                  filePath: filePath,
                  success: failMsg("二维码已保存到相册"),
                  fail: failMsg("二维码保存到相册失败，请稍后再试"),
                })
              },
              fail: failMsg("授权失败，请在小程序设置中开启'保存到相册'权限"),
            });
          },
          fail: failMsg("保存失败，请稍后再试"),
        });
      },
      fail: failMsg("生成二维码失败，请稍后再试")
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  // 从分享入口进入时返回主页
  goHome: function(e) {
    wx.reLaunch({
      url: '../home/home',
    })
  },
})
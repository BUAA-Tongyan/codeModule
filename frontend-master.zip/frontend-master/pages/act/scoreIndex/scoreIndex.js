// pages/act/actDiscover/actDiscover.js
let app = getApp()
let {
    api_GetPointChangeRecords
} = require("../../api/getData.js")
//wx-chart相关引用
let wxCharts = require('../../../utils/wxcharts.js');
let ringChart = null;
Page({

    data: {
        currentTab: 0,
    },

    onLoad: function (options) {

        let points = options.points
        let params = {
            page: 1,
            size: 8
        }
        api_GetPointChangeRecords(params, (res) => {
            console.log('积分变更记录==>', res)
            this.setData({
                dataSource: res.data.list,
                totalPoints: points
            })

        })
    },

    onReady: function () {

        var windowWidth = 320;
        try {
            var res = wx.getSystemInfoSync();
            windowWidth = res.windowWidth;
        } catch (e) {
            console.error('getSystemInfoSync failed!');
        }

        ringChart = new wxCharts({
            animation: true,
            canvasId: 'ringCanvas',
            type: 'ring',
            extra: {
                ringWidth: 25,
                pie: {
                    offsetAngle: -45
                }
            },
            series: [{
                name: '发起',
                data: 15,
                stroke: false
            }, {
                name: '参与',
                data: 35,
                stroke: false
            }, {
                name: '分享',
                data: 78,
                stroke: false
            }, {
                name: '点赞',
                data: 63,
                stroke: false
            }],
            disablePieStroke: true,
            width: windowWidth,
            height: 200,
            dataLabel: false,
            legend: true,
            background: '#f5f5f5',
            padding: 0
        });
        ringChart.addEventListener('renderComplete', () => {
            console.log('renderComplete');
        });
        setTimeout(() => {
            ringChart.stopAnimation();
        }, 500);
    },

    onPullDownRefresh: function (options) {
        // 页面相关事件处理函数--监听用户下拉动作
        wx.showToast({
            title: '数据加载中',
            icon: 'loading',
            duration: 1000,
        })
        this.refresh()
    },

    refresh: function () {

        let params = {
            page: 1,
            size: 400
        }
        api_GetPointChangeRecords(params, (res) => {
            console.log('积分变更记录==>', res)
            this.setData({
                dataSource: res.data.list,
            })
            wx.hideToast()
        })
        wx.stopPullDownRefresh()
    },

    touchHandler: function (e) {
        console.log(ringChart.getCurrentDataIndex(e));
    },
    updateData: function () {
        ringChart.updateData({
            title: {
                name: '80%'
            },
            subtitle: {
                color: '#ff0000'
            }
        });
    },

    //滑动切换
    swiperTab: function (e) {
        var that = this;
        that.setData({
            currentTab: e.detail.current
        });
    },
    //点击切换
    clickTab: function (e) {
        var that = this;
        if (this.data.currentTab === e.target.dataset.current) {
            return false;
        } else {
            that.setData({
                currentTab: e.target.dataset.current
            })
        }
    },
    //返回微沙龙首页
    goHome: function () {
        wx.switchTab({
            url: '../home/home'
        })
    },
    //返回活动广场
    goAcadHome: function () {
        wx.switchTab({
            url: '../acadHome/acadHome'
        })
    },
    //返回活动发起
    goActApply: function () {
        wx.switchTab({
            url: '../actApply/actApply'
        })
    },
    //返回积分规则
    goRule: function () {
        wx.navigateTo({
            url: '../scoreRule/scoreRule'
        })
    },

})
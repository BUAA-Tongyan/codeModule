// pages/act/actApply/actApply.js
let {
  api_GetActApplyForm,
  api_ApplyNewAct,
  api_uc_GetInfoByToken,
  api_GetHundredActType,
  api_PostHundredAct
  // api_SendTemplateMessage
} = require("../../api/getData.js")
import {
  $wuxToptips
} from '../../components/wux-index'
const app = getApp()
Page({

  data: {
    notifyItems: [{
        name: '无',
        value: ''
      },
      {
        name: '12:00',
        value: '12:00'
      },
      {
        name: '18:00',
        value: '18:00'
      },
    ],

    showupload:false,

    challangeTypes: ['跑步', '阅读', '外语', '锻炼', '学习', '就业', '其他'],
    challangeIndex: 0,

    challangePlaces: ['学院路', '沙河'],
    challangeIndex2: 0,

    challangeNotices: ['是', '否'],
    challangeIndex3: 0,

    starttime: ['今天', '明天'],
    startIndex: 0,

    commitment: [{
      name: "yes",
      value: "我同意活动发起承诺书"
    }],
    guestNum: 0, //主讲人数
    buttonDisabled: true, //提交按钮状态
    maxNum: 3, //最大参与人数
    sponsorIsShow: true, //是否显示主办方信息
    lengthOfInfo: 0,

    //待提交的表单数据
    theme: '', //活动标题
    act_type: "跑步", //活动类型
    campus: 1, //活动地点  1->学院路校区, 2->沙河校区
    notify: ['12:00'], //打卡提醒
    partner_cnt: 0, //招募队友数量
    desc: '今日flag一定要屹立不倒', //活动描述
    start_day: '', //活动开始日
    weixin: '', //微信
    // 私有属性：触发修改speaks事件时，禁止blur事件
    __killBlur: false
  },

  onLoad: function(options) {

    /*通过token获取用户信息*/
    api_uc_GetInfoByToken((res) => {
      console.log('通过token获取用户信息==>', res.data.data)
      var datestr = ''
      datestr = app.timePicker.date;
      datestr = datestr.replace(/-/g, "")
      this.setData({
        userContactEmail: res.data.data.email,
        userContactName: res.data.data.nickname,
        userContactTel: res.data.data.phone,
        start_day: datestr
      })
      this.sponsorIsShow()
    })
  },
  onShow: function(options) {
    if (app.globalData.userNotSignUp) {
      wx.showModal({
        title: '提示',
        content: '注册同研平台后才可发起活动！',
        confirmText: "前往注册",
        cancelText: "随便逛逛",
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
            wx.navigateTo({
              url: '../register/register',
            })
          } else if (res.cancel) {
            console.log('用户点击取消')
            wx.reLaunch({
              url: '../home/home',
            })
          }
        }
      })
    }

    /*获取活动类型*/
    api_GetHundredActType((res) => {
      var _this = this;
      console.log('获取的活动类型', res)
      _this.setData({
        challangeTypes: res
      })
    })

  },

  // 用户联系方式 图片添加
  chooseContactImage: function(e) {
    var _this = this;
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original'],
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: (res) => {

        console.log('活动图片添加成功', res)
        var tempFilePath = res.tempFilePaths[0];
        var url = '/buaa/act/uploadInfoImg';
        var name = 'actInfoImg';
        _this.setData({
          fImg_QRcode: tempFilePath
        })
        console.log('tmp filePath', _this.data.fImg_QRcode);
        wx.uploadFile({
          url: 'https://www.buaagsu.com' + url,
          filePath: tempFilePath,
          name: name,
          header: {
            'content-type': 'multipart/form-data',
            'hellobuaa': wx.getStorageSync("token"),
            "Cookie": "SESSION=" + wx.getStorageSync("session_id")
          },
          success: (res) => {
            console.log('res', res);
            if (res.statusCode != 200) {
              wx.showModal({
                title: '提示',
                content: '上传失败',
                showCancel: false
              })
              return;
            }
            var data = res.data
            console.log('活动附图url', JSON.parse(res.data).imgUrl);
            _this.setData({
              qrimg: JSON.parse(res.data).imgUrl
            })
          },
          fail: function(e) {
            console.log(e);
            wx.showModal({
              title: '提示',
              content: '上传失败',
              showCancel: false
            })
          },
        })
      }
    })

  },


  // 活动名称设置
  setActFormTitle: function(e) {
    this.setData({
      theme: e.detail.value
    })
    console.log('活动名称', this.data.theme)
  },
  // 活动类型设置
  setActFormType: function(e) {
    this.setData({
      act_type: this.data.challangeTypes[e.detail.value],
      challangeIndex: e.detail.value,
    })
    console.log('活动类型', this.data.act_type)
  },
  // 活动地点设置
  setActFormPlace: function(e) {
    this.setData({
      campus: (parseInt(e.detail.value) + 1).toString(),
      challangeIndex2: e.detail.value,
    })
    console.log('活动地点', this.data.campus)
  },
  //打卡提醒设置
  setActFormNotice: function(e) {
    var ns = ''
    if (e.detail.value == '0') {
      ns = true;
    } else {
      ns = false;
    }
    this.setData({
      notify: ns,
      challangeIndex3: e.detail.value,
    })
    console.log('是否打卡提醒', this.data.notify)
  },
  //参与人数设置
  setActFormMaxQuantity: function(e) {
    if(e.detail==0){
      this.setData({
        partner_cnt: e.detail,
        showupload: false,
      })
    }
    else{
      this.setData({
        partner_cnt: e.detail,
        showupload: true,
      })
    }
    console.log('参与人数', this.data.partner_cnt)
  },
  //活动简介
  setActFormInfo: function(e) {
    this.setData({
      desc: e.detail.value
    })
    console.log('活动简介', this.data.desc)
  },
  //设置活动开始时间
  setActFormStartTime: function(e) {
    var datestr = ''
    if (e.detail.value == '0') {
      datestr = app.timePicker.date;
    } else {
      datestr = app.timePicker.nextdate;
    }
    datestr = datestr.replace(/-/g, "")
    this.setData({
      start_day: datestr,
      startIndex: e.detail.value,
    })
    console.log('活动开始时间', this.data.start_day)
  },
  // 用户联系方式 图片添加
  chooseContactImage: function(e) {
    var _this = this;
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original'],
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: (res) => {
        // console.log('活动图片添加成功', res)
        var tempFilePath = res.tempFilePaths[0];
        var url = '/buaa/act/uploadInfoImg';
        var name = 'actInfoImg';
        wx.uploadFile({
          url: 'https://www.buaagsu.com' + url,
          filePath: tempFilePath,
          name: name,
          header: {
            'content-type': 'multipart/form-data',
            'hellobuaa': wx.getStorageSync("token"),
            "Cookie": "SESSION=" + wx.getStorageSync("session_id")
          },
          success: (res) => {
            // console.log('res', res);
            if (res.statusCode != 200) {
              wx.showModal({
                title: '提示',
                content: '上传失败',
                showCancel: false
              })
              return;
            }
            var data = res.data
            console.log('活动附图url', JSON.parse(res.data).imgUrl);
            _this.setData({
              weixin: JSON.parse(res.data).imgUrl
            })
          },
          fail: function(e) {
            console.log(e);
            wx.showModal({
              title: '提示',
              content: '上传失败',
              showCancel: false
            })
          },
        })
      }
    })

  },

  // 打卡提醒修改
  notifyChange: function(e) {
    var that = this;
    let checkboxValues = null;
    let checkboxItems = this.data.notifyItems,
      values = e.detail.value
    console.log('当前选中的value',values)
    var vv=[]
    if (values[values.length-1]!=""){
      for (var i = 0, lenI = checkboxItems.length; i < lenI; ++i) {
        if (checkboxItems[i].value==""){
          checkboxItems[i].checked = false;
          continue
        }
        if (values.indexOf(checkboxItems[i].value) >= 0) {
          checkboxItems[i].checked = true;
          vv.push(checkboxItems[i].value);
        } else {
          checkboxItems[i].checked = false;
        }
      }
      values=vv
    }
    else  {
      console.log('value包含 空', values)
      checkboxItems[0].checked = true;
      checkboxItems[1].checked = false;
      checkboxItems[2].checked = false;
      values=[""];
    } 
    console.log('setting',values)
    this.setData({
      notifytimes:values,
      notifyItems:checkboxItems
    })
  },
  // 恢复blur
  recoverBlur() {
    console.log('现在恢复blur事件')
    this.data.__killBlur = false
  },


  //是否显示主办方信息
  sponsorIsShow() {
    let userContactEmail = this.data.userContactEmail
    let userContactName = this.data.userContactName
    let userContactTel = this.data.userContactTel


    this.setData({
      contactName: userContactName,
      contactEmail: userContactEmail,
      contactTel: userContactTel,
      sponsorIsShow: false,
    })

  },

  //主办方信息设置
  //主办方名称
  setContactName: function(e) {
    this.setData({
      contactName: e.detail.value
    })
  },
  //主办方邮箱
  setContactEmail: function(e) {
    this.setData({
      contactEmail: e.detail.value
    })
  },
  //主办方联系电话
  setContactTel: function(e) {
    this.setData({
      contactTel: e.detail.value
    })
  },
  //活动简介长度
  getLengthOfInfo: function(e) {
    var length = e.detail.value.length;
    this.setData({
      lengthOfInfo: length
    })
  },
  // 获取卡券的标题，卡券标题不能过长，否则影响小程序后台申请卡券
  // 需要对过长的标题进行截取
  getCardTitle: function(e) {
    var titleStr = this.data.theme
    var titleLength = this.data.theme.length;
    var codeLength = 0;
    var cardTitle = new String()
    for (let i = 0; i < titleLength; i++) {
      var charCode = titleStr.charCodeAt(i);
      console.log("charCode[" + i + "]" + charCode)
      var charIndex = titleStr.charAt(i);
      if (charCode >= 0 && charCode <= 128) {
        cardTitle += charIndex;
        codeLength += 1;
      } else {
        cardTitle += charIndex;
        codeLength += 3;
      }
      if (codeLength === 24) {
        cardTitle += '…'
        break;
      }
      if (codeLength > 24) {
        break;
      }
    }
    if (codeLength > 24) {
      cardTitle = cardTitle.substring(0, cardTitle.length - 1)
      cardTitle += "…"
    }
    console.log("titleLength: ", titleLength)
    console.log("codeLength: ", codeLength)
    console.log("cardTitle: ", cardTitle)
    this.data.cardTitle = cardTitle
  },

  //活动发起承诺书弹窗
  checkboxChange: function(e) {
    console.log('checkbox发生change事件，携带value值为：', e.detail.value)
    if (e.detail.value.length == 1) {
      this.setData({
        buttonDisabled: false
      })
      wx.showModal({
        title: '活动发起承诺书',
        content: '我承诺，我将严格遵守《用户协议》，保证活动内容不涉及政治、宗教、任何形式的歧视等违法违规事项。如有违反任何法律法规及相关条款的行为，本人愿意承担所有责任。',
        showCancel: false,
        confirmText: "了解了"
      })
    } else {
      this.setData({
        buttonDisabled: true
      })
    }
  },
  testSummary: function() {},
  //提交发起活动表单
  submitApply: function(e) {
    console.log('formId==>', e.detail.formId)
    this.getCardTitle() //处理卡券标题
    //发起活动前数据的处理与验证
    let that = this.data
    let form = {
      theme: that.theme, //活动主题
      act_type: that.act_type,
      campus: that.campus,
      notify: that.notify,
      partner_cnt: that.partner_cnt,
      desc: that.desc,
      start_day: that.start_day,
      weixin: that.weixin
      // formId: e.detail.formId
    }
    console.log('发起活动前组装成的表单==>', form)
    ///////////////////////////////////////////////表单验证
    if (form.theme.length == 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '活动标题不能为空',
        duration: 2000,
        success() {},
      })
    } else if (form.desc.length == 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '活动描述不能为空',
        duration: 2000,
        success() {},
      })
    } else if (form.partner_cnt>0 && form.weixin.length == 0) {
      $wuxToptips().show({
        icon: 'cancel',
        hidden: false,
        text: '请上传微信二维码，方便匹配队友',
        duration: 2000,
        success() {},
      })
    } else {
      ////////////////////////////////////////////////
      let formJsonStr = JSON.stringify(form);
      console.log('转换后的json字符串==>', formJsonStr);
      // let temp = JSON.parse(formJsonStr)
      // console.log('json序列化==>', temp);

      let submitform={
        act_form:formJsonStr
      }

      wx.showModal({
        title: '确认发起？',
        success: (res) => {
          if (res.confirm) {
            console.log('用户点击确定发起活动')

            console.log('活动提交表单数据==> ', submitform)


            // 调用发起活动API
            api_PostHundredAct(submitform, (res) => {
              console.log('活动发起结果==>', res)
              if (res.status == 200) {
                console.log('活动发起成功==>')
                //发送模板消息
                wx.redirectTo({
                  url: '../msg/msg_success?type=challange',
                })
              } else {
                console.log('活动发起失败==>')
                wx.showModal({
                  title: '失败',
                  content: res.error_msg || '请尝试重新发起',
                  success: function(res) {
                    if (res.confirm) {
                      console.log('用户点击确定')
                    } else if (res.cancel) {
                      console.log('用户点击取消')
                    }
                  }
                })
              }
            })
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } // if time>1

  },
})
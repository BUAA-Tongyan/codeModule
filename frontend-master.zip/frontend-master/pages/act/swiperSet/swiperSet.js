// pages/act/swiperSet/swiperSet.js
let {
  api_GetAllBanners,
  api_AddBanner,
  api_DeleteBanner
} = require("../../api/getData.js")

Page({

  /**
   * 页面的初始数据
   */
  data: {
    swiperList: [],
    titleList: [],
    newImgPath: "",
    newTitle: "",
    newUrl: "",
    indexBanner: 0,
    indicatorDots: true,
    autoplay: true,
    interval: 2000,
    duration: 1000,
    previousMargin: 0,
    nextMargin: 0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.getBanners()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  /**************以上是生命周期********************以下是自定义函数**************************/
  /* 获取轮播图*/
  getBanners: function() {
    api_GetAllBanners((res) => {
      console.log('api_GetAllBanners==>', res)
      if (res.length) {
        this.setData({
          swiperList: res,
          bannerIdToDelete: res[0].id
        });
        var tempList = [];
        for (var i in res) {
          tempList[i] = res[i].title
        }
        this.setData({
          titleList: tempList
        })
      }
      console.log('默认要删除的bannerID==>', this.data.bannerIdToDelete)
    })
  },


  /*添加轮播相关*/
  chooseImage: function(e) {
    var _this = this;
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original'],
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function(res) {
        _this.setData({
          newImgPath: res.tempFilePaths[0]
        })
        console.log('===>', res)
      }
    })
  },

  bindTitle: function(e) {
    this.setData({
      newTitle: e.detail.value
    })
  },

  bindUrl: function(e) {
    this.setData({
      newUrl: e.detail.value
    })
  },

  submitAdd: function(e) {
    var temp = e.detail.value;
    var _this = this;
    var reg = /^([hH][tT]{2}[pP][sS]:\/\/|[hH][tT]{2}[pP][sS]:\/\/)(([A-Za-z0-9-~]+)\.)+([A-Za-z0-9-~\/])+$/;
    //temp['img'] = _this.data.newImgPath;
    if (temp.title.length == 0) {
      wx.showToast({
        title: '标题不能为空',
        icon: 'none',
        duration: 2000
      })
    } else if (temp.url.length == 0) {
      wx.showToast({
        title: '地址不能为空',
        icon: 'none',
        duration: 2000
      })
    }  else if (this.data.newImgPath.length == 0) {
      wx.showToast({
        title: '图片不能为空',
        icon: 'none',
        duration: 2000
      })
    } else {
      api_AddBanner(temp, this.data.newImgPath, (res) => {
        console.log('添加轮播结果反馈==>', res)
        if (res.errMsg == 'ok') {
          wx.showToast({
            title: '添加成功,请刷新查看',
            icon: 'success',
          })
        } else {
          wx.showToast({
            title: '添加失败',
            icon: 'none',
          })
        }
      })
    }
  },

  /*删除轮播相关*/
  pickTtitle: function(e) {
    let tmp = this.data.swiperList[e.detail.value].id
    this.setData({
      indexBanner: e.detail.value,
      bannerIdToDelete: tmp
    })
    console.log('要删除的轮播ID==>', this.data.bannerIdToDelete)
  },

  deleteSubmit: function(e) {
    console.log('轮播：', this.data.swiperList)
    var _this = this
    wx.showModal({
      title: '提示',
      content: '确定删除此轮播图吗？',
      success: function(res) {

        if (res.confirm) {
          // console.log(_this.data.indexBanner)

          api_DeleteBanner(_this.data.bannerIdToDelete, (res) => {
            console.log('删除轮播结果反馈==>', res)
            if (res.errmsg == 'ok') {
              wx.showToast({
                title: '删除成功',
                icon: 'success',
              })
            } else {
              wx.showToast({
                title: '删除失败',
                icon: 'none',
              })
            }
          })
        } else if (res.cancel) {
          console.log("取消删除")
        }
      }
    })
  },
  //刷新
  refreshBanner: function() {
    this.getBanners()
    wx.showToast({
      title: '刷新成功',
      icon: 'success'
    })
  }
})
// pages/act/msg/msg_success.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    actApply: false,
    actParticipate: false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    console.log('传值==>', options.type)
    this.setData({
      actId: options.actId,
    })
    // if (options.type == "actApply") {
    //   console.log('发起活动=============>')
    //   this.setData({
    //     actApply: true,
    //     actParticipate: false
    //   })
    // }
    // if (options.type == "actParticipate") {
    //   console.log("报名成功-------------------->")
    //   this.setData({
    //     actApply: false,
    //     actParticipate: true,
    //     actId: options.actId,
    //   })
    // }
  },

  goHome: function(e) {
    wx.switchTab({
      url: '/pages/act/home/home',
    })
  },

  // stayActApply: function(e) {
  //   wx.switchTab({
  //     url: '/pages/act/actApply/actApply',
  //   })
  // },

  stayActDetail: function(e) {
    wx.navigateTo({
      url: '../actDetail/actDetail?actId=' + this.data.actId,
    })
  },
})